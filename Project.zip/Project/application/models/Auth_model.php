<?php
class Auth_model extends CI_Model {
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function login($email, $password) {
        $this->db->where('email', $email);
        $query = $this->db->get('students');

        if ($query->num_rows() == 1) {
            $user = $query->row();
            if ($user->password === $password) { 
                return $user;
            }  
        }

        return false;
    }
}
?>
