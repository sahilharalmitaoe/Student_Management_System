<!DOCTYPE html>
<html>
<head>
    <title>Change Password</title>
</head>
<body>
    <h2>Change Password</h2>
    <?php echo validation_errors('<p style="color: red;">', '</p>'); ?>
    <?php if (isset($error_message)) echo '<p style="color: red;">' . $error_message . '</p>'; ?>

    <?php echo form_open('dashboard/change_password'); ?>
        <p>
            <label for="current_password">Current Password:</label>
            <input type="password" name="current_password" required>
        </p>
        <p>
            <label for="new_password">New Password:</label>
            <input type="password" name="new_password" required>
        </p>
        <p>
            <label for="confirm_password">Confirm Password:</label>
            <input type="password" name="confirm_password" required>
        </p>
        <p>
            <input type="submit" name="change_password" value="Change Password">
        </p>
    <?php echo form_close(); ?>
</body>
</html>
