<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('auth_model');
        $this->load->library('form_validation');
        $this->load->library('session');
    }
    
    public function admin_login() {
        
        $email = $this->input->post('email');
        $password = $this->input->post('password');

       
        $this->load->model('User_model');

        
        $admin = $this->User_model->get_admin_by_email($email, $password);

        if ($admin) {
            
            $this->session->set_userdata('is_admin', true);
            
            redirect('admin_dashboard');
        } else {
            
            $data['error_message'] = 'Invalid email or password';
            $this->load->view('admin_login', $data);
        }
    }

    

    public function index() {
        if ($this->session->userdata('user_id')) {
             
            redirect('dashboard');
        } else {
            
            $this->load->view('login');
        }
    }

    public function login() {
        
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');

        if ($this->form_validation->run() == FALSE) {
           
            $this->load->view('login');
        } else {
            
            $email = $this->input->post('email');
            $password = $this->input->post('password');

            
            $user = $this->auth_model->login($email, $password);

            if ($user) {
                
                $this->session->set_userdata('user_id', $user->id);

                
                redirect('dashboard');
            } else {
                
                $data['error_message'] = 'Invalid email or password.';
                $this->load->view('login', $data);
            }
        }
    }

    public function logout() {
        
        $this->session->unset_userdata('user_id');
        redirect('auth');
    }
    

}
?>
