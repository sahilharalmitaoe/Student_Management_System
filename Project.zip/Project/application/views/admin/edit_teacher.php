<!DOCTYPE html>
<html>
<head>
    <title>Edit Teacher</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2 class="text-primary">Edit Teacher</h2>
        <form method="post" action="<?php echo site_url('admin/update_teacher/'.$teacher_data->email); ?>">
            <label for="first_name">First Name:</label>
            <input type="text" name="first_name" value="<?php echo $teacher_data->first_name; ?>" required>
            <label for="last_name">Last Name:</label>
            <input type="text" name="last_name" value="<?php echo $teacher_data->last_name; ?>" required>
            <label for="email">Email:</label>
            <input type="email" name="email" value="<?php echo $teacher_data->email; ?>" required>
            <label for="phone">Phone:</label>
            <input type="text" name="phone" value="<?php echo $teacher_data->phone; ?>" required>
            <label for="address">Address:</label>
            <input type="text" name="address" value="<?php echo $teacher_data->address; ?>" required>
            <label for="course">Course:</label>
            <input type="text" name="course" value="<?php echo $teacher_data->course; ?>" required>
            <button type="submit">Update</button>
        </form>
    </div>
</body>
</html>
