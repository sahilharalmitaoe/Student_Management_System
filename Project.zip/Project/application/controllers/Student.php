<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('student_model');
        $this->load->library('form_validation');
    }

    public function index() {
        $this->load->view('register');
    }

    public function save() {
        
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[students.email]');
        $this->form_validation->set_rules('phone', 'Phone', 'trim|required');
        $this->form_validation->set_rules('address', 'Address', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]');
        $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|matches[password]');
        $this->form_validation->set_rules('gender', 'Gender', 'trim|required');

        if ($this->form_validation->run() == FALSE) {
            
            $this->load->view('register');
        } else {
            
            $data = array(
                'first_name' => $this->input->post('first_name'),
                'last_name' => $this->input->post('last_name'),
                'email' => $this->input->post('email'),
                'phone' => $this->input->post('phone'),
                'address' => $this->input->post('address'),
                'password' => $this->input->post('password'), 
                'gender' => $this->input->post('gender')
            );

            
            $this->student_model->insert_student($data);

            
            redirect('auth/login');
        }
    }
    public function get_admin_by_email($email) {
        $this->db->where('email', $email);
        $this->db->where('is_admin', 1); 
        $query = $this->db->get('students');
        return $query->row_array();
    }

    public function get_all_students() {
        $query = $this->db->get('students');
        return $query->result_array();
    }
    
}
?>
