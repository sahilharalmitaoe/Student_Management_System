<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-07-26 08:17:11 --> Config Class Initialized
INFO - 2023-07-26 08:17:11 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:17:11 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:17:11 --> Utf8 Class Initialized
INFO - 2023-07-26 08:17:11 --> URI Class Initialized
INFO - 2023-07-26 08:17:11 --> Router Class Initialized
INFO - 2023-07-26 08:17:11 --> Output Class Initialized
INFO - 2023-07-26 08:17:11 --> Security Class Initialized
DEBUG - 2023-07-26 08:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:17:11 --> Input Class Initialized
INFO - 2023-07-26 08:17:11 --> Language Class Initialized
INFO - 2023-07-26 08:17:11 --> Loader Class Initialized
INFO - 2023-07-26 08:17:11 --> Helper loaded: url_helper
INFO - 2023-07-26 08:17:11 --> Helper loaded: form_helper
INFO - 2023-07-26 08:17:11 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:17:11 --> Controller Class Initialized
DEBUG - 2023-07-26 08:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:17:11 --> Database Driver Class Initialized
INFO - 2023-07-26 08:17:11 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:17:11 --> Model "Student_model" initialized
INFO - 2023-07-26 08:17:11 --> Model "Teacher_model" initialized
INFO - 2023-07-26 08:17:11 --> Config Class Initialized
INFO - 2023-07-26 08:17:11 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:17:11 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:17:11 --> Utf8 Class Initialized
INFO - 2023-07-26 08:17:11 --> URI Class Initialized
INFO - 2023-07-26 08:17:11 --> Router Class Initialized
INFO - 2023-07-26 08:17:11 --> Output Class Initialized
INFO - 2023-07-26 08:17:11 --> Security Class Initialized
DEBUG - 2023-07-26 08:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:17:11 --> Input Class Initialized
INFO - 2023-07-26 08:17:11 --> Language Class Initialized
INFO - 2023-07-26 08:17:11 --> Loader Class Initialized
INFO - 2023-07-26 08:17:11 --> Helper loaded: url_helper
INFO - 2023-07-26 08:17:11 --> Helper loaded: form_helper
INFO - 2023-07-26 08:17:11 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:17:11 --> Controller Class Initialized
DEBUG - 2023-07-26 08:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:17:11 --> Database Driver Class Initialized
INFO - 2023-07-26 08:17:11 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:17:12 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/login.php
INFO - 2023-07-26 08:17:12 --> Final output sent to browser
DEBUG - 2023-07-26 08:17:12 --> Total execution time: 0.0639
INFO - 2023-07-26 08:17:22 --> Config Class Initialized
INFO - 2023-07-26 08:17:22 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:17:22 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:17:22 --> Utf8 Class Initialized
INFO - 2023-07-26 08:17:22 --> URI Class Initialized
INFO - 2023-07-26 08:17:22 --> Router Class Initialized
INFO - 2023-07-26 08:17:22 --> Output Class Initialized
INFO - 2023-07-26 08:17:22 --> Security Class Initialized
DEBUG - 2023-07-26 08:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:17:22 --> Input Class Initialized
INFO - 2023-07-26 08:17:22 --> Language Class Initialized
INFO - 2023-07-26 08:17:22 --> Loader Class Initialized
INFO - 2023-07-26 08:17:22 --> Helper loaded: url_helper
INFO - 2023-07-26 08:17:22 --> Helper loaded: form_helper
INFO - 2023-07-26 08:17:22 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:17:22 --> Controller Class Initialized
DEBUG - 2023-07-26 08:17:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:17:22 --> Database Driver Class Initialized
INFO - 2023-07-26 08:17:22 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:17:23 --> Config Class Initialized
INFO - 2023-07-26 08:17:23 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:17:23 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:17:23 --> Utf8 Class Initialized
INFO - 2023-07-26 08:17:23 --> URI Class Initialized
INFO - 2023-07-26 08:17:23 --> Router Class Initialized
INFO - 2023-07-26 08:17:23 --> Output Class Initialized
INFO - 2023-07-26 08:17:23 --> Security Class Initialized
DEBUG - 2023-07-26 08:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:17:23 --> Input Class Initialized
INFO - 2023-07-26 08:17:23 --> Language Class Initialized
INFO - 2023-07-26 08:17:23 --> Loader Class Initialized
INFO - 2023-07-26 08:17:23 --> Helper loaded: url_helper
INFO - 2023-07-26 08:17:23 --> Helper loaded: form_helper
INFO - 2023-07-26 08:17:23 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:17:23 --> Controller Class Initialized
DEBUG - 2023-07-26 08:17:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:17:23 --> Database Driver Class Initialized
INFO - 2023-07-26 08:17:23 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:17:23 --> Model "Student_model" initialized
INFO - 2023-07-26 08:17:23 --> Model "Teacher_model" initialized
INFO - 2023-07-26 08:17:23 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/dashboard.php
INFO - 2023-07-26 08:17:23 --> Final output sent to browser
DEBUG - 2023-07-26 08:17:23 --> Total execution time: 0.0578
INFO - 2023-07-26 08:17:32 --> Config Class Initialized
INFO - 2023-07-26 08:17:32 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:17:32 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:17:32 --> Utf8 Class Initialized
INFO - 2023-07-26 08:17:32 --> URI Class Initialized
INFO - 2023-07-26 08:17:32 --> Router Class Initialized
INFO - 2023-07-26 08:17:32 --> Output Class Initialized
INFO - 2023-07-26 08:17:32 --> Security Class Initialized
DEBUG - 2023-07-26 08:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:17:32 --> Input Class Initialized
INFO - 2023-07-26 08:17:32 --> Language Class Initialized
INFO - 2023-07-26 08:17:32 --> Loader Class Initialized
INFO - 2023-07-26 08:17:32 --> Helper loaded: url_helper
INFO - 2023-07-26 08:17:32 --> Helper loaded: form_helper
INFO - 2023-07-26 08:17:32 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:17:32 --> Controller Class Initialized
DEBUG - 2023-07-26 08:17:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:17:32 --> Database Driver Class Initialized
INFO - 2023-07-26 08:17:32 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:17:32 --> Model "Student_model" initialized
INFO - 2023-07-26 08:17:32 --> Model "Teacher_model" initialized
INFO - 2023-07-26 08:17:32 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 08:17:32 --> Final output sent to browser
DEBUG - 2023-07-26 08:17:32 --> Total execution time: 0.0577
INFO - 2023-07-26 08:17:53 --> Config Class Initialized
INFO - 2023-07-26 08:17:53 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:17:53 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:17:53 --> Utf8 Class Initialized
INFO - 2023-07-26 08:28:49 --> Config Class Initialized
INFO - 2023-07-26 08:28:49 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:28:49 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:28:49 --> Utf8 Class Initialized
INFO - 2023-07-26 08:28:49 --> URI Class Initialized
INFO - 2023-07-26 08:28:49 --> Router Class Initialized
INFO - 2023-07-26 08:28:49 --> Output Class Initialized
INFO - 2023-07-26 08:28:49 --> Security Class Initialized
DEBUG - 2023-07-26 08:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:28:49 --> Input Class Initialized
INFO - 2023-07-26 08:28:49 --> Language Class Initialized
INFO - 2023-07-26 08:28:49 --> Loader Class Initialized
INFO - 2023-07-26 08:28:49 --> Helper loaded: url_helper
INFO - 2023-07-26 08:28:49 --> Helper loaded: form_helper
INFO - 2023-07-26 08:28:49 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:28:49 --> Controller Class Initialized
DEBUG - 2023-07-26 08:28:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:28:49 --> Database Driver Class Initialized
INFO - 2023-07-26 08:28:49 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:28:49 --> Model "Student_model" initialized
INFO - 2023-07-26 08:28:49 --> Model "Teacher_model" initialized
ERROR - 2023-07-26 08:28:49 --> Severity: Error --> Call to undefined method Teacher_model::get_all_teachers() C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 75
INFO - 2023-07-26 08:28:50 --> Config Class Initialized
INFO - 2023-07-26 08:28:50 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:28:50 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:28:50 --> Utf8 Class Initialized
INFO - 2023-07-26 08:28:50 --> URI Class Initialized
INFO - 2023-07-26 08:28:50 --> Router Class Initialized
INFO - 2023-07-26 08:28:50 --> Output Class Initialized
INFO - 2023-07-26 08:28:50 --> Security Class Initialized
DEBUG - 2023-07-26 08:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:28:50 --> Input Class Initialized
INFO - 2023-07-26 08:28:50 --> Language Class Initialized
INFO - 2023-07-26 08:28:50 --> Loader Class Initialized
INFO - 2023-07-26 08:28:50 --> Helper loaded: url_helper
INFO - 2023-07-26 08:28:50 --> Helper loaded: form_helper
INFO - 2023-07-26 08:28:50 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:28:50 --> Controller Class Initialized
DEBUG - 2023-07-26 08:28:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:28:50 --> Database Driver Class Initialized
INFO - 2023-07-26 08:28:50 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:28:50 --> Model "Student_model" initialized
INFO - 2023-07-26 08:28:50 --> Model "Teacher_model" initialized
INFO - 2023-07-26 08:28:50 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/dashboard.php
INFO - 2023-07-26 08:28:50 --> Final output sent to browser
DEBUG - 2023-07-26 08:28:50 --> Total execution time: 0.0466
INFO - 2023-07-26 08:28:53 --> Config Class Initialized
INFO - 2023-07-26 08:28:53 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:28:53 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:28:53 --> Utf8 Class Initialized
INFO - 2023-07-26 08:28:53 --> URI Class Initialized
INFO - 2023-07-26 08:28:53 --> Router Class Initialized
INFO - 2023-07-26 08:28:53 --> Output Class Initialized
INFO - 2023-07-26 08:28:53 --> Security Class Initialized
DEBUG - 2023-07-26 08:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:28:53 --> Input Class Initialized
INFO - 2023-07-26 08:28:53 --> Language Class Initialized
INFO - 2023-07-26 08:28:53 --> Loader Class Initialized
INFO - 2023-07-26 08:28:53 --> Helper loaded: url_helper
INFO - 2023-07-26 08:28:53 --> Helper loaded: form_helper
INFO - 2023-07-26 08:28:53 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:28:53 --> Controller Class Initialized
DEBUG - 2023-07-26 08:28:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:28:53 --> Database Driver Class Initialized
INFO - 2023-07-26 08:28:53 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:28:53 --> Model "Student_model" initialized
INFO - 2023-07-26 08:28:53 --> Model "Teacher_model" initialized
INFO - 2023-07-26 08:28:53 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/dashboard.php
INFO - 2023-07-26 08:28:53 --> Final output sent to browser
DEBUG - 2023-07-26 08:28:53 --> Total execution time: 0.0281
INFO - 2023-07-26 08:28:57 --> Config Class Initialized
INFO - 2023-07-26 08:28:57 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:28:57 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:28:57 --> Utf8 Class Initialized
INFO - 2023-07-26 08:28:57 --> URI Class Initialized
INFO - 2023-07-26 08:28:57 --> Router Class Initialized
INFO - 2023-07-26 08:28:57 --> Output Class Initialized
INFO - 2023-07-26 08:28:57 --> Security Class Initialized
DEBUG - 2023-07-26 08:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:28:57 --> Input Class Initialized
INFO - 2023-07-26 08:28:57 --> Language Class Initialized
INFO - 2023-07-26 08:28:57 --> Loader Class Initialized
INFO - 2023-07-26 08:28:57 --> Helper loaded: url_helper
INFO - 2023-07-26 08:28:57 --> Helper loaded: form_helper
INFO - 2023-07-26 08:28:57 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:28:57 --> Controller Class Initialized
DEBUG - 2023-07-26 08:28:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:28:57 --> Database Driver Class Initialized
INFO - 2023-07-26 08:28:57 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:28:57 --> Model "Student_model" initialized
INFO - 2023-07-26 08:28:57 --> Model "Teacher_model" initialized
INFO - 2023-07-26 08:28:57 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_student.php
INFO - 2023-07-26 08:28:57 --> Final output sent to browser
DEBUG - 2023-07-26 08:28:57 --> Total execution time: 0.0467
INFO - 2023-07-26 08:28:59 --> Config Class Initialized
INFO - 2023-07-26 08:28:59 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:28:59 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:28:59 --> Utf8 Class Initialized
INFO - 2023-07-26 08:28:59 --> URI Class Initialized
INFO - 2023-07-26 08:28:59 --> Router Class Initialized
INFO - 2023-07-26 08:28:59 --> Output Class Initialized
INFO - 2023-07-26 08:28:59 --> Security Class Initialized
DEBUG - 2023-07-26 08:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:28:59 --> Input Class Initialized
INFO - 2023-07-26 08:28:59 --> Language Class Initialized
INFO - 2023-07-26 08:28:59 --> Loader Class Initialized
INFO - 2023-07-26 08:28:59 --> Helper loaded: url_helper
INFO - 2023-07-26 08:28:59 --> Helper loaded: form_helper
INFO - 2023-07-26 08:28:59 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:28:59 --> Controller Class Initialized
DEBUG - 2023-07-26 08:28:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:28:59 --> Database Driver Class Initialized
INFO - 2023-07-26 08:28:59 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:28:59 --> Model "Student_model" initialized
INFO - 2023-07-26 08:28:59 --> Model "Teacher_model" initialized
INFO - 2023-07-26 08:28:59 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/dashboard.php
INFO - 2023-07-26 08:28:59 --> Final output sent to browser
DEBUG - 2023-07-26 08:28:59 --> Total execution time: 0.0520
INFO - 2023-07-26 08:29:02 --> Config Class Initialized
INFO - 2023-07-26 08:29:02 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:29:02 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:29:02 --> Utf8 Class Initialized
INFO - 2023-07-26 08:29:02 --> URI Class Initialized
INFO - 2023-07-26 08:29:02 --> Router Class Initialized
INFO - 2023-07-26 08:29:02 --> Output Class Initialized
INFO - 2023-07-26 08:29:02 --> Security Class Initialized
DEBUG - 2023-07-26 08:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:29:02 --> Input Class Initialized
INFO - 2023-07-26 08:29:02 --> Language Class Initialized
INFO - 2023-07-26 08:29:02 --> Loader Class Initialized
INFO - 2023-07-26 08:29:02 --> Helper loaded: url_helper
INFO - 2023-07-26 08:29:02 --> Helper loaded: form_helper
INFO - 2023-07-26 08:29:02 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:29:02 --> Controller Class Initialized
DEBUG - 2023-07-26 08:29:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:29:02 --> Database Driver Class Initialized
INFO - 2023-07-26 08:29:02 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:29:02 --> Model "Student_model" initialized
INFO - 2023-07-26 08:29:02 --> Model "Teacher_model" initialized
ERROR - 2023-07-26 08:29:02 --> Severity: Error --> Call to undefined method Teacher_model::get_all_teachers() C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 75
INFO - 2023-07-26 08:30:05 --> Config Class Initialized
INFO - 2023-07-26 08:30:05 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:30:05 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:30:05 --> Utf8 Class Initialized
INFO - 2023-07-26 08:30:05 --> URI Class Initialized
INFO - 2023-07-26 08:30:05 --> Router Class Initialized
INFO - 2023-07-26 08:30:05 --> Output Class Initialized
INFO - 2023-07-26 08:30:05 --> Security Class Initialized
DEBUG - 2023-07-26 08:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:30:05 --> Input Class Initialized
INFO - 2023-07-26 08:30:05 --> Language Class Initialized
INFO - 2023-07-26 08:30:05 --> Loader Class Initialized
INFO - 2023-07-26 08:30:05 --> Helper loaded: url_helper
INFO - 2023-07-26 08:30:05 --> Helper loaded: form_helper
INFO - 2023-07-26 08:30:05 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:30:05 --> Controller Class Initialized
DEBUG - 2023-07-26 08:30:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:30:05 --> Database Driver Class Initialized
INFO - 2023-07-26 08:30:05 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:30:05 --> Model "Student_model" initialized
INFO - 2023-07-26 08:30:05 --> Model "Teacher_model" initialized
INFO - 2023-07-26 08:30:05 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 08:30:05 --> Final output sent to browser
DEBUG - 2023-07-26 08:30:05 --> Total execution time: 0.0426
INFO - 2023-07-26 08:30:10 --> Config Class Initialized
INFO - 2023-07-26 08:30:10 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:30:10 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:30:10 --> Utf8 Class Initialized
INFO - 2023-07-26 08:30:10 --> URI Class Initialized
INFO - 2023-07-26 08:30:10 --> Router Class Initialized
INFO - 2023-07-26 08:30:10 --> Output Class Initialized
INFO - 2023-07-26 08:30:10 --> Security Class Initialized
DEBUG - 2023-07-26 08:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:30:10 --> Input Class Initialized
INFO - 2023-07-26 08:30:10 --> Language Class Initialized
ERROR - 2023-07-26 08:30:10 --> 404 Page Not Found: Admin/edit_teacher
INFO - 2023-07-26 08:31:41 --> Config Class Initialized
INFO - 2023-07-26 08:31:41 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:31:41 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:31:41 --> Utf8 Class Initialized
INFO - 2023-07-26 08:31:41 --> URI Class Initialized
INFO - 2023-07-26 08:31:41 --> Router Class Initialized
INFO - 2023-07-26 08:31:41 --> Output Class Initialized
INFO - 2023-07-26 08:31:41 --> Security Class Initialized
DEBUG - 2023-07-26 08:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:31:41 --> Input Class Initialized
INFO - 2023-07-26 08:31:41 --> Language Class Initialized
INFO - 2023-07-26 08:31:41 --> Loader Class Initialized
INFO - 2023-07-26 08:31:41 --> Helper loaded: url_helper
INFO - 2023-07-26 08:31:41 --> Helper loaded: form_helper
INFO - 2023-07-26 08:31:41 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:31:41 --> Controller Class Initialized
DEBUG - 2023-07-26 08:31:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:31:41 --> Database Driver Class Initialized
INFO - 2023-07-26 08:31:41 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:31:41 --> Model "Student_model" initialized
INFO - 2023-07-26 08:31:41 --> Model "Teacher_model" initialized
ERROR - 2023-07-26 08:31:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\admin\edit_teacher.php 11
ERROR - 2023-07-26 08:31:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\admin\edit_teacher.php 13
ERROR - 2023-07-26 08:31:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\admin\edit_teacher.php 15
ERROR - 2023-07-26 08:31:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\admin\edit_teacher.php 17
ERROR - 2023-07-26 08:31:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\admin\edit_teacher.php 19
ERROR - 2023-07-26 08:31:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\admin\edit_teacher.php 21
ERROR - 2023-07-26 08:31:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\admin\edit_teacher.php 23
INFO - 2023-07-26 08:31:41 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 08:31:41 --> Final output sent to browser
DEBUG - 2023-07-26 08:31:41 --> Total execution time: 0.0453
INFO - 2023-07-26 08:53:42 --> Config Class Initialized
INFO - 2023-07-26 08:53:42 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:53:42 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:53:42 --> Utf8 Class Initialized
INFO - 2023-07-26 08:53:42 --> URI Class Initialized
INFO - 2023-07-26 08:53:42 --> Router Class Initialized
INFO - 2023-07-26 08:53:42 --> Output Class Initialized
INFO - 2023-07-26 08:53:42 --> Security Class Initialized
DEBUG - 2023-07-26 08:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:53:42 --> Input Class Initialized
INFO - 2023-07-26 08:53:42 --> Language Class Initialized
INFO - 2023-07-26 08:53:42 --> Loader Class Initialized
INFO - 2023-07-26 08:53:42 --> Helper loaded: url_helper
INFO - 2023-07-26 08:53:42 --> Helper loaded: form_helper
INFO - 2023-07-26 08:53:42 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:53:42 --> Controller Class Initialized
DEBUG - 2023-07-26 08:53:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:53:42 --> Database Driver Class Initialized
INFO - 2023-07-26 08:53:42 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:53:42 --> Model "Student_model" initialized
INFO - 2023-07-26 08:53:42 --> Model "Teacher_model" initialized
ERROR - 2023-07-26 08:53:42 --> Severity: Error --> Call to undefined method Teacher_model::get_teacher_by_id() C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 82
INFO - 2023-07-26 08:55:15 --> Config Class Initialized
INFO - 2023-07-26 08:55:15 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:55:15 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:55:15 --> Utf8 Class Initialized
INFO - 2023-07-26 08:55:15 --> URI Class Initialized
INFO - 2023-07-26 08:55:15 --> Router Class Initialized
INFO - 2023-07-26 08:55:15 --> Output Class Initialized
INFO - 2023-07-26 08:55:15 --> Security Class Initialized
DEBUG - 2023-07-26 08:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:55:15 --> Input Class Initialized
INFO - 2023-07-26 08:55:15 --> Language Class Initialized
INFO - 2023-07-26 08:55:15 --> Loader Class Initialized
INFO - 2023-07-26 08:55:15 --> Helper loaded: url_helper
INFO - 2023-07-26 08:55:15 --> Helper loaded: form_helper
INFO - 2023-07-26 08:55:15 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:55:15 --> Controller Class Initialized
DEBUG - 2023-07-26 08:55:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:55:15 --> Database Driver Class Initialized
INFO - 2023-07-26 08:55:15 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:55:15 --> Model "Student_model" initialized
INFO - 2023-07-26 08:55:15 --> Model "Teacher_model" initialized
ERROR - 2023-07-26 08:55:15 --> Query error: Unknown column 'teacher_id' in 'where clause' - Invalid query: SELECT *
FROM `teachers`
WHERE `teacher_id` = 'emily.williams%40example.com'
INFO - 2023-07-26 08:55:15 --> Language file loaded: language/english/db_lang.php
INFO - 2023-07-26 08:57:18 --> Config Class Initialized
INFO - 2023-07-26 08:57:18 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:57:18 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:57:18 --> Utf8 Class Initialized
INFO - 2023-07-26 08:57:18 --> URI Class Initialized
INFO - 2023-07-26 08:57:18 --> Router Class Initialized
INFO - 2023-07-26 08:57:18 --> Output Class Initialized
INFO - 2023-07-26 08:57:18 --> Security Class Initialized
DEBUG - 2023-07-26 08:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:57:18 --> Input Class Initialized
INFO - 2023-07-26 08:57:18 --> Language Class Initialized
INFO - 2023-07-26 08:57:18 --> Loader Class Initialized
INFO - 2023-07-26 08:57:18 --> Helper loaded: url_helper
INFO - 2023-07-26 08:57:18 --> Helper loaded: form_helper
INFO - 2023-07-26 08:57:18 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:57:18 --> Controller Class Initialized
DEBUG - 2023-07-26 08:57:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:57:18 --> Database Driver Class Initialized
INFO - 2023-07-26 08:57:18 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:57:18 --> Model "Student_model" initialized
INFO - 2023-07-26 08:57:18 --> Model "Teacher_model" initialized
ERROR - 2023-07-26 08:57:18 --> Severity: Notice --> Undefined variable: teacher_email C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 82
INFO - 2023-07-26 08:57:18 --> Final output sent to browser
DEBUG - 2023-07-26 08:57:18 --> Total execution time: 0.0485
INFO - 2023-07-26 08:59:35 --> Config Class Initialized
INFO - 2023-07-26 08:59:35 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:59:35 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:59:35 --> Utf8 Class Initialized
INFO - 2023-07-26 08:59:35 --> URI Class Initialized
INFO - 2023-07-26 08:59:35 --> Router Class Initialized
INFO - 2023-07-26 08:59:35 --> Output Class Initialized
INFO - 2023-07-26 08:59:35 --> Security Class Initialized
DEBUG - 2023-07-26 08:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:59:35 --> Input Class Initialized
INFO - 2023-07-26 08:59:35 --> Language Class Initialized
INFO - 2023-07-26 08:59:35 --> Loader Class Initialized
INFO - 2023-07-26 08:59:35 --> Helper loaded: url_helper
INFO - 2023-07-26 08:59:35 --> Helper loaded: form_helper
INFO - 2023-07-26 08:59:35 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:59:35 --> Controller Class Initialized
DEBUG - 2023-07-26 08:59:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:35 --> Database Driver Class Initialized
INFO - 2023-07-26 08:59:35 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:59:35 --> Model "Student_model" initialized
INFO - 2023-07-26 08:59:35 --> Model "Teacher_model" initialized
ERROR - 2023-07-26 08:59:35 --> Severity: Notice --> Undefined variable: teacher_email C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 82
INFO - 2023-07-26 08:59:35 --> Final output sent to browser
DEBUG - 2023-07-26 08:59:35 --> Total execution time: 0.0387
INFO - 2023-07-26 08:59:35 --> Config Class Initialized
INFO - 2023-07-26 08:59:35 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:59:35 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:59:35 --> Utf8 Class Initialized
INFO - 2023-07-26 08:59:35 --> URI Class Initialized
INFO - 2023-07-26 08:59:35 --> Router Class Initialized
INFO - 2023-07-26 08:59:35 --> Output Class Initialized
INFO - 2023-07-26 08:59:35 --> Security Class Initialized
DEBUG - 2023-07-26 08:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:59:35 --> Input Class Initialized
INFO - 2023-07-26 08:59:35 --> Language Class Initialized
INFO - 2023-07-26 08:59:35 --> Loader Class Initialized
INFO - 2023-07-26 08:59:35 --> Helper loaded: url_helper
INFO - 2023-07-26 08:59:35 --> Helper loaded: form_helper
INFO - 2023-07-26 08:59:35 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:59:35 --> Controller Class Initialized
DEBUG - 2023-07-26 08:59:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:35 --> Database Driver Class Initialized
INFO - 2023-07-26 08:59:35 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:59:35 --> Model "Student_model" initialized
INFO - 2023-07-26 08:59:35 --> Model "Teacher_model" initialized
ERROR - 2023-07-26 08:59:35 --> Severity: Notice --> Undefined variable: teacher_email C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 82
INFO - 2023-07-26 08:59:35 --> Final output sent to browser
DEBUG - 2023-07-26 08:59:35 --> Total execution time: 0.0387
INFO - 2023-07-26 08:59:36 --> Config Class Initialized
INFO - 2023-07-26 08:59:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:59:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:59:36 --> Utf8 Class Initialized
INFO - 2023-07-26 08:59:36 --> URI Class Initialized
INFO - 2023-07-26 08:59:36 --> Router Class Initialized
INFO - 2023-07-26 08:59:36 --> Output Class Initialized
INFO - 2023-07-26 08:59:36 --> Security Class Initialized
DEBUG - 2023-07-26 08:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:59:36 --> Input Class Initialized
INFO - 2023-07-26 08:59:36 --> Language Class Initialized
INFO - 2023-07-26 08:59:36 --> Loader Class Initialized
INFO - 2023-07-26 08:59:36 --> Helper loaded: url_helper
INFO - 2023-07-26 08:59:36 --> Helper loaded: form_helper
INFO - 2023-07-26 08:59:36 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:59:36 --> Controller Class Initialized
DEBUG - 2023-07-26 08:59:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:36 --> Database Driver Class Initialized
INFO - 2023-07-26 08:59:36 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:59:36 --> Model "Student_model" initialized
INFO - 2023-07-26 08:59:36 --> Model "Teacher_model" initialized
ERROR - 2023-07-26 08:59:36 --> Severity: Notice --> Undefined variable: teacher_email C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 82
INFO - 2023-07-26 08:59:36 --> Final output sent to browser
DEBUG - 2023-07-26 08:59:36 --> Total execution time: 0.0449
INFO - 2023-07-26 08:59:36 --> Config Class Initialized
INFO - 2023-07-26 08:59:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:59:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:59:36 --> Utf8 Class Initialized
INFO - 2023-07-26 08:59:36 --> URI Class Initialized
INFO - 2023-07-26 08:59:36 --> Router Class Initialized
INFO - 2023-07-26 08:59:36 --> Output Class Initialized
INFO - 2023-07-26 08:59:36 --> Security Class Initialized
DEBUG - 2023-07-26 08:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:59:36 --> Input Class Initialized
INFO - 2023-07-26 08:59:36 --> Language Class Initialized
INFO - 2023-07-26 08:59:36 --> Loader Class Initialized
INFO - 2023-07-26 08:59:36 --> Helper loaded: url_helper
INFO - 2023-07-26 08:59:36 --> Helper loaded: form_helper
INFO - 2023-07-26 08:59:36 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:59:36 --> Controller Class Initialized
DEBUG - 2023-07-26 08:59:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:36 --> Database Driver Class Initialized
INFO - 2023-07-26 08:59:36 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:59:36 --> Model "Student_model" initialized
INFO - 2023-07-26 08:59:36 --> Model "Teacher_model" initialized
ERROR - 2023-07-26 08:59:36 --> Severity: Notice --> Undefined variable: teacher_email C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 82
INFO - 2023-07-26 08:59:36 --> Final output sent to browser
DEBUG - 2023-07-26 08:59:36 --> Total execution time: 0.0419
INFO - 2023-07-26 08:59:36 --> Config Class Initialized
INFO - 2023-07-26 08:59:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:59:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:59:36 --> Utf8 Class Initialized
INFO - 2023-07-26 08:59:36 --> URI Class Initialized
INFO - 2023-07-26 08:59:36 --> Router Class Initialized
INFO - 2023-07-26 08:59:36 --> Output Class Initialized
INFO - 2023-07-26 08:59:36 --> Security Class Initialized
DEBUG - 2023-07-26 08:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:59:36 --> Input Class Initialized
INFO - 2023-07-26 08:59:36 --> Language Class Initialized
INFO - 2023-07-26 08:59:36 --> Loader Class Initialized
INFO - 2023-07-26 08:59:36 --> Helper loaded: url_helper
INFO - 2023-07-26 08:59:36 --> Helper loaded: form_helper
INFO - 2023-07-26 08:59:36 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:59:36 --> Controller Class Initialized
DEBUG - 2023-07-26 08:59:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:36 --> Database Driver Class Initialized
INFO - 2023-07-26 08:59:36 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:59:36 --> Model "Student_model" initialized
INFO - 2023-07-26 08:59:36 --> Model "Teacher_model" initialized
ERROR - 2023-07-26 08:59:36 --> Severity: Notice --> Undefined variable: teacher_email C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 82
INFO - 2023-07-26 08:59:36 --> Final output sent to browser
DEBUG - 2023-07-26 08:59:36 --> Total execution time: 0.0423
INFO - 2023-07-26 08:59:56 --> Config Class Initialized
INFO - 2023-07-26 08:59:56 --> Hooks Class Initialized
DEBUG - 2023-07-26 08:59:56 --> UTF-8 Support Enabled
INFO - 2023-07-26 08:59:56 --> Utf8 Class Initialized
INFO - 2023-07-26 08:59:56 --> URI Class Initialized
INFO - 2023-07-26 08:59:56 --> Router Class Initialized
INFO - 2023-07-26 08:59:56 --> Output Class Initialized
INFO - 2023-07-26 08:59:56 --> Security Class Initialized
DEBUG - 2023-07-26 08:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 08:59:56 --> Input Class Initialized
INFO - 2023-07-26 08:59:56 --> Language Class Initialized
INFO - 2023-07-26 08:59:56 --> Loader Class Initialized
INFO - 2023-07-26 08:59:56 --> Helper loaded: url_helper
INFO - 2023-07-26 08:59:56 --> Helper loaded: form_helper
INFO - 2023-07-26 08:59:56 --> Form Validation Class Initialized
DEBUG - 2023-07-26 08:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 08:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 08:59:56 --> Controller Class Initialized
DEBUG - 2023-07-26 08:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 08:59:56 --> Database Driver Class Initialized
INFO - 2023-07-26 08:59:56 --> Model "Admin_model" initialized
INFO - 2023-07-26 08:59:56 --> Model "Student_model" initialized
INFO - 2023-07-26 08:59:56 --> Model "Teacher_model" initialized
ERROR - 2023-07-26 08:59:56 --> Severity: Notice --> Undefined variable: teacher_email C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 82
INFO - 2023-07-26 08:59:56 --> Final output sent to browser
DEBUG - 2023-07-26 08:59:56 --> Total execution time: 0.0496
INFO - 2023-07-26 09:01:51 --> Config Class Initialized
INFO - 2023-07-26 09:01:51 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:01:51 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:01:51 --> Utf8 Class Initialized
INFO - 2023-07-26 09:01:51 --> URI Class Initialized
INFO - 2023-07-26 09:01:51 --> Router Class Initialized
INFO - 2023-07-26 09:01:51 --> Output Class Initialized
INFO - 2023-07-26 09:01:51 --> Security Class Initialized
DEBUG - 2023-07-26 09:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:01:51 --> Input Class Initialized
INFO - 2023-07-26 09:01:51 --> Language Class Initialized
INFO - 2023-07-26 09:01:51 --> Loader Class Initialized
INFO - 2023-07-26 09:01:51 --> Helper loaded: url_helper
INFO - 2023-07-26 09:01:51 --> Helper loaded: form_helper
INFO - 2023-07-26 09:01:51 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:01:51 --> Controller Class Initialized
DEBUG - 2023-07-26 09:01:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:01:51 --> Database Driver Class Initialized
INFO - 2023-07-26 09:01:51 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:01:51 --> Model "Student_model" initialized
INFO - 2023-07-26 09:01:51 --> Model "Teacher_model" initialized
ERROR - 2023-07-26 09:01:51 --> Severity: Notice --> Undefined property: stdClass::$teacher_id C:\xampp\htdocs\Project\application\views\admin\edit_teacher.php 13
ERROR - 2023-07-26 09:01:51 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\Project\application\views\admin\edit_teacher.php 21
INFO - 2023-07-26 09:01:51 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:01:51 --> Final output sent to browser
DEBUG - 2023-07-26 09:01:51 --> Total execution time: 0.0355
INFO - 2023-07-26 09:05:32 --> Config Class Initialized
INFO - 2023-07-26 09:05:32 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:05:32 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:05:32 --> Utf8 Class Initialized
INFO - 2023-07-26 09:05:32 --> URI Class Initialized
INFO - 2023-07-26 09:05:32 --> Router Class Initialized
INFO - 2023-07-26 09:05:32 --> Output Class Initialized
INFO - 2023-07-26 09:05:32 --> Security Class Initialized
DEBUG - 2023-07-26 09:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:05:32 --> Input Class Initialized
INFO - 2023-07-26 09:05:32 --> Language Class Initialized
INFO - 2023-07-26 09:05:32 --> Loader Class Initialized
INFO - 2023-07-26 09:05:32 --> Helper loaded: url_helper
INFO - 2023-07-26 09:05:32 --> Helper loaded: form_helper
INFO - 2023-07-26 09:05:32 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:05:32 --> Controller Class Initialized
DEBUG - 2023-07-26 09:05:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:05:32 --> Database Driver Class Initialized
INFO - 2023-07-26 09:05:32 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:05:32 --> Model "Student_model" initialized
INFO - 2023-07-26 09:05:32 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:05:32 --> Config Class Initialized
INFO - 2023-07-26 09:05:32 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:05:32 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:05:32 --> Utf8 Class Initialized
INFO - 2023-07-26 09:05:32 --> URI Class Initialized
INFO - 2023-07-26 09:05:32 --> Router Class Initialized
INFO - 2023-07-26 09:05:32 --> Output Class Initialized
INFO - 2023-07-26 09:05:32 --> Security Class Initialized
DEBUG - 2023-07-26 09:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:05:32 --> Input Class Initialized
INFO - 2023-07-26 09:05:32 --> Language Class Initialized
ERROR - 2023-07-26 09:05:32 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 09:06:20 --> Config Class Initialized
INFO - 2023-07-26 09:06:20 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:06:20 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:06:20 --> Utf8 Class Initialized
INFO - 2023-07-26 09:06:20 --> URI Class Initialized
INFO - 2023-07-26 09:06:20 --> Router Class Initialized
INFO - 2023-07-26 09:06:20 --> Output Class Initialized
INFO - 2023-07-26 09:06:20 --> Security Class Initialized
DEBUG - 2023-07-26 09:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:06:20 --> Input Class Initialized
INFO - 2023-07-26 09:06:20 --> Language Class Initialized
ERROR - 2023-07-26 09:06:20 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 09:06:20 --> Config Class Initialized
INFO - 2023-07-26 09:06:20 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:06:20 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:06:20 --> Utf8 Class Initialized
INFO - 2023-07-26 09:06:20 --> URI Class Initialized
INFO - 2023-07-26 09:06:20 --> Router Class Initialized
INFO - 2023-07-26 09:06:20 --> Output Class Initialized
INFO - 2023-07-26 09:06:20 --> Security Class Initialized
DEBUG - 2023-07-26 09:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:06:20 --> Input Class Initialized
INFO - 2023-07-26 09:06:20 --> Language Class Initialized
ERROR - 2023-07-26 09:06:20 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 09:06:21 --> Config Class Initialized
INFO - 2023-07-26 09:06:21 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:06:21 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:06:21 --> Utf8 Class Initialized
INFO - 2023-07-26 09:06:21 --> URI Class Initialized
INFO - 2023-07-26 09:06:21 --> Router Class Initialized
INFO - 2023-07-26 09:06:21 --> Output Class Initialized
INFO - 2023-07-26 09:06:21 --> Security Class Initialized
DEBUG - 2023-07-26 09:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:06:21 --> Input Class Initialized
INFO - 2023-07-26 09:06:21 --> Language Class Initialized
ERROR - 2023-07-26 09:06:21 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 09:06:21 --> Config Class Initialized
INFO - 2023-07-26 09:06:21 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:06:21 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:06:21 --> Utf8 Class Initialized
INFO - 2023-07-26 09:06:21 --> URI Class Initialized
INFO - 2023-07-26 09:06:21 --> Router Class Initialized
INFO - 2023-07-26 09:06:21 --> Output Class Initialized
INFO - 2023-07-26 09:06:21 --> Security Class Initialized
DEBUG - 2023-07-26 09:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:06:21 --> Input Class Initialized
INFO - 2023-07-26 09:06:21 --> Language Class Initialized
ERROR - 2023-07-26 09:06:21 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 09:06:21 --> Config Class Initialized
INFO - 2023-07-26 09:06:21 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:06:21 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:06:21 --> Utf8 Class Initialized
INFO - 2023-07-26 09:06:21 --> URI Class Initialized
INFO - 2023-07-26 09:06:21 --> Router Class Initialized
INFO - 2023-07-26 09:06:21 --> Output Class Initialized
INFO - 2023-07-26 09:06:21 --> Security Class Initialized
DEBUG - 2023-07-26 09:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:06:21 --> Input Class Initialized
INFO - 2023-07-26 09:06:21 --> Language Class Initialized
ERROR - 2023-07-26 09:06:21 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 09:06:21 --> Config Class Initialized
INFO - 2023-07-26 09:06:21 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:06:21 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:06:21 --> Utf8 Class Initialized
INFO - 2023-07-26 09:06:21 --> URI Class Initialized
INFO - 2023-07-26 09:06:21 --> Router Class Initialized
INFO - 2023-07-26 09:06:21 --> Output Class Initialized
INFO - 2023-07-26 09:06:21 --> Security Class Initialized
DEBUG - 2023-07-26 09:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:06:21 --> Input Class Initialized
INFO - 2023-07-26 09:06:21 --> Language Class Initialized
ERROR - 2023-07-26 09:06:21 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 09:06:21 --> Config Class Initialized
INFO - 2023-07-26 09:06:21 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:06:21 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:06:21 --> Utf8 Class Initialized
INFO - 2023-07-26 09:06:21 --> URI Class Initialized
INFO - 2023-07-26 09:06:21 --> Router Class Initialized
INFO - 2023-07-26 09:06:21 --> Output Class Initialized
INFO - 2023-07-26 09:06:21 --> Security Class Initialized
DEBUG - 2023-07-26 09:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:06:21 --> Input Class Initialized
INFO - 2023-07-26 09:06:21 --> Language Class Initialized
ERROR - 2023-07-26 09:06:21 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 09:06:47 --> Config Class Initialized
INFO - 2023-07-26 09:06:47 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:06:47 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:06:47 --> Utf8 Class Initialized
INFO - 2023-07-26 09:07:22 --> Config Class Initialized
INFO - 2023-07-26 09:07:22 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:07:22 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:07:22 --> Utf8 Class Initialized
INFO - 2023-07-26 09:07:22 --> URI Class Initialized
INFO - 2023-07-26 09:07:22 --> Router Class Initialized
INFO - 2023-07-26 09:07:22 --> Output Class Initialized
INFO - 2023-07-26 09:07:22 --> Security Class Initialized
DEBUG - 2023-07-26 09:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:07:22 --> Input Class Initialized
INFO - 2023-07-26 09:07:22 --> Language Class Initialized
ERROR - 2023-07-26 09:07:22 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 09:07:23 --> Config Class Initialized
INFO - 2023-07-26 09:07:23 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:07:23 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:07:23 --> Utf8 Class Initialized
INFO - 2023-07-26 09:07:23 --> URI Class Initialized
INFO - 2023-07-26 09:07:23 --> Router Class Initialized
INFO - 2023-07-26 09:07:23 --> Output Class Initialized
INFO - 2023-07-26 09:07:23 --> Security Class Initialized
DEBUG - 2023-07-26 09:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:07:23 --> Input Class Initialized
INFO - 2023-07-26 09:07:23 --> Language Class Initialized
ERROR - 2023-07-26 09:07:23 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 09:07:23 --> Config Class Initialized
INFO - 2023-07-26 09:07:23 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:07:23 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:07:23 --> Utf8 Class Initialized
INFO - 2023-07-26 09:07:23 --> URI Class Initialized
INFO - 2023-07-26 09:07:23 --> Router Class Initialized
INFO - 2023-07-26 09:07:23 --> Output Class Initialized
INFO - 2023-07-26 09:07:23 --> Security Class Initialized
DEBUG - 2023-07-26 09:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:07:23 --> Input Class Initialized
INFO - 2023-07-26 09:07:23 --> Language Class Initialized
ERROR - 2023-07-26 09:07:23 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 09:13:49 --> Config Class Initialized
INFO - 2023-07-26 09:13:49 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:13:49 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:13:49 --> Utf8 Class Initialized
INFO - 2023-07-26 09:13:49 --> URI Class Initialized
INFO - 2023-07-26 09:13:49 --> Router Class Initialized
INFO - 2023-07-26 09:13:49 --> Output Class Initialized
INFO - 2023-07-26 09:13:49 --> Security Class Initialized
DEBUG - 2023-07-26 09:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:13:49 --> Input Class Initialized
INFO - 2023-07-26 09:13:49 --> Language Class Initialized
ERROR - 2023-07-26 09:13:49 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 09:14:01 --> Config Class Initialized
INFO - 2023-07-26 09:14:01 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:14:01 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:14:01 --> Utf8 Class Initialized
INFO - 2023-07-26 09:14:01 --> URI Class Initialized
DEBUG - 2023-07-26 09:14:01 --> No URI present. Default controller set.
INFO - 2023-07-26 09:14:01 --> Router Class Initialized
INFO - 2023-07-26 09:14:01 --> Output Class Initialized
INFO - 2023-07-26 09:14:01 --> Security Class Initialized
DEBUG - 2023-07-26 09:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:14:01 --> Input Class Initialized
INFO - 2023-07-26 09:14:01 --> Language Class Initialized
INFO - 2023-07-26 09:14:01 --> Loader Class Initialized
INFO - 2023-07-26 09:14:01 --> Helper loaded: url_helper
INFO - 2023-07-26 09:14:01 --> Helper loaded: form_helper
INFO - 2023-07-26 09:14:01 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:14:01 --> Controller Class Initialized
INFO - 2023-07-26 09:14:01 --> Database Driver Class Initialized
INFO - 2023-07-26 09:14:01 --> Model "Student_model" initialized
DEBUG - 2023-07-26 09:14:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:14:01 --> File loaded: C:\xampp\htdocs\Project\application\views\register.php
INFO - 2023-07-26 09:14:01 --> Final output sent to browser
DEBUG - 2023-07-26 09:14:01 --> Total execution time: 0.0825
INFO - 2023-07-26 09:14:04 --> Config Class Initialized
INFO - 2023-07-26 09:14:04 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:14:04 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:14:04 --> Utf8 Class Initialized
INFO - 2023-07-26 09:14:04 --> URI Class Initialized
INFO - 2023-07-26 09:14:04 --> Router Class Initialized
INFO - 2023-07-26 09:14:04 --> Output Class Initialized
INFO - 2023-07-26 09:14:04 --> Security Class Initialized
DEBUG - 2023-07-26 09:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:14:04 --> Input Class Initialized
INFO - 2023-07-26 09:14:04 --> Language Class Initialized
INFO - 2023-07-26 09:14:04 --> Loader Class Initialized
INFO - 2023-07-26 09:14:04 --> Helper loaded: url_helper
INFO - 2023-07-26 09:14:04 --> Helper loaded: form_helper
INFO - 2023-07-26 09:14:04 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:14:04 --> Controller Class Initialized
DEBUG - 2023-07-26 09:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:14:04 --> Database Driver Class Initialized
INFO - 2023-07-26 09:14:04 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:14:04 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/login.php
INFO - 2023-07-26 09:14:04 --> Final output sent to browser
DEBUG - 2023-07-26 09:14:04 --> Total execution time: 0.0362
INFO - 2023-07-26 09:14:11 --> Config Class Initialized
INFO - 2023-07-26 09:14:11 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:14:11 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:14:11 --> Utf8 Class Initialized
INFO - 2023-07-26 09:14:11 --> URI Class Initialized
INFO - 2023-07-26 09:14:11 --> Router Class Initialized
INFO - 2023-07-26 09:14:11 --> Output Class Initialized
INFO - 2023-07-26 09:14:11 --> Security Class Initialized
DEBUG - 2023-07-26 09:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:14:11 --> Input Class Initialized
INFO - 2023-07-26 09:14:11 --> Language Class Initialized
INFO - 2023-07-26 09:14:11 --> Loader Class Initialized
INFO - 2023-07-26 09:14:11 --> Helper loaded: url_helper
INFO - 2023-07-26 09:14:11 --> Helper loaded: form_helper
INFO - 2023-07-26 09:14:11 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:14:11 --> Controller Class Initialized
DEBUG - 2023-07-26 09:14:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:14:11 --> Database Driver Class Initialized
INFO - 2023-07-26 09:14:11 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:14:11 --> Config Class Initialized
INFO - 2023-07-26 09:14:11 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:14:11 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:14:11 --> Utf8 Class Initialized
INFO - 2023-07-26 09:14:11 --> URI Class Initialized
INFO - 2023-07-26 09:14:11 --> Router Class Initialized
INFO - 2023-07-26 09:14:11 --> Output Class Initialized
INFO - 2023-07-26 09:14:11 --> Security Class Initialized
DEBUG - 2023-07-26 09:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:14:11 --> Input Class Initialized
INFO - 2023-07-26 09:14:11 --> Language Class Initialized
INFO - 2023-07-26 09:14:11 --> Loader Class Initialized
INFO - 2023-07-26 09:14:11 --> Helper loaded: url_helper
INFO - 2023-07-26 09:14:11 --> Helper loaded: form_helper
INFO - 2023-07-26 09:14:11 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:14:11 --> Controller Class Initialized
DEBUG - 2023-07-26 09:14:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:14:11 --> Database Driver Class Initialized
INFO - 2023-07-26 09:14:11 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:14:11 --> Model "Student_model" initialized
INFO - 2023-07-26 09:14:11 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:14:11 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/dashboard.php
INFO - 2023-07-26 09:14:11 --> Final output sent to browser
DEBUG - 2023-07-26 09:14:11 --> Total execution time: 0.0400
INFO - 2023-07-26 09:14:13 --> Config Class Initialized
INFO - 2023-07-26 09:14:13 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:14:13 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:14:13 --> Utf8 Class Initialized
INFO - 2023-07-26 09:14:13 --> URI Class Initialized
INFO - 2023-07-26 09:14:13 --> Router Class Initialized
INFO - 2023-07-26 09:14:13 --> Output Class Initialized
INFO - 2023-07-26 09:14:13 --> Security Class Initialized
DEBUG - 2023-07-26 09:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:14:13 --> Input Class Initialized
INFO - 2023-07-26 09:14:13 --> Language Class Initialized
INFO - 2023-07-26 09:14:13 --> Loader Class Initialized
INFO - 2023-07-26 09:14:13 --> Helper loaded: url_helper
INFO - 2023-07-26 09:14:13 --> Helper loaded: form_helper
INFO - 2023-07-26 09:14:13 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:14:13 --> Controller Class Initialized
DEBUG - 2023-07-26 09:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:14:13 --> Database Driver Class Initialized
INFO - 2023-07-26 09:14:13 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:14:13 --> Model "Student_model" initialized
INFO - 2023-07-26 09:14:13 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:14:17 --> Config Class Initialized
INFO - 2023-07-26 09:14:17 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:14:17 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:14:17 --> Utf8 Class Initialized
INFO - 2023-07-26 09:14:17 --> URI Class Initialized
INFO - 2023-07-26 09:14:17 --> Router Class Initialized
INFO - 2023-07-26 09:14:17 --> Output Class Initialized
INFO - 2023-07-26 09:14:17 --> Security Class Initialized
DEBUG - 2023-07-26 09:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:14:17 --> Input Class Initialized
INFO - 2023-07-26 09:14:17 --> Language Class Initialized
INFO - 2023-07-26 09:14:17 --> Loader Class Initialized
INFO - 2023-07-26 09:14:17 --> Helper loaded: url_helper
INFO - 2023-07-26 09:14:17 --> Helper loaded: form_helper
INFO - 2023-07-26 09:14:17 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:14:17 --> Controller Class Initialized
DEBUG - 2023-07-26 09:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:14:17 --> Database Driver Class Initialized
INFO - 2023-07-26 09:14:17 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:14:17 --> Model "Student_model" initialized
INFO - 2023-07-26 09:14:17 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:14:17 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/dashboard.php
INFO - 2023-07-26 09:14:17 --> Final output sent to browser
DEBUG - 2023-07-26 09:14:17 --> Total execution time: 0.0848
INFO - 2023-07-26 09:17:01 --> Config Class Initialized
INFO - 2023-07-26 09:17:01 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:17:01 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:17:01 --> Utf8 Class Initialized
INFO - 2023-07-26 09:17:01 --> URI Class Initialized
INFO - 2023-07-26 09:17:01 --> Router Class Initialized
INFO - 2023-07-26 09:17:01 --> Output Class Initialized
INFO - 2023-07-26 09:17:01 --> Security Class Initialized
DEBUG - 2023-07-26 09:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:17:01 --> Input Class Initialized
INFO - 2023-07-26 09:17:01 --> Language Class Initialized
INFO - 2023-07-26 09:17:01 --> Loader Class Initialized
INFO - 2023-07-26 09:17:01 --> Helper loaded: url_helper
INFO - 2023-07-26 09:17:01 --> Helper loaded: form_helper
INFO - 2023-07-26 09:17:01 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:17:01 --> Controller Class Initialized
DEBUG - 2023-07-26 09:17:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:17:02 --> Database Driver Class Initialized
INFO - 2023-07-26 09:17:02 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:17:02 --> Model "Student_model" initialized
INFO - 2023-07-26 09:17:02 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:17:02 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/dashboard.php
INFO - 2023-07-26 09:17:02 --> Final output sent to browser
DEBUG - 2023-07-26 09:17:02 --> Total execution time: 0.0372
INFO - 2023-07-26 09:17:02 --> Config Class Initialized
INFO - 2023-07-26 09:17:02 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:17:02 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:17:02 --> Utf8 Class Initialized
INFO - 2023-07-26 09:17:02 --> URI Class Initialized
INFO - 2023-07-26 09:17:02 --> Router Class Initialized
INFO - 2023-07-26 09:17:02 --> Output Class Initialized
INFO - 2023-07-26 09:17:02 --> Security Class Initialized
DEBUG - 2023-07-26 09:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:17:02 --> Input Class Initialized
INFO - 2023-07-26 09:17:02 --> Language Class Initialized
INFO - 2023-07-26 09:17:02 --> Loader Class Initialized
INFO - 2023-07-26 09:17:02 --> Helper loaded: url_helper
INFO - 2023-07-26 09:17:02 --> Helper loaded: form_helper
INFO - 2023-07-26 09:17:02 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:17:02 --> Controller Class Initialized
DEBUG - 2023-07-26 09:17:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:17:02 --> Database Driver Class Initialized
INFO - 2023-07-26 09:17:02 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:17:02 --> Model "Student_model" initialized
INFO - 2023-07-26 09:17:02 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:17:02 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:17:02 --> Final output sent to browser
DEBUG - 2023-07-26 09:17:02 --> Total execution time: 0.0362
INFO - 2023-07-26 09:20:10 --> Config Class Initialized
INFO - 2023-07-26 09:20:10 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:20:10 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:20:10 --> Utf8 Class Initialized
INFO - 2023-07-26 09:20:10 --> URI Class Initialized
INFO - 2023-07-26 09:20:10 --> Router Class Initialized
INFO - 2023-07-26 09:20:10 --> Output Class Initialized
INFO - 2023-07-26 09:20:10 --> Security Class Initialized
DEBUG - 2023-07-26 09:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:20:10 --> Input Class Initialized
INFO - 2023-07-26 09:20:10 --> Language Class Initialized
INFO - 2023-07-26 09:20:10 --> Loader Class Initialized
INFO - 2023-07-26 09:20:10 --> Helper loaded: url_helper
INFO - 2023-07-26 09:20:10 --> Helper loaded: form_helper
INFO - 2023-07-26 09:20:10 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:20:10 --> Controller Class Initialized
DEBUG - 2023-07-26 09:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:20:10 --> Database Driver Class Initialized
INFO - 2023-07-26 09:20:10 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:20:10 --> Model "Student_model" initialized
INFO - 2023-07-26 09:20:10 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:20:10 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:20:10 --> Final output sent to browser
DEBUG - 2023-07-26 09:20:10 --> Total execution time: 0.0327
INFO - 2023-07-26 09:20:12 --> Config Class Initialized
INFO - 2023-07-26 09:20:12 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:20:12 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:20:12 --> Utf8 Class Initialized
INFO - 2023-07-26 09:20:14 --> Config Class Initialized
INFO - 2023-07-26 09:20:14 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:20:14 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:20:14 --> Utf8 Class Initialized
INFO - 2023-07-26 09:20:14 --> URI Class Initialized
INFO - 2023-07-26 09:20:14 --> Router Class Initialized
INFO - 2023-07-26 09:20:14 --> Output Class Initialized
INFO - 2023-07-26 09:20:14 --> Security Class Initialized
DEBUG - 2023-07-26 09:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:20:14 --> Input Class Initialized
INFO - 2023-07-26 09:20:14 --> Language Class Initialized
INFO - 2023-07-26 09:20:14 --> Loader Class Initialized
INFO - 2023-07-26 09:20:14 --> Helper loaded: url_helper
INFO - 2023-07-26 09:20:14 --> Helper loaded: form_helper
INFO - 2023-07-26 09:20:14 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:20:14 --> Controller Class Initialized
DEBUG - 2023-07-26 09:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:20:14 --> Database Driver Class Initialized
INFO - 2023-07-26 09:20:14 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:20:14 --> Model "Student_model" initialized
INFO - 2023-07-26 09:20:14 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:20:14 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:20:14 --> Final output sent to browser
DEBUG - 2023-07-26 09:20:14 --> Total execution time: 0.0486
INFO - 2023-07-26 09:20:16 --> Config Class Initialized
INFO - 2023-07-26 09:20:16 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:20:16 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:20:16 --> Utf8 Class Initialized
INFO - 2023-07-26 09:20:17 --> Config Class Initialized
INFO - 2023-07-26 09:20:17 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:20:17 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:20:17 --> Utf8 Class Initialized
INFO - 2023-07-26 09:20:17 --> URI Class Initialized
INFO - 2023-07-26 09:20:17 --> Router Class Initialized
INFO - 2023-07-26 09:20:17 --> Output Class Initialized
INFO - 2023-07-26 09:20:17 --> Security Class Initialized
DEBUG - 2023-07-26 09:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:20:17 --> Input Class Initialized
INFO - 2023-07-26 09:20:17 --> Language Class Initialized
INFO - 2023-07-26 09:20:17 --> Loader Class Initialized
INFO - 2023-07-26 09:20:17 --> Helper loaded: url_helper
INFO - 2023-07-26 09:20:17 --> Helper loaded: form_helper
INFO - 2023-07-26 09:20:17 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:20:17 --> Controller Class Initialized
DEBUG - 2023-07-26 09:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:20:17 --> Database Driver Class Initialized
INFO - 2023-07-26 09:20:17 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:20:17 --> Model "Student_model" initialized
INFO - 2023-07-26 09:20:17 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:20:17 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:20:17 --> Final output sent to browser
DEBUG - 2023-07-26 09:20:17 --> Total execution time: 0.0427
INFO - 2023-07-26 09:20:20 --> Config Class Initialized
INFO - 2023-07-26 09:20:20 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:20:20 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:20:20 --> Utf8 Class Initialized
INFO - 2023-07-26 09:21:22 --> Config Class Initialized
INFO - 2023-07-26 09:21:22 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:21:22 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:21:22 --> Utf8 Class Initialized
INFO - 2023-07-26 09:21:22 --> URI Class Initialized
INFO - 2023-07-26 09:21:22 --> Router Class Initialized
INFO - 2023-07-26 09:21:22 --> Output Class Initialized
INFO - 2023-07-26 09:21:22 --> Security Class Initialized
DEBUG - 2023-07-26 09:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:21:22 --> Input Class Initialized
INFO - 2023-07-26 09:21:22 --> Language Class Initialized
INFO - 2023-07-26 09:21:22 --> Loader Class Initialized
INFO - 2023-07-26 09:21:22 --> Helper loaded: url_helper
INFO - 2023-07-26 09:21:22 --> Helper loaded: form_helper
INFO - 2023-07-26 09:21:22 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:21:22 --> Controller Class Initialized
DEBUG - 2023-07-26 09:21:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:21:22 --> Database Driver Class Initialized
INFO - 2023-07-26 09:21:22 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:21:22 --> Model "Student_model" initialized
INFO - 2023-07-26 09:21:22 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:21:22 --> Config Class Initialized
INFO - 2023-07-26 09:21:22 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:21:22 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:21:22 --> Utf8 Class Initialized
INFO - 2023-07-26 09:21:22 --> URI Class Initialized
INFO - 2023-07-26 09:21:22 --> Router Class Initialized
INFO - 2023-07-26 09:21:22 --> Output Class Initialized
INFO - 2023-07-26 09:21:22 --> Security Class Initialized
DEBUG - 2023-07-26 09:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:21:22 --> Input Class Initialized
INFO - 2023-07-26 09:21:22 --> Language Class Initialized
INFO - 2023-07-26 09:21:22 --> Loader Class Initialized
INFO - 2023-07-26 09:21:22 --> Helper loaded: url_helper
INFO - 2023-07-26 09:21:22 --> Helper loaded: form_helper
INFO - 2023-07-26 09:21:22 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:21:22 --> Controller Class Initialized
DEBUG - 2023-07-26 09:21:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:21:22 --> Database Driver Class Initialized
INFO - 2023-07-26 09:21:22 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:21:22 --> Model "Student_model" initialized
INFO - 2023-07-26 09:21:22 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:24:35 --> Config Class Initialized
INFO - 2023-07-26 09:24:35 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:24:35 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:24:35 --> Utf8 Class Initialized
INFO - 2023-07-26 09:24:35 --> URI Class Initialized
INFO - 2023-07-26 09:24:35 --> Router Class Initialized
INFO - 2023-07-26 09:24:35 --> Output Class Initialized
INFO - 2023-07-26 09:24:35 --> Security Class Initialized
DEBUG - 2023-07-26 09:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:24:35 --> Input Class Initialized
INFO - 2023-07-26 09:24:35 --> Language Class Initialized
INFO - 2023-07-26 09:24:35 --> Loader Class Initialized
INFO - 2023-07-26 09:24:35 --> Helper loaded: url_helper
INFO - 2023-07-26 09:24:35 --> Helper loaded: form_helper
INFO - 2023-07-26 09:24:35 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:24:35 --> Controller Class Initialized
DEBUG - 2023-07-26 09:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:24:35 --> Database Driver Class Initialized
INFO - 2023-07-26 09:24:35 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:24:35 --> Model "Student_model" initialized
INFO - 2023-07-26 09:24:35 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:24:36 --> Config Class Initialized
INFO - 2023-07-26 09:24:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:24:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:24:36 --> Utf8 Class Initialized
INFO - 2023-07-26 09:24:36 --> URI Class Initialized
INFO - 2023-07-26 09:24:36 --> Router Class Initialized
INFO - 2023-07-26 09:24:36 --> Output Class Initialized
INFO - 2023-07-26 09:24:36 --> Security Class Initialized
DEBUG - 2023-07-26 09:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:24:36 --> Input Class Initialized
INFO - 2023-07-26 09:24:36 --> Language Class Initialized
INFO - 2023-07-26 09:24:36 --> Loader Class Initialized
INFO - 2023-07-26 09:24:36 --> Helper loaded: url_helper
INFO - 2023-07-26 09:24:36 --> Helper loaded: form_helper
INFO - 2023-07-26 09:24:36 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:24:36 --> Controller Class Initialized
DEBUG - 2023-07-26 09:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:24:36 --> Database Driver Class Initialized
INFO - 2023-07-26 09:24:36 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:24:36 --> Model "Student_model" initialized
INFO - 2023-07-26 09:24:36 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:24:36 --> Config Class Initialized
INFO - 2023-07-26 09:24:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:24:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:24:36 --> Utf8 Class Initialized
INFO - 2023-07-26 09:24:36 --> URI Class Initialized
INFO - 2023-07-26 09:24:36 --> Router Class Initialized
INFO - 2023-07-26 09:24:36 --> Output Class Initialized
INFO - 2023-07-26 09:24:36 --> Security Class Initialized
DEBUG - 2023-07-26 09:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:24:36 --> Input Class Initialized
INFO - 2023-07-26 09:24:36 --> Language Class Initialized
INFO - 2023-07-26 09:24:36 --> Loader Class Initialized
INFO - 2023-07-26 09:24:36 --> Helper loaded: url_helper
INFO - 2023-07-26 09:24:36 --> Helper loaded: form_helper
INFO - 2023-07-26 09:24:36 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:24:36 --> Controller Class Initialized
DEBUG - 2023-07-26 09:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:24:36 --> Database Driver Class Initialized
INFO - 2023-07-26 09:24:36 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:24:36 --> Model "Student_model" initialized
INFO - 2023-07-26 09:24:36 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:24:36 --> Config Class Initialized
INFO - 2023-07-26 09:24:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:24:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:24:36 --> Utf8 Class Initialized
INFO - 2023-07-26 09:24:36 --> URI Class Initialized
INFO - 2023-07-26 09:24:36 --> Router Class Initialized
INFO - 2023-07-26 09:24:36 --> Output Class Initialized
INFO - 2023-07-26 09:24:36 --> Security Class Initialized
DEBUG - 2023-07-26 09:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:24:36 --> Input Class Initialized
INFO - 2023-07-26 09:24:36 --> Language Class Initialized
INFO - 2023-07-26 09:24:36 --> Loader Class Initialized
INFO - 2023-07-26 09:24:36 --> Helper loaded: url_helper
INFO - 2023-07-26 09:24:36 --> Helper loaded: form_helper
INFO - 2023-07-26 09:24:36 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:24:36 --> Controller Class Initialized
DEBUG - 2023-07-26 09:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:24:36 --> Database Driver Class Initialized
INFO - 2023-07-26 09:24:36 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:24:36 --> Model "Student_model" initialized
INFO - 2023-07-26 09:24:36 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:24:51 --> Config Class Initialized
INFO - 2023-07-26 09:24:51 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:24:51 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:24:51 --> Utf8 Class Initialized
INFO - 2023-07-26 09:24:51 --> URI Class Initialized
INFO - 2023-07-26 09:24:51 --> Router Class Initialized
INFO - 2023-07-26 09:24:51 --> Output Class Initialized
INFO - 2023-07-26 09:24:51 --> Security Class Initialized
DEBUG - 2023-07-26 09:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:24:51 --> Input Class Initialized
INFO - 2023-07-26 09:24:51 --> Language Class Initialized
INFO - 2023-07-26 09:24:51 --> Loader Class Initialized
INFO - 2023-07-26 09:24:51 --> Helper loaded: url_helper
INFO - 2023-07-26 09:24:51 --> Helper loaded: form_helper
INFO - 2023-07-26 09:24:51 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:24:51 --> Controller Class Initialized
DEBUG - 2023-07-26 09:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:24:51 --> Database Driver Class Initialized
INFO - 2023-07-26 09:24:51 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:24:51 --> Model "Student_model" initialized
INFO - 2023-07-26 09:24:51 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:24:52 --> Config Class Initialized
INFO - 2023-07-26 09:24:52 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:24:52 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:24:52 --> Utf8 Class Initialized
INFO - 2023-07-26 09:24:52 --> URI Class Initialized
INFO - 2023-07-26 09:24:52 --> Router Class Initialized
INFO - 2023-07-26 09:24:52 --> Output Class Initialized
INFO - 2023-07-26 09:24:52 --> Security Class Initialized
DEBUG - 2023-07-26 09:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:24:52 --> Input Class Initialized
INFO - 2023-07-26 09:24:52 --> Language Class Initialized
INFO - 2023-07-26 09:24:52 --> Loader Class Initialized
INFO - 2023-07-26 09:24:52 --> Helper loaded: url_helper
INFO - 2023-07-26 09:24:52 --> Helper loaded: form_helper
INFO - 2023-07-26 09:24:52 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:24:52 --> Controller Class Initialized
DEBUG - 2023-07-26 09:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:24:52 --> Database Driver Class Initialized
INFO - 2023-07-26 09:24:52 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:24:52 --> Model "Student_model" initialized
INFO - 2023-07-26 09:24:52 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:28:29 --> Config Class Initialized
INFO - 2023-07-26 09:28:29 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:28:29 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:28:29 --> Utf8 Class Initialized
INFO - 2023-07-26 09:28:29 --> URI Class Initialized
INFO - 2023-07-26 09:28:29 --> Router Class Initialized
INFO - 2023-07-26 09:28:29 --> Output Class Initialized
INFO - 2023-07-26 09:28:29 --> Security Class Initialized
DEBUG - 2023-07-26 09:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:28:29 --> Input Class Initialized
INFO - 2023-07-26 09:28:29 --> Language Class Initialized
INFO - 2023-07-26 09:28:29 --> Loader Class Initialized
INFO - 2023-07-26 09:28:29 --> Helper loaded: url_helper
INFO - 2023-07-26 09:28:29 --> Helper loaded: form_helper
INFO - 2023-07-26 09:28:29 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:28:29 --> Controller Class Initialized
DEBUG - 2023-07-26 09:28:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:28:29 --> Database Driver Class Initialized
INFO - 2023-07-26 09:28:29 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:28:29 --> Model "Student_model" initialized
INFO - 2023-07-26 09:28:29 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:28:29 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:28:29 --> Final output sent to browser
DEBUG - 2023-07-26 09:28:29 --> Total execution time: 0.0423
INFO - 2023-07-26 09:28:30 --> Config Class Initialized
INFO - 2023-07-26 09:28:30 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:28:30 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:28:30 --> Utf8 Class Initialized
INFO - 2023-07-26 09:28:30 --> URI Class Initialized
INFO - 2023-07-26 09:28:30 --> Router Class Initialized
INFO - 2023-07-26 09:28:30 --> Output Class Initialized
INFO - 2023-07-26 09:28:30 --> Security Class Initialized
DEBUG - 2023-07-26 09:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:28:30 --> Input Class Initialized
INFO - 2023-07-26 09:28:30 --> Language Class Initialized
INFO - 2023-07-26 09:28:30 --> Loader Class Initialized
INFO - 2023-07-26 09:28:30 --> Helper loaded: url_helper
INFO - 2023-07-26 09:28:30 --> Helper loaded: form_helper
INFO - 2023-07-26 09:28:30 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:28:30 --> Controller Class Initialized
DEBUG - 2023-07-26 09:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:28:30 --> Database Driver Class Initialized
INFO - 2023-07-26 09:28:30 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:28:30 --> Model "Student_model" initialized
INFO - 2023-07-26 09:28:30 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:28:30 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:28:30 --> Final output sent to browser
DEBUG - 2023-07-26 09:28:30 --> Total execution time: 0.0503
INFO - 2023-07-26 09:28:31 --> Config Class Initialized
INFO - 2023-07-26 09:28:31 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:28:31 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:28:31 --> Utf8 Class Initialized
INFO - 2023-07-26 09:28:31 --> URI Class Initialized
INFO - 2023-07-26 09:28:31 --> Router Class Initialized
INFO - 2023-07-26 09:28:31 --> Output Class Initialized
INFO - 2023-07-26 09:28:31 --> Security Class Initialized
DEBUG - 2023-07-26 09:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:28:31 --> Input Class Initialized
INFO - 2023-07-26 09:28:31 --> Language Class Initialized
INFO - 2023-07-26 09:28:31 --> Loader Class Initialized
INFO - 2023-07-26 09:28:31 --> Helper loaded: url_helper
INFO - 2023-07-26 09:28:31 --> Helper loaded: form_helper
INFO - 2023-07-26 09:28:31 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:28:31 --> Controller Class Initialized
DEBUG - 2023-07-26 09:28:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:28:31 --> Database Driver Class Initialized
INFO - 2023-07-26 09:28:31 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:28:31 --> Model "Student_model" initialized
INFO - 2023-07-26 09:28:31 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:28:31 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:28:31 --> Final output sent to browser
DEBUG - 2023-07-26 09:28:31 --> Total execution time: 0.0416
INFO - 2023-07-26 09:28:32 --> Config Class Initialized
INFO - 2023-07-26 09:28:32 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:28:32 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:28:32 --> Utf8 Class Initialized
INFO - 2023-07-26 09:28:32 --> URI Class Initialized
INFO - 2023-07-26 09:28:32 --> Router Class Initialized
INFO - 2023-07-26 09:28:32 --> Output Class Initialized
INFO - 2023-07-26 09:28:32 --> Security Class Initialized
DEBUG - 2023-07-26 09:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:28:32 --> Input Class Initialized
INFO - 2023-07-26 09:28:32 --> Language Class Initialized
INFO - 2023-07-26 09:28:32 --> Loader Class Initialized
INFO - 2023-07-26 09:28:32 --> Helper loaded: url_helper
INFO - 2023-07-26 09:28:32 --> Helper loaded: form_helper
INFO - 2023-07-26 09:28:32 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:28:32 --> Controller Class Initialized
DEBUG - 2023-07-26 09:28:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:28:32 --> Database Driver Class Initialized
INFO - 2023-07-26 09:28:32 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:28:32 --> Model "Student_model" initialized
INFO - 2023-07-26 09:28:32 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:28:32 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:28:32 --> Final output sent to browser
DEBUG - 2023-07-26 09:28:32 --> Total execution time: 0.0402
INFO - 2023-07-26 09:28:34 --> Config Class Initialized
INFO - 2023-07-26 09:28:34 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:28:34 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:28:34 --> Utf8 Class Initialized
INFO - 2023-07-26 09:28:34 --> URI Class Initialized
INFO - 2023-07-26 09:28:34 --> Router Class Initialized
INFO - 2023-07-26 09:28:34 --> Output Class Initialized
INFO - 2023-07-26 09:28:34 --> Security Class Initialized
DEBUG - 2023-07-26 09:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:28:34 --> Input Class Initialized
INFO - 2023-07-26 09:28:34 --> Language Class Initialized
INFO - 2023-07-26 09:28:34 --> Loader Class Initialized
INFO - 2023-07-26 09:28:34 --> Helper loaded: url_helper
INFO - 2023-07-26 09:28:34 --> Helper loaded: form_helper
INFO - 2023-07-26 09:28:34 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:28:34 --> Controller Class Initialized
DEBUG - 2023-07-26 09:28:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:28:34 --> Database Driver Class Initialized
INFO - 2023-07-26 09:28:34 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:28:34 --> Model "Student_model" initialized
INFO - 2023-07-26 09:28:34 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:28:34 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:28:34 --> Final output sent to browser
DEBUG - 2023-07-26 09:28:34 --> Total execution time: 0.0460
INFO - 2023-07-26 09:28:38 --> Config Class Initialized
INFO - 2023-07-26 09:28:38 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:28:38 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:28:38 --> Utf8 Class Initialized
INFO - 2023-07-26 09:28:38 --> URI Class Initialized
INFO - 2023-07-26 09:28:38 --> Router Class Initialized
INFO - 2023-07-26 09:28:38 --> Output Class Initialized
INFO - 2023-07-26 09:28:38 --> Security Class Initialized
DEBUG - 2023-07-26 09:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:28:38 --> Input Class Initialized
INFO - 2023-07-26 09:28:38 --> Language Class Initialized
INFO - 2023-07-26 09:28:38 --> Loader Class Initialized
INFO - 2023-07-26 09:28:38 --> Helper loaded: url_helper
INFO - 2023-07-26 09:28:38 --> Helper loaded: form_helper
INFO - 2023-07-26 09:28:38 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:28:38 --> Controller Class Initialized
DEBUG - 2023-07-26 09:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:28:38 --> Database Driver Class Initialized
INFO - 2023-07-26 09:28:38 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:28:38 --> Model "Student_model" initialized
INFO - 2023-07-26 09:28:38 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:28:38 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:28:38 --> Final output sent to browser
DEBUG - 2023-07-26 09:28:38 --> Total execution time: 0.0365
INFO - 2023-07-26 09:28:39 --> Config Class Initialized
INFO - 2023-07-26 09:28:39 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:28:39 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:28:39 --> Utf8 Class Initialized
INFO - 2023-07-26 09:28:39 --> URI Class Initialized
INFO - 2023-07-26 09:28:39 --> Router Class Initialized
INFO - 2023-07-26 09:28:39 --> Output Class Initialized
INFO - 2023-07-26 09:28:39 --> Security Class Initialized
DEBUG - 2023-07-26 09:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:28:39 --> Input Class Initialized
INFO - 2023-07-26 09:28:39 --> Language Class Initialized
INFO - 2023-07-26 09:28:39 --> Loader Class Initialized
INFO - 2023-07-26 09:28:39 --> Helper loaded: url_helper
INFO - 2023-07-26 09:28:39 --> Helper loaded: form_helper
INFO - 2023-07-26 09:28:39 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:28:39 --> Controller Class Initialized
DEBUG - 2023-07-26 09:28:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:28:39 --> Database Driver Class Initialized
INFO - 2023-07-26 09:28:39 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:28:39 --> Model "Student_model" initialized
INFO - 2023-07-26 09:28:39 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:28:39 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:28:39 --> Final output sent to browser
DEBUG - 2023-07-26 09:28:39 --> Total execution time: 0.0409
INFO - 2023-07-26 09:28:43 --> Config Class Initialized
INFO - 2023-07-26 09:28:43 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:28:43 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:28:43 --> Utf8 Class Initialized
INFO - 2023-07-26 09:28:43 --> URI Class Initialized
INFO - 2023-07-26 09:28:43 --> Router Class Initialized
INFO - 2023-07-26 09:28:43 --> Output Class Initialized
INFO - 2023-07-26 09:28:43 --> Security Class Initialized
DEBUG - 2023-07-26 09:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:28:43 --> Input Class Initialized
INFO - 2023-07-26 09:28:43 --> Language Class Initialized
INFO - 2023-07-26 09:28:43 --> Loader Class Initialized
INFO - 2023-07-26 09:28:43 --> Helper loaded: url_helper
INFO - 2023-07-26 09:28:43 --> Helper loaded: form_helper
INFO - 2023-07-26 09:28:43 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:28:43 --> Controller Class Initialized
DEBUG - 2023-07-26 09:28:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:28:43 --> Database Driver Class Initialized
INFO - 2023-07-26 09:28:43 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:28:43 --> Model "Student_model" initialized
INFO - 2023-07-26 09:28:43 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:28:43 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:28:43 --> Final output sent to browser
DEBUG - 2023-07-26 09:28:43 --> Total execution time: 0.0481
INFO - 2023-07-26 09:28:45 --> Config Class Initialized
INFO - 2023-07-26 09:28:45 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:28:45 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:28:45 --> Utf8 Class Initialized
INFO - 2023-07-26 09:28:45 --> URI Class Initialized
INFO - 2023-07-26 09:28:45 --> Router Class Initialized
INFO - 2023-07-26 09:28:45 --> Output Class Initialized
INFO - 2023-07-26 09:28:45 --> Security Class Initialized
DEBUG - 2023-07-26 09:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:28:45 --> Input Class Initialized
INFO - 2023-07-26 09:28:45 --> Language Class Initialized
INFO - 2023-07-26 09:28:45 --> Loader Class Initialized
INFO - 2023-07-26 09:28:45 --> Helper loaded: url_helper
INFO - 2023-07-26 09:28:45 --> Helper loaded: form_helper
INFO - 2023-07-26 09:28:45 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:28:45 --> Controller Class Initialized
DEBUG - 2023-07-26 09:28:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:28:45 --> Database Driver Class Initialized
INFO - 2023-07-26 09:28:45 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:28:45 --> Model "Student_model" initialized
INFO - 2023-07-26 09:28:45 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:28:45 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:28:45 --> Final output sent to browser
DEBUG - 2023-07-26 09:28:45 --> Total execution time: 0.0404
INFO - 2023-07-26 09:29:29 --> Config Class Initialized
INFO - 2023-07-26 09:29:29 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:29:29 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:29:29 --> Utf8 Class Initialized
INFO - 2023-07-26 09:29:29 --> URI Class Initialized
INFO - 2023-07-26 09:29:29 --> Router Class Initialized
INFO - 2023-07-26 09:29:29 --> Output Class Initialized
INFO - 2023-07-26 09:29:29 --> Security Class Initialized
DEBUG - 2023-07-26 09:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:29:29 --> Input Class Initialized
INFO - 2023-07-26 09:29:29 --> Language Class Initialized
INFO - 2023-07-26 09:29:29 --> Loader Class Initialized
INFO - 2023-07-26 09:29:29 --> Helper loaded: url_helper
INFO - 2023-07-26 09:29:29 --> Helper loaded: form_helper
INFO - 2023-07-26 09:29:29 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:29:29 --> Controller Class Initialized
DEBUG - 2023-07-26 09:29:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:29:29 --> Database Driver Class Initialized
INFO - 2023-07-26 09:29:29 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:29:29 --> Model "Student_model" initialized
INFO - 2023-07-26 09:29:29 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:29:29 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:29:29 --> Final output sent to browser
DEBUG - 2023-07-26 09:29:29 --> Total execution time: 0.0291
INFO - 2023-07-26 09:29:52 --> Config Class Initialized
INFO - 2023-07-26 09:29:52 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:29:52 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:29:52 --> Utf8 Class Initialized
INFO - 2023-07-26 09:29:52 --> URI Class Initialized
INFO - 2023-07-26 09:29:52 --> Router Class Initialized
INFO - 2023-07-26 09:29:52 --> Output Class Initialized
INFO - 2023-07-26 09:29:52 --> Security Class Initialized
DEBUG - 2023-07-26 09:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:29:52 --> Input Class Initialized
INFO - 2023-07-26 09:29:52 --> Language Class Initialized
ERROR - 2023-07-26 09:29:52 --> 404 Page Not Found: Admin/update_teacher
INFO - 2023-07-26 09:30:36 --> Config Class Initialized
INFO - 2023-07-26 09:30:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:30:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:30:36 --> Utf8 Class Initialized
INFO - 2023-07-26 09:30:36 --> URI Class Initialized
INFO - 2023-07-26 09:30:36 --> Router Class Initialized
INFO - 2023-07-26 09:30:36 --> Output Class Initialized
INFO - 2023-07-26 09:30:36 --> Security Class Initialized
DEBUG - 2023-07-26 09:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:30:36 --> Input Class Initialized
INFO - 2023-07-26 09:30:36 --> Language Class Initialized
INFO - 2023-07-26 09:30:36 --> Loader Class Initialized
INFO - 2023-07-26 09:30:36 --> Helper loaded: url_helper
INFO - 2023-07-26 09:30:36 --> Helper loaded: form_helper
INFO - 2023-07-26 09:30:36 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:30:36 --> Controller Class Initialized
DEBUG - 2023-07-26 09:30:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:30:36 --> Database Driver Class Initialized
INFO - 2023-07-26 09:30:36 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:30:36 --> Model "Student_model" initialized
INFO - 2023-07-26 09:30:36 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:30:36 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:30:36 --> Final output sent to browser
DEBUG - 2023-07-26 09:30:36 --> Total execution time: 0.0511
INFO - 2023-07-26 09:31:11 --> Config Class Initialized
INFO - 2023-07-26 09:31:11 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:31:11 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:31:11 --> Utf8 Class Initialized
INFO - 2023-07-26 09:31:11 --> URI Class Initialized
INFO - 2023-07-26 09:31:11 --> Router Class Initialized
INFO - 2023-07-26 09:31:11 --> Output Class Initialized
INFO - 2023-07-26 09:31:11 --> Security Class Initialized
DEBUG - 2023-07-26 09:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:31:11 --> Input Class Initialized
INFO - 2023-07-26 09:31:11 --> Language Class Initialized
INFO - 2023-07-26 09:31:11 --> Loader Class Initialized
INFO - 2023-07-26 09:31:11 --> Helper loaded: url_helper
INFO - 2023-07-26 09:31:11 --> Helper loaded: form_helper
INFO - 2023-07-26 09:31:11 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:31:11 --> Controller Class Initialized
DEBUG - 2023-07-26 09:31:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:31:11 --> Database Driver Class Initialized
INFO - 2023-07-26 09:31:11 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:31:11 --> Model "Student_model" initialized
INFO - 2023-07-26 09:31:11 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:31:11 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:31:11 --> Final output sent to browser
DEBUG - 2023-07-26 09:31:11 --> Total execution time: 0.0271
INFO - 2023-07-26 09:31:27 --> Config Class Initialized
INFO - 2023-07-26 09:31:27 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:31:27 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:31:27 --> Utf8 Class Initialized
INFO - 2023-07-26 09:31:27 --> URI Class Initialized
INFO - 2023-07-26 09:31:27 --> Router Class Initialized
INFO - 2023-07-26 09:31:27 --> Output Class Initialized
INFO - 2023-07-26 09:31:27 --> Security Class Initialized
DEBUG - 2023-07-26 09:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:31:27 --> Input Class Initialized
INFO - 2023-07-26 09:31:27 --> Language Class Initialized
INFO - 2023-07-26 09:31:27 --> Loader Class Initialized
INFO - 2023-07-26 09:31:27 --> Helper loaded: url_helper
INFO - 2023-07-26 09:31:27 --> Helper loaded: form_helper
INFO - 2023-07-26 09:31:27 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:31:27 --> Controller Class Initialized
DEBUG - 2023-07-26 09:31:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:31:27 --> Database Driver Class Initialized
INFO - 2023-07-26 09:31:27 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:31:27 --> Model "Student_model" initialized
INFO - 2023-07-26 09:31:27 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:31:27 --> Config Class Initialized
INFO - 2023-07-26 09:31:27 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:31:27 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:31:27 --> Utf8 Class Initialized
INFO - 2023-07-26 09:31:27 --> URI Class Initialized
INFO - 2023-07-26 09:31:27 --> Router Class Initialized
INFO - 2023-07-26 09:31:27 --> Output Class Initialized
INFO - 2023-07-26 09:31:27 --> Security Class Initialized
DEBUG - 2023-07-26 09:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:31:27 --> Input Class Initialized
INFO - 2023-07-26 09:31:27 --> Language Class Initialized
ERROR - 2023-07-26 09:31:27 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 09:32:43 --> Config Class Initialized
INFO - 2023-07-26 09:32:43 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:32:43 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:32:43 --> Utf8 Class Initialized
INFO - 2023-07-26 09:32:43 --> URI Class Initialized
INFO - 2023-07-26 09:32:43 --> Router Class Initialized
INFO - 2023-07-26 09:32:43 --> Output Class Initialized
INFO - 2023-07-26 09:32:43 --> Security Class Initialized
DEBUG - 2023-07-26 09:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:32:43 --> Input Class Initialized
INFO - 2023-07-26 09:32:43 --> Language Class Initialized
INFO - 2023-07-26 09:32:43 --> Loader Class Initialized
INFO - 2023-07-26 09:32:43 --> Helper loaded: url_helper
INFO - 2023-07-26 09:32:43 --> Helper loaded: form_helper
INFO - 2023-07-26 09:32:43 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:32:43 --> Controller Class Initialized
DEBUG - 2023-07-26 09:32:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:32:43 --> Database Driver Class Initialized
INFO - 2023-07-26 09:32:43 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:32:43 --> Model "Student_model" initialized
INFO - 2023-07-26 09:32:43 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:32:43 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:32:43 --> Final output sent to browser
DEBUG - 2023-07-26 09:32:43 --> Total execution time: 0.0285
INFO - 2023-07-26 09:32:45 --> Config Class Initialized
INFO - 2023-07-26 09:32:45 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:32:45 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:32:45 --> Utf8 Class Initialized
INFO - 2023-07-26 09:32:45 --> URI Class Initialized
INFO - 2023-07-26 09:32:45 --> Router Class Initialized
INFO - 2023-07-26 09:32:45 --> Output Class Initialized
INFO - 2023-07-26 09:32:45 --> Security Class Initialized
DEBUG - 2023-07-26 09:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:32:45 --> Input Class Initialized
INFO - 2023-07-26 09:32:45 --> Language Class Initialized
INFO - 2023-07-26 09:32:45 --> Loader Class Initialized
INFO - 2023-07-26 09:32:45 --> Helper loaded: url_helper
INFO - 2023-07-26 09:32:45 --> Helper loaded: form_helper
INFO - 2023-07-26 09:32:45 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:32:45 --> Controller Class Initialized
DEBUG - 2023-07-26 09:32:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:32:45 --> Database Driver Class Initialized
INFO - 2023-07-26 09:32:45 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:32:45 --> Model "Student_model" initialized
INFO - 2023-07-26 09:32:45 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:32:45 --> Config Class Initialized
INFO - 2023-07-26 09:32:45 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:32:45 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:32:45 --> Utf8 Class Initialized
INFO - 2023-07-26 09:32:45 --> URI Class Initialized
INFO - 2023-07-26 09:32:45 --> Router Class Initialized
INFO - 2023-07-26 09:32:45 --> Output Class Initialized
INFO - 2023-07-26 09:32:45 --> Security Class Initialized
DEBUG - 2023-07-26 09:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:32:45 --> Input Class Initialized
INFO - 2023-07-26 09:32:45 --> Language Class Initialized
ERROR - 2023-07-26 09:32:45 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:32:46 --> Config Class Initialized
INFO - 2023-07-26 09:32:46 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:32:46 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:32:46 --> Utf8 Class Initialized
INFO - 2023-07-26 09:32:46 --> URI Class Initialized
INFO - 2023-07-26 09:32:46 --> Router Class Initialized
INFO - 2023-07-26 09:32:46 --> Output Class Initialized
INFO - 2023-07-26 09:32:46 --> Security Class Initialized
DEBUG - 2023-07-26 09:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:32:46 --> Input Class Initialized
INFO - 2023-07-26 09:32:46 --> Language Class Initialized
ERROR - 2023-07-26 09:32:46 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:32:47 --> Config Class Initialized
INFO - 2023-07-26 09:32:47 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:32:47 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:32:47 --> Utf8 Class Initialized
INFO - 2023-07-26 09:32:47 --> URI Class Initialized
INFO - 2023-07-26 09:32:47 --> Router Class Initialized
INFO - 2023-07-26 09:32:47 --> Output Class Initialized
INFO - 2023-07-26 09:32:47 --> Security Class Initialized
DEBUG - 2023-07-26 09:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:32:47 --> Input Class Initialized
INFO - 2023-07-26 09:32:47 --> Language Class Initialized
INFO - 2023-07-26 09:32:47 --> Loader Class Initialized
INFO - 2023-07-26 09:32:47 --> Helper loaded: url_helper
INFO - 2023-07-26 09:32:47 --> Helper loaded: form_helper
INFO - 2023-07-26 09:32:47 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:32:47 --> Controller Class Initialized
DEBUG - 2023-07-26 09:32:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:32:47 --> Database Driver Class Initialized
INFO - 2023-07-26 09:32:47 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:32:47 --> Model "Student_model" initialized
INFO - 2023-07-26 09:32:47 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:32:47 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:32:47 --> Final output sent to browser
DEBUG - 2023-07-26 09:32:47 --> Total execution time: 0.0430
INFO - 2023-07-26 09:32:48 --> Config Class Initialized
INFO - 2023-07-26 09:32:48 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:32:48 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:32:48 --> Utf8 Class Initialized
INFO - 2023-07-26 09:32:48 --> URI Class Initialized
INFO - 2023-07-26 09:32:48 --> Router Class Initialized
INFO - 2023-07-26 09:32:48 --> Output Class Initialized
INFO - 2023-07-26 09:32:48 --> Security Class Initialized
DEBUG - 2023-07-26 09:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:32:48 --> Input Class Initialized
INFO - 2023-07-26 09:32:48 --> Language Class Initialized
INFO - 2023-07-26 09:32:48 --> Loader Class Initialized
INFO - 2023-07-26 09:32:48 --> Helper loaded: url_helper
INFO - 2023-07-26 09:32:48 --> Helper loaded: form_helper
INFO - 2023-07-26 09:32:48 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:32:48 --> Controller Class Initialized
DEBUG - 2023-07-26 09:32:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:32:48 --> Database Driver Class Initialized
INFO - 2023-07-26 09:32:48 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:32:48 --> Model "Student_model" initialized
INFO - 2023-07-26 09:32:48 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:32:48 --> Config Class Initialized
INFO - 2023-07-26 09:32:48 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:32:48 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:32:48 --> Utf8 Class Initialized
INFO - 2023-07-26 09:32:48 --> URI Class Initialized
INFO - 2023-07-26 09:32:48 --> Router Class Initialized
INFO - 2023-07-26 09:32:48 --> Output Class Initialized
INFO - 2023-07-26 09:32:48 --> Security Class Initialized
DEBUG - 2023-07-26 09:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:32:48 --> Input Class Initialized
INFO - 2023-07-26 09:32:48 --> Language Class Initialized
ERROR - 2023-07-26 09:32:48 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:35:13 --> Config Class Initialized
INFO - 2023-07-26 09:35:13 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:35:13 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:35:13 --> Utf8 Class Initialized
INFO - 2023-07-26 09:35:13 --> URI Class Initialized
INFO - 2023-07-26 09:35:13 --> Router Class Initialized
INFO - 2023-07-26 09:35:13 --> Output Class Initialized
INFO - 2023-07-26 09:35:13 --> Security Class Initialized
DEBUG - 2023-07-26 09:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:35:13 --> Input Class Initialized
INFO - 2023-07-26 09:35:13 --> Language Class Initialized
ERROR - 2023-07-26 09:35:13 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:35:13 --> Config Class Initialized
INFO - 2023-07-26 09:35:13 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:35:13 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:35:13 --> Utf8 Class Initialized
INFO - 2023-07-26 09:35:13 --> URI Class Initialized
INFO - 2023-07-26 09:35:13 --> Router Class Initialized
INFO - 2023-07-26 09:35:13 --> Output Class Initialized
INFO - 2023-07-26 09:35:13 --> Security Class Initialized
DEBUG - 2023-07-26 09:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:35:13 --> Input Class Initialized
INFO - 2023-07-26 09:35:13 --> Language Class Initialized
ERROR - 2023-07-26 09:35:13 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:35:14 --> Config Class Initialized
INFO - 2023-07-26 09:35:14 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:35:14 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:35:14 --> Utf8 Class Initialized
INFO - 2023-07-26 09:35:14 --> URI Class Initialized
INFO - 2023-07-26 09:35:14 --> Router Class Initialized
INFO - 2023-07-26 09:35:14 --> Output Class Initialized
INFO - 2023-07-26 09:35:14 --> Security Class Initialized
DEBUG - 2023-07-26 09:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:35:14 --> Input Class Initialized
INFO - 2023-07-26 09:35:14 --> Language Class Initialized
ERROR - 2023-07-26 09:35:14 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:35:14 --> Config Class Initialized
INFO - 2023-07-26 09:35:14 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:35:14 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:35:14 --> Utf8 Class Initialized
INFO - 2023-07-26 09:35:14 --> URI Class Initialized
INFO - 2023-07-26 09:35:14 --> Router Class Initialized
INFO - 2023-07-26 09:35:14 --> Output Class Initialized
INFO - 2023-07-26 09:35:14 --> Security Class Initialized
DEBUG - 2023-07-26 09:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:35:14 --> Input Class Initialized
INFO - 2023-07-26 09:35:14 --> Language Class Initialized
ERROR - 2023-07-26 09:35:14 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:35:14 --> Config Class Initialized
INFO - 2023-07-26 09:35:14 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:35:14 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:35:14 --> Utf8 Class Initialized
INFO - 2023-07-26 09:35:14 --> URI Class Initialized
INFO - 2023-07-26 09:35:14 --> Router Class Initialized
INFO - 2023-07-26 09:35:14 --> Output Class Initialized
INFO - 2023-07-26 09:35:14 --> Security Class Initialized
DEBUG - 2023-07-26 09:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:35:14 --> Input Class Initialized
INFO - 2023-07-26 09:35:14 --> Language Class Initialized
INFO - 2023-07-26 09:35:14 --> Loader Class Initialized
INFO - 2023-07-26 09:35:14 --> Helper loaded: url_helper
INFO - 2023-07-26 09:35:14 --> Helper loaded: form_helper
INFO - 2023-07-26 09:35:14 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:35:14 --> Controller Class Initialized
DEBUG - 2023-07-26 09:35:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:35:14 --> Database Driver Class Initialized
INFO - 2023-07-26 09:35:14 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:35:14 --> Model "Student_model" initialized
INFO - 2023-07-26 09:35:14 --> Model "Teacher_model" initialized
ERROR - 2023-07-26 09:35:14 --> Severity: Notice --> Undefined variable: teacher_data C:\xampp\htdocs\Project\application\views\admin\edit_teacher.php 10
ERROR - 2023-07-26 09:35:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\admin\edit_teacher.php 10
INFO - 2023-07-26 09:35:14 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:35:14 --> Final output sent to browser
DEBUG - 2023-07-26 09:35:14 --> Total execution time: 0.0255
INFO - 2023-07-26 09:36:45 --> Config Class Initialized
INFO - 2023-07-26 09:36:45 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:36:45 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:36:45 --> Utf8 Class Initialized
INFO - 2023-07-26 09:36:45 --> URI Class Initialized
INFO - 2023-07-26 09:36:45 --> Router Class Initialized
INFO - 2023-07-26 09:36:45 --> Output Class Initialized
INFO - 2023-07-26 09:36:45 --> Security Class Initialized
DEBUG - 2023-07-26 09:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:36:45 --> Input Class Initialized
INFO - 2023-07-26 09:36:45 --> Language Class Initialized
INFO - 2023-07-26 09:36:45 --> Loader Class Initialized
INFO - 2023-07-26 09:36:45 --> Helper loaded: url_helper
INFO - 2023-07-26 09:36:45 --> Helper loaded: form_helper
INFO - 2023-07-26 09:36:45 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:36:45 --> Controller Class Initialized
DEBUG - 2023-07-26 09:36:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:36:45 --> Database Driver Class Initialized
INFO - 2023-07-26 09:36:45 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:36:45 --> Model "Student_model" initialized
INFO - 2023-07-26 09:36:45 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:36:45 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:36:45 --> Final output sent to browser
DEBUG - 2023-07-26 09:36:45 --> Total execution time: 0.0246
INFO - 2023-07-26 09:36:53 --> Config Class Initialized
INFO - 2023-07-26 09:36:53 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:36:53 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:36:53 --> Utf8 Class Initialized
INFO - 2023-07-26 09:36:53 --> URI Class Initialized
INFO - 2023-07-26 09:36:53 --> Router Class Initialized
INFO - 2023-07-26 09:36:53 --> Output Class Initialized
INFO - 2023-07-26 09:36:53 --> Security Class Initialized
DEBUG - 2023-07-26 09:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:36:53 --> Input Class Initialized
INFO - 2023-07-26 09:36:53 --> Language Class Initialized
INFO - 2023-07-26 09:36:53 --> Loader Class Initialized
INFO - 2023-07-26 09:36:53 --> Helper loaded: url_helper
INFO - 2023-07-26 09:36:53 --> Helper loaded: form_helper
INFO - 2023-07-26 09:36:53 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:36:53 --> Controller Class Initialized
DEBUG - 2023-07-26 09:36:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:36:53 --> Database Driver Class Initialized
INFO - 2023-07-26 09:36:53 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:36:53 --> Model "Student_model" initialized
INFO - 2023-07-26 09:36:53 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:36:53 --> Config Class Initialized
INFO - 2023-07-26 09:36:53 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:36:53 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:36:53 --> Utf8 Class Initialized
INFO - 2023-07-26 09:36:53 --> URI Class Initialized
INFO - 2023-07-26 09:36:53 --> Router Class Initialized
INFO - 2023-07-26 09:36:53 --> Output Class Initialized
INFO - 2023-07-26 09:36:53 --> Security Class Initialized
DEBUG - 2023-07-26 09:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:36:53 --> Input Class Initialized
INFO - 2023-07-26 09:36:53 --> Language Class Initialized
ERROR - 2023-07-26 09:36:53 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:37:55 --> Config Class Initialized
INFO - 2023-07-26 09:37:55 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:37:55 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:37:55 --> Utf8 Class Initialized
INFO - 2023-07-26 09:37:55 --> URI Class Initialized
INFO - 2023-07-26 09:37:55 --> Router Class Initialized
INFO - 2023-07-26 09:37:55 --> Output Class Initialized
INFO - 2023-07-26 09:37:55 --> Security Class Initialized
DEBUG - 2023-07-26 09:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:37:55 --> Input Class Initialized
INFO - 2023-07-26 09:37:55 --> Language Class Initialized
INFO - 2023-07-26 09:37:55 --> Loader Class Initialized
INFO - 2023-07-26 09:37:55 --> Helper loaded: url_helper
INFO - 2023-07-26 09:37:55 --> Helper loaded: form_helper
INFO - 2023-07-26 09:37:55 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:37:55 --> Controller Class Initialized
DEBUG - 2023-07-26 09:37:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:37:55 --> Database Driver Class Initialized
INFO - 2023-07-26 09:37:55 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:37:55 --> Model "Student_model" initialized
INFO - 2023-07-26 09:37:55 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:37:55 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:37:55 --> Final output sent to browser
DEBUG - 2023-07-26 09:37:55 --> Total execution time: 0.0356
INFO - 2023-07-26 09:37:56 --> Config Class Initialized
INFO - 2023-07-26 09:37:56 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:37:56 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:37:56 --> Utf8 Class Initialized
INFO - 2023-07-26 09:37:56 --> URI Class Initialized
INFO - 2023-07-26 09:37:56 --> Router Class Initialized
INFO - 2023-07-26 09:37:56 --> Output Class Initialized
INFO - 2023-07-26 09:37:56 --> Security Class Initialized
DEBUG - 2023-07-26 09:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:37:56 --> Input Class Initialized
INFO - 2023-07-26 09:37:56 --> Language Class Initialized
INFO - 2023-07-26 09:37:56 --> Loader Class Initialized
INFO - 2023-07-26 09:37:56 --> Helper loaded: url_helper
INFO - 2023-07-26 09:37:56 --> Helper loaded: form_helper
INFO - 2023-07-26 09:37:56 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:37:56 --> Controller Class Initialized
DEBUG - 2023-07-26 09:37:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:37:56 --> Database Driver Class Initialized
INFO - 2023-07-26 09:37:56 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:37:56 --> Model "Student_model" initialized
INFO - 2023-07-26 09:37:56 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:37:56 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:37:56 --> Final output sent to browser
DEBUG - 2023-07-26 09:37:56 --> Total execution time: 0.0374
INFO - 2023-07-26 09:38:10 --> Config Class Initialized
INFO - 2023-07-26 09:38:10 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:38:10 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:38:10 --> Utf8 Class Initialized
INFO - 2023-07-26 09:38:10 --> URI Class Initialized
INFO - 2023-07-26 09:38:10 --> Router Class Initialized
INFO - 2023-07-26 09:38:10 --> Output Class Initialized
INFO - 2023-07-26 09:38:10 --> Security Class Initialized
DEBUG - 2023-07-26 09:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:38:10 --> Input Class Initialized
INFO - 2023-07-26 09:38:10 --> Language Class Initialized
INFO - 2023-07-26 09:38:10 --> Loader Class Initialized
INFO - 2023-07-26 09:38:10 --> Helper loaded: url_helper
INFO - 2023-07-26 09:38:10 --> Helper loaded: form_helper
INFO - 2023-07-26 09:38:10 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:38:10 --> Controller Class Initialized
DEBUG - 2023-07-26 09:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:38:10 --> Database Driver Class Initialized
INFO - 2023-07-26 09:38:10 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:38:10 --> Model "Student_model" initialized
INFO - 2023-07-26 09:38:10 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:38:10 --> Config Class Initialized
INFO - 2023-07-26 09:38:10 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:38:10 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:38:10 --> Utf8 Class Initialized
INFO - 2023-07-26 09:38:10 --> URI Class Initialized
INFO - 2023-07-26 09:38:10 --> Router Class Initialized
INFO - 2023-07-26 09:38:10 --> Output Class Initialized
INFO - 2023-07-26 09:38:10 --> Security Class Initialized
DEBUG - 2023-07-26 09:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:38:10 --> Input Class Initialized
INFO - 2023-07-26 09:38:10 --> Language Class Initialized
ERROR - 2023-07-26 09:38:10 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 09:38:11 --> Config Class Initialized
INFO - 2023-07-26 09:38:11 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:38:11 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:38:11 --> Utf8 Class Initialized
INFO - 2023-07-26 09:38:11 --> URI Class Initialized
INFO - 2023-07-26 09:38:11 --> Router Class Initialized
INFO - 2023-07-26 09:38:11 --> Output Class Initialized
INFO - 2023-07-26 09:38:11 --> Security Class Initialized
DEBUG - 2023-07-26 09:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:38:11 --> Input Class Initialized
INFO - 2023-07-26 09:38:11 --> Language Class Initialized
INFO - 2023-07-26 09:38:11 --> Loader Class Initialized
INFO - 2023-07-26 09:38:11 --> Helper loaded: url_helper
INFO - 2023-07-26 09:38:11 --> Helper loaded: form_helper
INFO - 2023-07-26 09:38:11 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:38:11 --> Controller Class Initialized
DEBUG - 2023-07-26 09:38:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:38:11 --> Database Driver Class Initialized
INFO - 2023-07-26 09:38:11 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:38:11 --> Model "Student_model" initialized
INFO - 2023-07-26 09:38:11 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:38:11 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:38:11 --> Final output sent to browser
DEBUG - 2023-07-26 09:38:11 --> Total execution time: 0.0439
INFO - 2023-07-26 09:38:21 --> Config Class Initialized
INFO - 2023-07-26 09:38:21 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:38:21 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:38:21 --> Utf8 Class Initialized
INFO - 2023-07-26 09:38:21 --> URI Class Initialized
INFO - 2023-07-26 09:38:21 --> Router Class Initialized
INFO - 2023-07-26 09:38:21 --> Output Class Initialized
INFO - 2023-07-26 09:38:21 --> Security Class Initialized
DEBUG - 2023-07-26 09:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:38:21 --> Input Class Initialized
INFO - 2023-07-26 09:38:21 --> Language Class Initialized
INFO - 2023-07-26 09:38:21 --> Loader Class Initialized
INFO - 2023-07-26 09:38:21 --> Helper loaded: url_helper
INFO - 2023-07-26 09:38:21 --> Helper loaded: form_helper
INFO - 2023-07-26 09:38:21 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:38:21 --> Controller Class Initialized
DEBUG - 2023-07-26 09:38:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:38:21 --> Database Driver Class Initialized
INFO - 2023-07-26 09:38:21 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:38:21 --> Model "Student_model" initialized
INFO - 2023-07-26 09:38:21 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:38:21 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:38:21 --> Final output sent to browser
DEBUG - 2023-07-26 09:38:21 --> Total execution time: 0.0253
INFO - 2023-07-26 09:38:32 --> Config Class Initialized
INFO - 2023-07-26 09:38:32 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:38:32 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:38:32 --> Utf8 Class Initialized
INFO - 2023-07-26 09:38:32 --> URI Class Initialized
INFO - 2023-07-26 09:38:32 --> Router Class Initialized
INFO - 2023-07-26 09:38:32 --> Output Class Initialized
INFO - 2023-07-26 09:38:32 --> Security Class Initialized
DEBUG - 2023-07-26 09:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:38:32 --> Input Class Initialized
INFO - 2023-07-26 09:38:32 --> Language Class Initialized
INFO - 2023-07-26 09:38:32 --> Loader Class Initialized
INFO - 2023-07-26 09:38:32 --> Helper loaded: url_helper
INFO - 2023-07-26 09:38:32 --> Helper loaded: form_helper
INFO - 2023-07-26 09:38:32 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:38:32 --> Controller Class Initialized
DEBUG - 2023-07-26 09:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:38:32 --> Database Driver Class Initialized
INFO - 2023-07-26 09:38:32 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:38:32 --> Model "Student_model" initialized
INFO - 2023-07-26 09:38:32 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:38:32 --> Config Class Initialized
INFO - 2023-07-26 09:38:32 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:38:32 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:38:32 --> Utf8 Class Initialized
INFO - 2023-07-26 09:38:32 --> URI Class Initialized
INFO - 2023-07-26 09:38:32 --> Router Class Initialized
INFO - 2023-07-26 09:38:32 --> Output Class Initialized
INFO - 2023-07-26 09:38:32 --> Security Class Initialized
DEBUG - 2023-07-26 09:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:38:32 --> Input Class Initialized
INFO - 2023-07-26 09:38:32 --> Language Class Initialized
ERROR - 2023-07-26 09:38:32 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:38:33 --> Config Class Initialized
INFO - 2023-07-26 09:38:33 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:38:33 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:38:33 --> Utf8 Class Initialized
INFO - 2023-07-26 09:38:33 --> URI Class Initialized
INFO - 2023-07-26 09:38:33 --> Router Class Initialized
INFO - 2023-07-26 09:38:33 --> Output Class Initialized
INFO - 2023-07-26 09:38:33 --> Security Class Initialized
DEBUG - 2023-07-26 09:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:38:33 --> Input Class Initialized
INFO - 2023-07-26 09:38:33 --> Language Class Initialized
INFO - 2023-07-26 09:38:33 --> Loader Class Initialized
INFO - 2023-07-26 09:38:33 --> Helper loaded: url_helper
INFO - 2023-07-26 09:38:33 --> Helper loaded: form_helper
INFO - 2023-07-26 09:38:33 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:38:33 --> Controller Class Initialized
DEBUG - 2023-07-26 09:38:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:38:33 --> Database Driver Class Initialized
INFO - 2023-07-26 09:38:33 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:38:33 --> Model "Student_model" initialized
INFO - 2023-07-26 09:38:33 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:38:33 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:38:33 --> Final output sent to browser
DEBUG - 2023-07-26 09:38:33 --> Total execution time: 0.0418
INFO - 2023-07-26 09:38:34 --> Config Class Initialized
INFO - 2023-07-26 09:38:34 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:38:34 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:38:34 --> Utf8 Class Initialized
INFO - 2023-07-26 09:38:34 --> URI Class Initialized
INFO - 2023-07-26 09:38:34 --> Router Class Initialized
INFO - 2023-07-26 09:38:34 --> Output Class Initialized
INFO - 2023-07-26 09:38:34 --> Security Class Initialized
DEBUG - 2023-07-26 09:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:38:34 --> Input Class Initialized
INFO - 2023-07-26 09:38:34 --> Language Class Initialized
INFO - 2023-07-26 09:38:34 --> Loader Class Initialized
INFO - 2023-07-26 09:38:34 --> Helper loaded: url_helper
INFO - 2023-07-26 09:38:34 --> Helper loaded: form_helper
INFO - 2023-07-26 09:38:34 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:38:34 --> Controller Class Initialized
DEBUG - 2023-07-26 09:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:38:34 --> Database Driver Class Initialized
INFO - 2023-07-26 09:38:34 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:38:34 --> Model "Student_model" initialized
INFO - 2023-07-26 09:38:34 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:38:34 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:38:34 --> Final output sent to browser
DEBUG - 2023-07-26 09:38:34 --> Total execution time: 0.0237
INFO - 2023-07-26 09:41:16 --> Config Class Initialized
INFO - 2023-07-26 09:41:16 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:41:16 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:41:16 --> Utf8 Class Initialized
INFO - 2023-07-26 09:41:16 --> URI Class Initialized
INFO - 2023-07-26 09:41:16 --> Router Class Initialized
INFO - 2023-07-26 09:41:16 --> Output Class Initialized
INFO - 2023-07-26 09:41:16 --> Security Class Initialized
DEBUG - 2023-07-26 09:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:41:16 --> Input Class Initialized
INFO - 2023-07-26 09:41:16 --> Language Class Initialized
INFO - 2023-07-26 09:41:16 --> Loader Class Initialized
INFO - 2023-07-26 09:41:16 --> Helper loaded: url_helper
INFO - 2023-07-26 09:41:16 --> Helper loaded: form_helper
INFO - 2023-07-26 09:41:16 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:41:16 --> Controller Class Initialized
DEBUG - 2023-07-26 09:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:41:16 --> Database Driver Class Initialized
INFO - 2023-07-26 09:41:16 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:41:16 --> Model "Student_model" initialized
INFO - 2023-07-26 09:41:16 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:41:16 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:41:16 --> Final output sent to browser
DEBUG - 2023-07-26 09:41:16 --> Total execution time: 0.0272
INFO - 2023-07-26 09:41:19 --> Config Class Initialized
INFO - 2023-07-26 09:41:19 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:41:19 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:41:19 --> Utf8 Class Initialized
INFO - 2023-07-26 09:41:19 --> URI Class Initialized
INFO - 2023-07-26 09:41:19 --> Router Class Initialized
INFO - 2023-07-26 09:41:19 --> Output Class Initialized
INFO - 2023-07-26 09:41:19 --> Security Class Initialized
DEBUG - 2023-07-26 09:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:41:19 --> Input Class Initialized
INFO - 2023-07-26 09:41:19 --> Language Class Initialized
INFO - 2023-07-26 09:41:19 --> Loader Class Initialized
INFO - 2023-07-26 09:41:19 --> Helper loaded: url_helper
INFO - 2023-07-26 09:41:19 --> Helper loaded: form_helper
INFO - 2023-07-26 09:41:19 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:41:19 --> Controller Class Initialized
DEBUG - 2023-07-26 09:41:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:41:19 --> Database Driver Class Initialized
INFO - 2023-07-26 09:41:19 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:41:19 --> Model "Student_model" initialized
INFO - 2023-07-26 09:41:19 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:41:19 --> Config Class Initialized
INFO - 2023-07-26 09:41:19 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:41:19 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:41:19 --> Utf8 Class Initialized
INFO - 2023-07-26 09:41:19 --> URI Class Initialized
INFO - 2023-07-26 09:41:19 --> Router Class Initialized
INFO - 2023-07-26 09:41:19 --> Output Class Initialized
INFO - 2023-07-26 09:41:19 --> Security Class Initialized
DEBUG - 2023-07-26 09:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:41:19 --> Input Class Initialized
INFO - 2023-07-26 09:41:19 --> Language Class Initialized
ERROR - 2023-07-26 09:41:19 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:41:20 --> Config Class Initialized
INFO - 2023-07-26 09:41:20 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:41:20 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:41:20 --> Utf8 Class Initialized
INFO - 2023-07-26 09:41:20 --> URI Class Initialized
INFO - 2023-07-26 09:41:20 --> Router Class Initialized
INFO - 2023-07-26 09:41:20 --> Output Class Initialized
INFO - 2023-07-26 09:41:20 --> Security Class Initialized
DEBUG - 2023-07-26 09:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:41:20 --> Input Class Initialized
INFO - 2023-07-26 09:41:20 --> Language Class Initialized
INFO - 2023-07-26 09:41:20 --> Loader Class Initialized
INFO - 2023-07-26 09:41:20 --> Helper loaded: url_helper
INFO - 2023-07-26 09:41:20 --> Helper loaded: form_helper
INFO - 2023-07-26 09:41:20 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:41:20 --> Controller Class Initialized
DEBUG - 2023-07-26 09:41:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:41:20 --> Database Driver Class Initialized
INFO - 2023-07-26 09:41:20 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:41:20 --> Model "Student_model" initialized
INFO - 2023-07-26 09:41:20 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:41:20 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:41:20 --> Final output sent to browser
DEBUG - 2023-07-26 09:41:20 --> Total execution time: 0.0361
INFO - 2023-07-26 09:41:27 --> Config Class Initialized
INFO - 2023-07-26 09:41:27 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:41:27 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:41:27 --> Utf8 Class Initialized
INFO - 2023-07-26 09:41:27 --> URI Class Initialized
INFO - 2023-07-26 09:41:27 --> Router Class Initialized
INFO - 2023-07-26 09:41:27 --> Output Class Initialized
INFO - 2023-07-26 09:41:27 --> Security Class Initialized
DEBUG - 2023-07-26 09:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:41:27 --> Input Class Initialized
INFO - 2023-07-26 09:41:27 --> Language Class Initialized
INFO - 2023-07-26 09:41:27 --> Loader Class Initialized
INFO - 2023-07-26 09:41:27 --> Helper loaded: url_helper
INFO - 2023-07-26 09:41:27 --> Helper loaded: form_helper
INFO - 2023-07-26 09:41:27 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:41:27 --> Controller Class Initialized
DEBUG - 2023-07-26 09:41:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:41:27 --> Database Driver Class Initialized
INFO - 2023-07-26 09:41:27 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:41:27 --> Model "Student_model" initialized
INFO - 2023-07-26 09:41:27 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:41:27 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:41:27 --> Final output sent to browser
DEBUG - 2023-07-26 09:41:27 --> Total execution time: 0.0421
INFO - 2023-07-26 09:41:30 --> Config Class Initialized
INFO - 2023-07-26 09:41:30 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:41:30 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:41:30 --> Utf8 Class Initialized
INFO - 2023-07-26 09:41:30 --> URI Class Initialized
INFO - 2023-07-26 09:41:30 --> Router Class Initialized
INFO - 2023-07-26 09:41:30 --> Output Class Initialized
INFO - 2023-07-26 09:41:30 --> Security Class Initialized
DEBUG - 2023-07-26 09:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:41:30 --> Input Class Initialized
INFO - 2023-07-26 09:41:30 --> Language Class Initialized
INFO - 2023-07-26 09:41:30 --> Loader Class Initialized
INFO - 2023-07-26 09:41:30 --> Helper loaded: url_helper
INFO - 2023-07-26 09:41:30 --> Helper loaded: form_helper
INFO - 2023-07-26 09:41:30 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:41:30 --> Controller Class Initialized
DEBUG - 2023-07-26 09:41:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:41:30 --> Database Driver Class Initialized
INFO - 2023-07-26 09:41:30 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:41:30 --> Model "Student_model" initialized
INFO - 2023-07-26 09:41:30 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:41:30 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:41:30 --> Final output sent to browser
DEBUG - 2023-07-26 09:41:30 --> Total execution time: 0.0400
INFO - 2023-07-26 09:41:36 --> Config Class Initialized
INFO - 2023-07-26 09:41:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:41:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:41:36 --> Utf8 Class Initialized
INFO - 2023-07-26 09:41:36 --> URI Class Initialized
INFO - 2023-07-26 09:41:36 --> Router Class Initialized
INFO - 2023-07-26 09:41:36 --> Output Class Initialized
INFO - 2023-07-26 09:41:36 --> Security Class Initialized
DEBUG - 2023-07-26 09:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:41:36 --> Input Class Initialized
INFO - 2023-07-26 09:41:36 --> Language Class Initialized
INFO - 2023-07-26 09:41:36 --> Loader Class Initialized
INFO - 2023-07-26 09:41:36 --> Helper loaded: url_helper
INFO - 2023-07-26 09:41:36 --> Helper loaded: form_helper
INFO - 2023-07-26 09:41:36 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:41:36 --> Controller Class Initialized
DEBUG - 2023-07-26 09:41:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:41:36 --> Database Driver Class Initialized
INFO - 2023-07-26 09:41:36 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:41:36 --> Model "Student_model" initialized
INFO - 2023-07-26 09:41:36 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:41:36 --> Config Class Initialized
INFO - 2023-07-26 09:41:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:41:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:41:36 --> Utf8 Class Initialized
INFO - 2023-07-26 09:41:36 --> URI Class Initialized
INFO - 2023-07-26 09:41:36 --> Router Class Initialized
INFO - 2023-07-26 09:41:36 --> Output Class Initialized
INFO - 2023-07-26 09:41:36 --> Security Class Initialized
DEBUG - 2023-07-26 09:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:41:36 --> Input Class Initialized
INFO - 2023-07-26 09:41:36 --> Language Class Initialized
ERROR - 2023-07-26 09:41:36 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:41:37 --> Config Class Initialized
INFO - 2023-07-26 09:41:37 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:41:37 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:41:37 --> Utf8 Class Initialized
INFO - 2023-07-26 09:41:37 --> URI Class Initialized
INFO - 2023-07-26 09:41:37 --> Router Class Initialized
INFO - 2023-07-26 09:41:37 --> Output Class Initialized
INFO - 2023-07-26 09:41:37 --> Security Class Initialized
DEBUG - 2023-07-26 09:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:41:37 --> Input Class Initialized
INFO - 2023-07-26 09:41:37 --> Language Class Initialized
INFO - 2023-07-26 09:41:37 --> Loader Class Initialized
INFO - 2023-07-26 09:41:37 --> Helper loaded: url_helper
INFO - 2023-07-26 09:41:37 --> Helper loaded: form_helper
INFO - 2023-07-26 09:41:37 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:41:37 --> Controller Class Initialized
DEBUG - 2023-07-26 09:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:41:37 --> Database Driver Class Initialized
INFO - 2023-07-26 09:41:37 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:41:37 --> Model "Student_model" initialized
INFO - 2023-07-26 09:41:37 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:41:37 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:41:37 --> Final output sent to browser
DEBUG - 2023-07-26 09:41:37 --> Total execution time: 0.0486
INFO - 2023-07-26 09:41:37 --> Config Class Initialized
INFO - 2023-07-26 09:41:37 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:41:37 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:41:37 --> Utf8 Class Initialized
INFO - 2023-07-26 09:41:37 --> URI Class Initialized
INFO - 2023-07-26 09:41:37 --> Router Class Initialized
INFO - 2023-07-26 09:41:37 --> Output Class Initialized
INFO - 2023-07-26 09:41:37 --> Security Class Initialized
DEBUG - 2023-07-26 09:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:41:37 --> Input Class Initialized
INFO - 2023-07-26 09:41:37 --> Language Class Initialized
INFO - 2023-07-26 09:41:37 --> Loader Class Initialized
INFO - 2023-07-26 09:41:37 --> Helper loaded: url_helper
INFO - 2023-07-26 09:41:37 --> Helper loaded: form_helper
INFO - 2023-07-26 09:41:37 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:41:37 --> Controller Class Initialized
DEBUG - 2023-07-26 09:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:41:37 --> Database Driver Class Initialized
INFO - 2023-07-26 09:41:37 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:41:37 --> Model "Student_model" initialized
INFO - 2023-07-26 09:41:37 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:41:37 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:41:37 --> Final output sent to browser
DEBUG - 2023-07-26 09:41:37 --> Total execution time: 0.0475
INFO - 2023-07-26 09:43:51 --> Config Class Initialized
INFO - 2023-07-26 09:43:51 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:43:51 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:43:51 --> Utf8 Class Initialized
INFO - 2023-07-26 09:43:51 --> URI Class Initialized
INFO - 2023-07-26 09:43:51 --> Router Class Initialized
INFO - 2023-07-26 09:43:51 --> Output Class Initialized
INFO - 2023-07-26 09:43:51 --> Security Class Initialized
DEBUG - 2023-07-26 09:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:43:51 --> Input Class Initialized
INFO - 2023-07-26 09:43:51 --> Language Class Initialized
INFO - 2023-07-26 09:43:51 --> Loader Class Initialized
INFO - 2023-07-26 09:43:51 --> Helper loaded: url_helper
INFO - 2023-07-26 09:43:51 --> Helper loaded: form_helper
INFO - 2023-07-26 09:43:51 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:43:51 --> Controller Class Initialized
DEBUG - 2023-07-26 09:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:43:51 --> Database Driver Class Initialized
INFO - 2023-07-26 09:43:51 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:43:51 --> Model "Student_model" initialized
INFO - 2023-07-26 09:43:51 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:43:51 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:43:51 --> Final output sent to browser
DEBUG - 2023-07-26 09:43:51 --> Total execution time: 0.0410
INFO - 2023-07-26 09:43:57 --> Config Class Initialized
INFO - 2023-07-26 09:43:57 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:43:57 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:43:57 --> Utf8 Class Initialized
INFO - 2023-07-26 09:43:57 --> URI Class Initialized
INFO - 2023-07-26 09:43:57 --> Router Class Initialized
INFO - 2023-07-26 09:43:57 --> Output Class Initialized
INFO - 2023-07-26 09:43:57 --> Security Class Initialized
DEBUG - 2023-07-26 09:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:43:57 --> Input Class Initialized
INFO - 2023-07-26 09:43:57 --> Language Class Initialized
INFO - 2023-07-26 09:43:57 --> Loader Class Initialized
INFO - 2023-07-26 09:43:57 --> Helper loaded: url_helper
INFO - 2023-07-26 09:43:57 --> Helper loaded: form_helper
INFO - 2023-07-26 09:43:57 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:43:57 --> Controller Class Initialized
DEBUG - 2023-07-26 09:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:43:57 --> Database Driver Class Initialized
INFO - 2023-07-26 09:43:57 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:43:57 --> Model "Student_model" initialized
INFO - 2023-07-26 09:43:57 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:43:57 --> Config Class Initialized
INFO - 2023-07-26 09:43:57 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:43:57 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:43:57 --> Utf8 Class Initialized
INFO - 2023-07-26 09:43:57 --> URI Class Initialized
INFO - 2023-07-26 09:43:57 --> Router Class Initialized
INFO - 2023-07-26 09:43:57 --> Output Class Initialized
INFO - 2023-07-26 09:43:57 --> Security Class Initialized
DEBUG - 2023-07-26 09:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:43:57 --> Input Class Initialized
INFO - 2023-07-26 09:43:57 --> Language Class Initialized
ERROR - 2023-07-26 09:43:57 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:45:03 --> Config Class Initialized
INFO - 2023-07-26 09:45:03 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:03 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:03 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:03 --> URI Class Initialized
INFO - 2023-07-26 09:45:03 --> Router Class Initialized
INFO - 2023-07-26 09:45:03 --> Output Class Initialized
INFO - 2023-07-26 09:45:03 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:03 --> Input Class Initialized
INFO - 2023-07-26 09:45:03 --> Language Class Initialized
INFO - 2023-07-26 09:45:03 --> Loader Class Initialized
INFO - 2023-07-26 09:45:03 --> Helper loaded: url_helper
INFO - 2023-07-26 09:45:03 --> Helper loaded: form_helper
INFO - 2023-07-26 09:45:03 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:45:03 --> Controller Class Initialized
DEBUG - 2023-07-26 09:45:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:45:03 --> Database Driver Class Initialized
INFO - 2023-07-26 09:45:03 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:45:03 --> Model "Student_model" initialized
INFO - 2023-07-26 09:45:03 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:45:03 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:45:03 --> Final output sent to browser
DEBUG - 2023-07-26 09:45:03 --> Total execution time: 0.0254
INFO - 2023-07-26 09:45:04 --> Config Class Initialized
INFO - 2023-07-26 09:45:04 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:04 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:04 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:04 --> URI Class Initialized
INFO - 2023-07-26 09:45:04 --> Router Class Initialized
INFO - 2023-07-26 09:45:04 --> Output Class Initialized
INFO - 2023-07-26 09:45:04 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:04 --> Input Class Initialized
INFO - 2023-07-26 09:45:04 --> Language Class Initialized
INFO - 2023-07-26 09:45:04 --> Loader Class Initialized
INFO - 2023-07-26 09:45:04 --> Helper loaded: url_helper
INFO - 2023-07-26 09:45:04 --> Helper loaded: form_helper
INFO - 2023-07-26 09:45:04 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:45:04 --> Controller Class Initialized
DEBUG - 2023-07-26 09:45:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:45:04 --> Database Driver Class Initialized
INFO - 2023-07-26 09:45:04 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:45:04 --> Model "Student_model" initialized
INFO - 2023-07-26 09:45:04 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:45:04 --> Config Class Initialized
INFO - 2023-07-26 09:45:04 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:04 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:04 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:04 --> URI Class Initialized
INFO - 2023-07-26 09:45:04 --> Router Class Initialized
INFO - 2023-07-26 09:45:04 --> Output Class Initialized
INFO - 2023-07-26 09:45:04 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:04 --> Input Class Initialized
INFO - 2023-07-26 09:45:04 --> Language Class Initialized
ERROR - 2023-07-26 09:45:04 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:45:05 --> Config Class Initialized
INFO - 2023-07-26 09:45:05 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:05 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:05 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:05 --> URI Class Initialized
INFO - 2023-07-26 09:45:05 --> Router Class Initialized
INFO - 2023-07-26 09:45:05 --> Output Class Initialized
INFO - 2023-07-26 09:45:05 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:05 --> Input Class Initialized
INFO - 2023-07-26 09:45:05 --> Language Class Initialized
INFO - 2023-07-26 09:45:05 --> Loader Class Initialized
INFO - 2023-07-26 09:45:05 --> Helper loaded: url_helper
INFO - 2023-07-26 09:45:05 --> Helper loaded: form_helper
INFO - 2023-07-26 09:45:05 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:45:05 --> Controller Class Initialized
DEBUG - 2023-07-26 09:45:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:45:05 --> Database Driver Class Initialized
INFO - 2023-07-26 09:45:05 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:45:05 --> Model "Student_model" initialized
INFO - 2023-07-26 09:45:05 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:45:05 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:45:05 --> Final output sent to browser
DEBUG - 2023-07-26 09:45:05 --> Total execution time: 0.0269
INFO - 2023-07-26 09:45:06 --> Config Class Initialized
INFO - 2023-07-26 09:45:06 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:06 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:06 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:06 --> URI Class Initialized
INFO - 2023-07-26 09:45:06 --> Router Class Initialized
INFO - 2023-07-26 09:45:06 --> Output Class Initialized
INFO - 2023-07-26 09:45:06 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:06 --> Input Class Initialized
INFO - 2023-07-26 09:45:06 --> Language Class Initialized
INFO - 2023-07-26 09:45:06 --> Loader Class Initialized
INFO - 2023-07-26 09:45:06 --> Helper loaded: url_helper
INFO - 2023-07-26 09:45:06 --> Helper loaded: form_helper
INFO - 2023-07-26 09:45:06 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:45:06 --> Controller Class Initialized
DEBUG - 2023-07-26 09:45:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:45:06 --> Database Driver Class Initialized
INFO - 2023-07-26 09:45:06 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:45:06 --> Model "Student_model" initialized
INFO - 2023-07-26 09:45:06 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:45:06 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:45:06 --> Final output sent to browser
DEBUG - 2023-07-26 09:45:06 --> Total execution time: 0.0262
INFO - 2023-07-26 09:45:08 --> Config Class Initialized
INFO - 2023-07-26 09:45:08 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:08 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:08 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:08 --> URI Class Initialized
INFO - 2023-07-26 09:45:08 --> Router Class Initialized
INFO - 2023-07-26 09:45:08 --> Output Class Initialized
INFO - 2023-07-26 09:45:08 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:08 --> Input Class Initialized
INFO - 2023-07-26 09:45:08 --> Language Class Initialized
INFO - 2023-07-26 09:45:08 --> Loader Class Initialized
INFO - 2023-07-26 09:45:08 --> Helper loaded: url_helper
INFO - 2023-07-26 09:45:08 --> Helper loaded: form_helper
INFO - 2023-07-26 09:45:08 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:45:08 --> Controller Class Initialized
DEBUG - 2023-07-26 09:45:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:45:08 --> Database Driver Class Initialized
INFO - 2023-07-26 09:45:08 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:45:08 --> Model "Student_model" initialized
INFO - 2023-07-26 09:45:08 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:45:08 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:45:08 --> Final output sent to browser
DEBUG - 2023-07-26 09:45:08 --> Total execution time: 0.0429
INFO - 2023-07-26 09:45:12 --> Config Class Initialized
INFO - 2023-07-26 09:45:12 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:12 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:12 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:12 --> URI Class Initialized
INFO - 2023-07-26 09:45:12 --> Router Class Initialized
INFO - 2023-07-26 09:45:12 --> Output Class Initialized
INFO - 2023-07-26 09:45:12 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:12 --> Input Class Initialized
INFO - 2023-07-26 09:45:12 --> Language Class Initialized
INFO - 2023-07-26 09:45:12 --> Loader Class Initialized
INFO - 2023-07-26 09:45:12 --> Helper loaded: url_helper
INFO - 2023-07-26 09:45:12 --> Helper loaded: form_helper
INFO - 2023-07-26 09:45:12 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:45:12 --> Controller Class Initialized
DEBUG - 2023-07-26 09:45:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:45:12 --> Database Driver Class Initialized
INFO - 2023-07-26 09:45:12 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:45:12 --> Model "Student_model" initialized
INFO - 2023-07-26 09:45:12 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:45:12 --> Config Class Initialized
INFO - 2023-07-26 09:45:12 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:12 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:12 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:12 --> URI Class Initialized
INFO - 2023-07-26 09:45:12 --> Router Class Initialized
INFO - 2023-07-26 09:45:12 --> Output Class Initialized
INFO - 2023-07-26 09:45:12 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:12 --> Input Class Initialized
INFO - 2023-07-26 09:45:12 --> Language Class Initialized
ERROR - 2023-07-26 09:45:12 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:45:30 --> Config Class Initialized
INFO - 2023-07-26 09:45:30 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:30 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:30 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:30 --> URI Class Initialized
INFO - 2023-07-26 09:45:30 --> Router Class Initialized
INFO - 2023-07-26 09:45:30 --> Output Class Initialized
INFO - 2023-07-26 09:45:30 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:30 --> Input Class Initialized
INFO - 2023-07-26 09:45:30 --> Language Class Initialized
ERROR - 2023-07-26 09:45:30 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:45:31 --> Config Class Initialized
INFO - 2023-07-26 09:45:31 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:31 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:31 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:31 --> URI Class Initialized
INFO - 2023-07-26 09:45:31 --> Router Class Initialized
INFO - 2023-07-26 09:45:31 --> Output Class Initialized
INFO - 2023-07-26 09:45:31 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:31 --> Input Class Initialized
INFO - 2023-07-26 09:45:31 --> Language Class Initialized
ERROR - 2023-07-26 09:45:31 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:45:31 --> Config Class Initialized
INFO - 2023-07-26 09:45:31 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:31 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:31 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:31 --> URI Class Initialized
INFO - 2023-07-26 09:45:31 --> Router Class Initialized
INFO - 2023-07-26 09:45:31 --> Output Class Initialized
INFO - 2023-07-26 09:45:31 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:31 --> Input Class Initialized
INFO - 2023-07-26 09:45:31 --> Language Class Initialized
ERROR - 2023-07-26 09:45:31 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:45:31 --> Config Class Initialized
INFO - 2023-07-26 09:45:31 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:31 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:31 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:31 --> URI Class Initialized
INFO - 2023-07-26 09:45:31 --> Router Class Initialized
INFO - 2023-07-26 09:45:31 --> Output Class Initialized
INFO - 2023-07-26 09:45:31 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:31 --> Input Class Initialized
INFO - 2023-07-26 09:45:31 --> Language Class Initialized
ERROR - 2023-07-26 09:45:31 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:45:31 --> Config Class Initialized
INFO - 2023-07-26 09:45:31 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:31 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:31 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:31 --> URI Class Initialized
INFO - 2023-07-26 09:45:31 --> Router Class Initialized
INFO - 2023-07-26 09:45:31 --> Output Class Initialized
INFO - 2023-07-26 09:45:31 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:31 --> Input Class Initialized
INFO - 2023-07-26 09:45:31 --> Language Class Initialized
ERROR - 2023-07-26 09:45:31 --> 404 Page Not Found: Teacher_dashboard/index
INFO - 2023-07-26 09:45:32 --> Config Class Initialized
INFO - 2023-07-26 09:45:32 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:32 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:32 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:32 --> URI Class Initialized
INFO - 2023-07-26 09:45:32 --> Router Class Initialized
INFO - 2023-07-26 09:45:32 --> Output Class Initialized
INFO - 2023-07-26 09:45:32 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:32 --> Input Class Initialized
INFO - 2023-07-26 09:45:32 --> Language Class Initialized
INFO - 2023-07-26 09:45:32 --> Loader Class Initialized
INFO - 2023-07-26 09:45:32 --> Helper loaded: url_helper
INFO - 2023-07-26 09:45:32 --> Helper loaded: form_helper
INFO - 2023-07-26 09:45:32 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:45:32 --> Controller Class Initialized
DEBUG - 2023-07-26 09:45:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:45:32 --> Database Driver Class Initialized
INFO - 2023-07-26 09:45:32 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:45:32 --> Model "Student_model" initialized
INFO - 2023-07-26 09:45:32 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:45:32 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:45:32 --> Final output sent to browser
DEBUG - 2023-07-26 09:45:32 --> Total execution time: 0.0258
INFO - 2023-07-26 09:45:37 --> Config Class Initialized
INFO - 2023-07-26 09:45:37 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:37 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:37 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:37 --> URI Class Initialized
INFO - 2023-07-26 09:45:37 --> Router Class Initialized
INFO - 2023-07-26 09:45:37 --> Output Class Initialized
INFO - 2023-07-26 09:45:37 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:37 --> Input Class Initialized
INFO - 2023-07-26 09:45:37 --> Language Class Initialized
INFO - 2023-07-26 09:45:37 --> Loader Class Initialized
INFO - 2023-07-26 09:45:37 --> Helper loaded: url_helper
INFO - 2023-07-26 09:45:37 --> Helper loaded: form_helper
INFO - 2023-07-26 09:45:37 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:45:37 --> Controller Class Initialized
DEBUG - 2023-07-26 09:45:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:45:37 --> Database Driver Class Initialized
INFO - 2023-07-26 09:45:37 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:45:37 --> Model "Student_model" initialized
INFO - 2023-07-26 09:45:37 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:45:37 --> Config Class Initialized
INFO - 2023-07-26 09:45:37 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:37 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:37 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:37 --> URI Class Initialized
INFO - 2023-07-26 09:45:37 --> Router Class Initialized
INFO - 2023-07-26 09:45:37 --> Output Class Initialized
INFO - 2023-07-26 09:45:37 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:37 --> Input Class Initialized
INFO - 2023-07-26 09:45:37 --> Language Class Initialized
ERROR - 2023-07-26 09:45:37 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 09:45:38 --> Config Class Initialized
INFO - 2023-07-26 09:45:38 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:38 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:38 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:38 --> URI Class Initialized
INFO - 2023-07-26 09:45:38 --> Router Class Initialized
INFO - 2023-07-26 09:45:38 --> Output Class Initialized
INFO - 2023-07-26 09:45:38 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:38 --> Input Class Initialized
INFO - 2023-07-26 09:45:38 --> Language Class Initialized
INFO - 2023-07-26 09:45:38 --> Loader Class Initialized
INFO - 2023-07-26 09:45:38 --> Helper loaded: url_helper
INFO - 2023-07-26 09:45:38 --> Helper loaded: form_helper
INFO - 2023-07-26 09:45:38 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:45:38 --> Controller Class Initialized
DEBUG - 2023-07-26 09:45:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:45:38 --> Database Driver Class Initialized
INFO - 2023-07-26 09:45:38 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:45:38 --> Model "Student_model" initialized
INFO - 2023-07-26 09:45:38 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:45:38 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:45:38 --> Final output sent to browser
DEBUG - 2023-07-26 09:45:38 --> Total execution time: 0.0372
INFO - 2023-07-26 09:45:38 --> Config Class Initialized
INFO - 2023-07-26 09:45:38 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:38 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:38 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:38 --> URI Class Initialized
INFO - 2023-07-26 09:45:38 --> Router Class Initialized
INFO - 2023-07-26 09:45:38 --> Output Class Initialized
INFO - 2023-07-26 09:45:38 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:38 --> Input Class Initialized
INFO - 2023-07-26 09:45:38 --> Language Class Initialized
INFO - 2023-07-26 09:45:38 --> Loader Class Initialized
INFO - 2023-07-26 09:45:38 --> Helper loaded: url_helper
INFO - 2023-07-26 09:45:38 --> Helper loaded: form_helper
INFO - 2023-07-26 09:45:38 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:45:38 --> Controller Class Initialized
DEBUG - 2023-07-26 09:45:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:45:38 --> Database Driver Class Initialized
INFO - 2023-07-26 09:45:38 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:45:38 --> Model "Student_model" initialized
INFO - 2023-07-26 09:45:38 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:45:38 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:45:38 --> Final output sent to browser
DEBUG - 2023-07-26 09:45:38 --> Total execution time: 0.0463
INFO - 2023-07-26 09:45:45 --> Config Class Initialized
INFO - 2023-07-26 09:45:45 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:45 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:45 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:45 --> URI Class Initialized
INFO - 2023-07-26 09:45:45 --> Router Class Initialized
INFO - 2023-07-26 09:45:45 --> Output Class Initialized
INFO - 2023-07-26 09:45:45 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:45 --> Input Class Initialized
INFO - 2023-07-26 09:45:45 --> Language Class Initialized
INFO - 2023-07-26 09:45:45 --> Loader Class Initialized
INFO - 2023-07-26 09:45:45 --> Helper loaded: url_helper
INFO - 2023-07-26 09:45:45 --> Helper loaded: form_helper
INFO - 2023-07-26 09:45:45 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:45:45 --> Controller Class Initialized
DEBUG - 2023-07-26 09:45:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:45:45 --> Database Driver Class Initialized
INFO - 2023-07-26 09:45:45 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:45:45 --> Model "Student_model" initialized
INFO - 2023-07-26 09:45:45 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:45:45 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:45:45 --> Final output sent to browser
DEBUG - 2023-07-26 09:45:45 --> Total execution time: 0.0419
INFO - 2023-07-26 09:45:52 --> Config Class Initialized
INFO - 2023-07-26 09:45:52 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:52 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:52 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:52 --> URI Class Initialized
INFO - 2023-07-26 09:45:52 --> Router Class Initialized
INFO - 2023-07-26 09:45:52 --> Output Class Initialized
INFO - 2023-07-26 09:45:52 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:52 --> Input Class Initialized
INFO - 2023-07-26 09:45:52 --> Language Class Initialized
INFO - 2023-07-26 09:45:52 --> Loader Class Initialized
INFO - 2023-07-26 09:45:52 --> Helper loaded: url_helper
INFO - 2023-07-26 09:45:52 --> Helper loaded: form_helper
INFO - 2023-07-26 09:45:52 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:45:52 --> Controller Class Initialized
DEBUG - 2023-07-26 09:45:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:45:52 --> Database Driver Class Initialized
INFO - 2023-07-26 09:45:52 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:45:52 --> Model "Student_model" initialized
INFO - 2023-07-26 09:45:52 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:45:52 --> Config Class Initialized
INFO - 2023-07-26 09:45:52 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:52 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:52 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:52 --> URI Class Initialized
INFO - 2023-07-26 09:45:52 --> Router Class Initialized
INFO - 2023-07-26 09:45:52 --> Output Class Initialized
INFO - 2023-07-26 09:45:52 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:52 --> Input Class Initialized
INFO - 2023-07-26 09:45:52 --> Language Class Initialized
ERROR - 2023-07-26 09:45:52 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 09:45:53 --> Config Class Initialized
INFO - 2023-07-26 09:45:53 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:53 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:53 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:53 --> URI Class Initialized
INFO - 2023-07-26 09:45:53 --> Router Class Initialized
INFO - 2023-07-26 09:45:53 --> Output Class Initialized
INFO - 2023-07-26 09:45:53 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:53 --> Input Class Initialized
INFO - 2023-07-26 09:45:53 --> Language Class Initialized
INFO - 2023-07-26 09:45:53 --> Loader Class Initialized
INFO - 2023-07-26 09:45:53 --> Helper loaded: url_helper
INFO - 2023-07-26 09:45:53 --> Helper loaded: form_helper
INFO - 2023-07-26 09:45:53 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:45:53 --> Controller Class Initialized
DEBUG - 2023-07-26 09:45:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:45:53 --> Database Driver Class Initialized
INFO - 2023-07-26 09:45:53 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:45:53 --> Model "Student_model" initialized
INFO - 2023-07-26 09:45:53 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:45:53 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:45:53 --> Final output sent to browser
DEBUG - 2023-07-26 09:45:53 --> Total execution time: 0.0434
INFO - 2023-07-26 09:45:54 --> Config Class Initialized
INFO - 2023-07-26 09:45:54 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:54 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:54 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:54 --> URI Class Initialized
INFO - 2023-07-26 09:45:54 --> Router Class Initialized
INFO - 2023-07-26 09:45:54 --> Output Class Initialized
INFO - 2023-07-26 09:45:54 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:54 --> Input Class Initialized
INFO - 2023-07-26 09:45:54 --> Language Class Initialized
INFO - 2023-07-26 09:45:54 --> Loader Class Initialized
INFO - 2023-07-26 09:45:54 --> Helper loaded: url_helper
INFO - 2023-07-26 09:45:54 --> Helper loaded: form_helper
INFO - 2023-07-26 09:45:54 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:45:54 --> Controller Class Initialized
DEBUG - 2023-07-26 09:45:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:45:54 --> Database Driver Class Initialized
INFO - 2023-07-26 09:45:54 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:45:54 --> Model "Student_model" initialized
INFO - 2023-07-26 09:45:54 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:45:54 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:45:54 --> Final output sent to browser
DEBUG - 2023-07-26 09:45:54 --> Total execution time: 0.0475
INFO - 2023-07-26 09:45:57 --> Config Class Initialized
INFO - 2023-07-26 09:45:57 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:57 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:57 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:57 --> URI Class Initialized
INFO - 2023-07-26 09:45:57 --> Router Class Initialized
INFO - 2023-07-26 09:45:57 --> Output Class Initialized
INFO - 2023-07-26 09:45:57 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:57 --> Input Class Initialized
INFO - 2023-07-26 09:45:57 --> Language Class Initialized
INFO - 2023-07-26 09:45:57 --> Loader Class Initialized
INFO - 2023-07-26 09:45:57 --> Helper loaded: url_helper
INFO - 2023-07-26 09:45:57 --> Helper loaded: form_helper
INFO - 2023-07-26 09:45:57 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:45:57 --> Controller Class Initialized
DEBUG - 2023-07-26 09:45:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:45:57 --> Database Driver Class Initialized
INFO - 2023-07-26 09:45:57 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:45:57 --> Model "Student_model" initialized
INFO - 2023-07-26 09:45:57 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:45:57 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:45:57 --> Final output sent to browser
DEBUG - 2023-07-26 09:45:57 --> Total execution time: 0.0418
INFO - 2023-07-26 09:45:58 --> Config Class Initialized
INFO - 2023-07-26 09:45:58 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:58 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:58 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:58 --> URI Class Initialized
INFO - 2023-07-26 09:45:58 --> Router Class Initialized
INFO - 2023-07-26 09:45:58 --> Output Class Initialized
INFO - 2023-07-26 09:45:58 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:58 --> Input Class Initialized
INFO - 2023-07-26 09:45:58 --> Language Class Initialized
INFO - 2023-07-26 09:45:58 --> Loader Class Initialized
INFO - 2023-07-26 09:45:58 --> Helper loaded: url_helper
INFO - 2023-07-26 09:45:58 --> Helper loaded: form_helper
INFO - 2023-07-26 09:45:58 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:45:58 --> Controller Class Initialized
DEBUG - 2023-07-26 09:45:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:45:58 --> Database Driver Class Initialized
INFO - 2023-07-26 09:45:58 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:45:58 --> Model "Student_model" initialized
INFO - 2023-07-26 09:45:58 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:45:58 --> Config Class Initialized
INFO - 2023-07-26 09:45:58 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:45:58 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:45:58 --> Utf8 Class Initialized
INFO - 2023-07-26 09:45:58 --> URI Class Initialized
INFO - 2023-07-26 09:45:58 --> Router Class Initialized
INFO - 2023-07-26 09:45:58 --> Output Class Initialized
INFO - 2023-07-26 09:45:58 --> Security Class Initialized
DEBUG - 2023-07-26 09:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:45:58 --> Input Class Initialized
INFO - 2023-07-26 09:45:58 --> Language Class Initialized
ERROR - 2023-07-26 09:45:58 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 09:46:01 --> Config Class Initialized
INFO - 2023-07-26 09:46:01 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:46:01 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:46:01 --> Utf8 Class Initialized
INFO - 2023-07-26 09:46:01 --> URI Class Initialized
INFO - 2023-07-26 09:46:01 --> Router Class Initialized
INFO - 2023-07-26 09:46:01 --> Output Class Initialized
INFO - 2023-07-26 09:46:01 --> Security Class Initialized
DEBUG - 2023-07-26 09:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:46:01 --> Input Class Initialized
INFO - 2023-07-26 09:46:01 --> Language Class Initialized
INFO - 2023-07-26 09:46:01 --> Loader Class Initialized
INFO - 2023-07-26 09:46:01 --> Helper loaded: url_helper
INFO - 2023-07-26 09:46:01 --> Helper loaded: form_helper
INFO - 2023-07-26 09:46:01 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:46:01 --> Controller Class Initialized
DEBUG - 2023-07-26 09:46:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:46:01 --> Database Driver Class Initialized
INFO - 2023-07-26 09:46:01 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:46:01 --> Model "Student_model" initialized
INFO - 2023-07-26 09:46:01 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:46:01 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:46:01 --> Final output sent to browser
DEBUG - 2023-07-26 09:46:01 --> Total execution time: 0.0411
INFO - 2023-07-26 09:46:02 --> Config Class Initialized
INFO - 2023-07-26 09:46:02 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:46:02 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:46:02 --> Utf8 Class Initialized
INFO - 2023-07-26 09:46:02 --> URI Class Initialized
INFO - 2023-07-26 09:46:02 --> Router Class Initialized
INFO - 2023-07-26 09:46:02 --> Output Class Initialized
INFO - 2023-07-26 09:46:02 --> Security Class Initialized
DEBUG - 2023-07-26 09:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:46:02 --> Input Class Initialized
INFO - 2023-07-26 09:46:02 --> Language Class Initialized
INFO - 2023-07-26 09:46:02 --> Loader Class Initialized
INFO - 2023-07-26 09:46:02 --> Helper loaded: url_helper
INFO - 2023-07-26 09:46:02 --> Helper loaded: form_helper
INFO - 2023-07-26 09:46:02 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:46:02 --> Controller Class Initialized
DEBUG - 2023-07-26 09:46:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:46:02 --> Database Driver Class Initialized
INFO - 2023-07-26 09:46:02 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:46:02 --> Model "Student_model" initialized
INFO - 2023-07-26 09:46:02 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:46:02 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:46:02 --> Final output sent to browser
DEBUG - 2023-07-26 09:46:02 --> Total execution time: 0.0354
INFO - 2023-07-26 09:46:18 --> Config Class Initialized
INFO - 2023-07-26 09:46:18 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:46:18 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:46:18 --> Utf8 Class Initialized
INFO - 2023-07-26 09:46:18 --> URI Class Initialized
INFO - 2023-07-26 09:46:18 --> Router Class Initialized
INFO - 2023-07-26 09:46:18 --> Output Class Initialized
INFO - 2023-07-26 09:46:18 --> Security Class Initialized
DEBUG - 2023-07-26 09:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:46:18 --> Input Class Initialized
INFO - 2023-07-26 09:46:18 --> Language Class Initialized
INFO - 2023-07-26 09:46:18 --> Loader Class Initialized
INFO - 2023-07-26 09:46:18 --> Helper loaded: url_helper
INFO - 2023-07-26 09:46:18 --> Helper loaded: form_helper
INFO - 2023-07-26 09:46:18 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:46:18 --> Controller Class Initialized
DEBUG - 2023-07-26 09:46:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:46:18 --> Database Driver Class Initialized
INFO - 2023-07-26 09:46:18 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:46:18 --> Model "Student_model" initialized
INFO - 2023-07-26 09:46:18 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:46:18 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:46:18 --> Final output sent to browser
DEBUG - 2023-07-26 09:46:18 --> Total execution time: 0.0418
INFO - 2023-07-26 09:47:24 --> Config Class Initialized
INFO - 2023-07-26 09:47:24 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:47:24 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:47:24 --> Utf8 Class Initialized
INFO - 2023-07-26 09:47:24 --> URI Class Initialized
INFO - 2023-07-26 09:47:24 --> Router Class Initialized
INFO - 2023-07-26 09:47:24 --> Output Class Initialized
INFO - 2023-07-26 09:47:24 --> Security Class Initialized
DEBUG - 2023-07-26 09:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:47:24 --> Input Class Initialized
INFO - 2023-07-26 09:47:24 --> Language Class Initialized
INFO - 2023-07-26 09:47:24 --> Loader Class Initialized
INFO - 2023-07-26 09:47:24 --> Helper loaded: url_helper
INFO - 2023-07-26 09:47:24 --> Helper loaded: form_helper
INFO - 2023-07-26 09:47:24 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:47:24 --> Controller Class Initialized
DEBUG - 2023-07-26 09:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:47:24 --> Database Driver Class Initialized
INFO - 2023-07-26 09:47:24 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:47:24 --> Model "Student_model" initialized
INFO - 2023-07-26 09:47:24 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:47:24 --> Config Class Initialized
INFO - 2023-07-26 09:47:24 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:47:24 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:47:24 --> Utf8 Class Initialized
INFO - 2023-07-26 09:47:24 --> URI Class Initialized
INFO - 2023-07-26 09:47:24 --> Router Class Initialized
INFO - 2023-07-26 09:47:24 --> Output Class Initialized
INFO - 2023-07-26 09:47:24 --> Security Class Initialized
DEBUG - 2023-07-26 09:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:47:24 --> Input Class Initialized
INFO - 2023-07-26 09:47:24 --> Language Class Initialized
ERROR - 2023-07-26 09:47:24 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 09:47:34 --> Config Class Initialized
INFO - 2023-07-26 09:47:34 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:47:34 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:47:34 --> Utf8 Class Initialized
INFO - 2023-07-26 09:47:34 --> URI Class Initialized
INFO - 2023-07-26 09:47:34 --> Router Class Initialized
INFO - 2023-07-26 09:47:34 --> Output Class Initialized
INFO - 2023-07-26 09:47:34 --> Security Class Initialized
DEBUG - 2023-07-26 09:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:47:34 --> Input Class Initialized
INFO - 2023-07-26 09:47:34 --> Language Class Initialized
INFO - 2023-07-26 09:47:34 --> Loader Class Initialized
INFO - 2023-07-26 09:47:34 --> Helper loaded: url_helper
INFO - 2023-07-26 09:47:34 --> Helper loaded: form_helper
INFO - 2023-07-26 09:47:34 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:47:34 --> Controller Class Initialized
DEBUG - 2023-07-26 09:47:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:47:34 --> Database Driver Class Initialized
INFO - 2023-07-26 09:47:34 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:47:34 --> Model "Student_model" initialized
INFO - 2023-07-26 09:47:34 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:47:34 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:47:34 --> Final output sent to browser
DEBUG - 2023-07-26 09:47:34 --> Total execution time: 0.0339
INFO - 2023-07-26 09:47:37 --> Config Class Initialized
INFO - 2023-07-26 09:47:37 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:47:37 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:47:37 --> Utf8 Class Initialized
INFO - 2023-07-26 09:47:37 --> URI Class Initialized
INFO - 2023-07-26 09:47:37 --> Router Class Initialized
INFO - 2023-07-26 09:47:37 --> Output Class Initialized
INFO - 2023-07-26 09:47:37 --> Security Class Initialized
DEBUG - 2023-07-26 09:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:47:37 --> Input Class Initialized
INFO - 2023-07-26 09:47:37 --> Language Class Initialized
INFO - 2023-07-26 09:47:37 --> Loader Class Initialized
INFO - 2023-07-26 09:47:37 --> Helper loaded: url_helper
INFO - 2023-07-26 09:47:37 --> Helper loaded: form_helper
INFO - 2023-07-26 09:47:37 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:47:37 --> Controller Class Initialized
DEBUG - 2023-07-26 09:47:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:47:37 --> Database Driver Class Initialized
INFO - 2023-07-26 09:47:37 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:47:37 --> Model "Student_model" initialized
INFO - 2023-07-26 09:47:37 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:47:37 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:47:37 --> Final output sent to browser
DEBUG - 2023-07-26 09:47:37 --> Total execution time: 0.0395
INFO - 2023-07-26 09:48:14 --> Config Class Initialized
INFO - 2023-07-26 09:48:14 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:48:14 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:48:14 --> Utf8 Class Initialized
INFO - 2023-07-26 09:48:14 --> URI Class Initialized
INFO - 2023-07-26 09:48:14 --> Router Class Initialized
INFO - 2023-07-26 09:48:14 --> Output Class Initialized
INFO - 2023-07-26 09:48:14 --> Security Class Initialized
DEBUG - 2023-07-26 09:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:48:14 --> Input Class Initialized
INFO - 2023-07-26 09:48:14 --> Language Class Initialized
INFO - 2023-07-26 09:48:14 --> Loader Class Initialized
INFO - 2023-07-26 09:48:14 --> Helper loaded: url_helper
INFO - 2023-07-26 09:48:14 --> Helper loaded: form_helper
INFO - 2023-07-26 09:48:14 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:48:14 --> Controller Class Initialized
DEBUG - 2023-07-26 09:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:48:14 --> Database Driver Class Initialized
INFO - 2023-07-26 09:48:14 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:48:14 --> Model "Student_model" initialized
INFO - 2023-07-26 09:48:14 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:48:14 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:48:14 --> Final output sent to browser
DEBUG - 2023-07-26 09:48:14 --> Total execution time: 0.0263
INFO - 2023-07-26 09:48:19 --> Config Class Initialized
INFO - 2023-07-26 09:48:19 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:48:19 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:48:19 --> Utf8 Class Initialized
INFO - 2023-07-26 09:48:19 --> URI Class Initialized
INFO - 2023-07-26 09:48:19 --> Router Class Initialized
INFO - 2023-07-26 09:48:19 --> Output Class Initialized
INFO - 2023-07-26 09:48:19 --> Security Class Initialized
DEBUG - 2023-07-26 09:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:48:19 --> Input Class Initialized
INFO - 2023-07-26 09:48:19 --> Language Class Initialized
INFO - 2023-07-26 09:48:19 --> Loader Class Initialized
INFO - 2023-07-26 09:48:19 --> Helper loaded: url_helper
INFO - 2023-07-26 09:48:19 --> Helper loaded: form_helper
INFO - 2023-07-26 09:48:19 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:48:19 --> Controller Class Initialized
DEBUG - 2023-07-26 09:48:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:48:19 --> Database Driver Class Initialized
INFO - 2023-07-26 09:48:19 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:48:19 --> Model "Student_model" initialized
INFO - 2023-07-26 09:48:19 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:48:19 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 09:48:19 --> Final output sent to browser
DEBUG - 2023-07-26 09:48:19 --> Total execution time: 0.0429
INFO - 2023-07-26 09:48:25 --> Config Class Initialized
INFO - 2023-07-26 09:48:25 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:48:25 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:48:25 --> Utf8 Class Initialized
INFO - 2023-07-26 09:48:25 --> URI Class Initialized
INFO - 2023-07-26 09:48:25 --> Router Class Initialized
INFO - 2023-07-26 09:48:25 --> Output Class Initialized
INFO - 2023-07-26 09:48:25 --> Security Class Initialized
DEBUG - 2023-07-26 09:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:48:25 --> Input Class Initialized
INFO - 2023-07-26 09:48:25 --> Language Class Initialized
INFO - 2023-07-26 09:48:25 --> Loader Class Initialized
INFO - 2023-07-26 09:48:25 --> Helper loaded: url_helper
INFO - 2023-07-26 09:48:25 --> Helper loaded: form_helper
INFO - 2023-07-26 09:48:25 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:48:25 --> Controller Class Initialized
DEBUG - 2023-07-26 09:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:48:25 --> Database Driver Class Initialized
INFO - 2023-07-26 09:48:25 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:48:25 --> Model "Student_model" initialized
INFO - 2023-07-26 09:48:25 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:48:25 --> Config Class Initialized
INFO - 2023-07-26 09:48:25 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:48:25 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:48:25 --> Utf8 Class Initialized
INFO - 2023-07-26 09:48:25 --> URI Class Initialized
INFO - 2023-07-26 09:48:25 --> Router Class Initialized
INFO - 2023-07-26 09:48:25 --> Output Class Initialized
INFO - 2023-07-26 09:48:25 --> Security Class Initialized
DEBUG - 2023-07-26 09:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:48:25 --> Input Class Initialized
INFO - 2023-07-26 09:48:25 --> Language Class Initialized
INFO - 2023-07-26 09:48:25 --> Loader Class Initialized
INFO - 2023-07-26 09:48:25 --> Helper loaded: url_helper
INFO - 2023-07-26 09:48:25 --> Helper loaded: form_helper
INFO - 2023-07-26 09:48:25 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:48:25 --> Controller Class Initialized
DEBUG - 2023-07-26 09:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:48:25 --> Database Driver Class Initialized
INFO - 2023-07-26 09:48:25 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:48:25 --> Model "Student_model" initialized
INFO - 2023-07-26 09:48:25 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:48:25 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:48:25 --> Final output sent to browser
DEBUG - 2023-07-26 09:48:25 --> Total execution time: 0.0431
INFO - 2023-07-26 09:49:10 --> Config Class Initialized
INFO - 2023-07-26 09:49:10 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:49:10 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:49:10 --> Utf8 Class Initialized
INFO - 2023-07-26 09:49:10 --> URI Class Initialized
INFO - 2023-07-26 09:49:10 --> Router Class Initialized
INFO - 2023-07-26 09:49:10 --> Output Class Initialized
INFO - 2023-07-26 09:49:10 --> Security Class Initialized
DEBUG - 2023-07-26 09:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:49:10 --> Input Class Initialized
INFO - 2023-07-26 09:49:10 --> Language Class Initialized
INFO - 2023-07-26 09:49:10 --> Loader Class Initialized
INFO - 2023-07-26 09:49:10 --> Helper loaded: url_helper
INFO - 2023-07-26 09:49:10 --> Helper loaded: form_helper
INFO - 2023-07-26 09:49:10 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:49:10 --> Controller Class Initialized
DEBUG - 2023-07-26 09:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:49:10 --> Database Driver Class Initialized
INFO - 2023-07-26 09:49:10 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:49:10 --> Model "Student_model" initialized
INFO - 2023-07-26 09:49:10 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:49:36 --> Config Class Initialized
INFO - 2023-07-26 09:49:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:49:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:49:36 --> Utf8 Class Initialized
INFO - 2023-07-26 09:49:36 --> URI Class Initialized
INFO - 2023-07-26 09:49:36 --> Router Class Initialized
INFO - 2023-07-26 09:49:36 --> Output Class Initialized
INFO - 2023-07-26 09:49:36 --> Security Class Initialized
DEBUG - 2023-07-26 09:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:49:36 --> Input Class Initialized
INFO - 2023-07-26 09:49:36 --> Language Class Initialized
INFO - 2023-07-26 09:49:36 --> Loader Class Initialized
INFO - 2023-07-26 09:49:36 --> Helper loaded: url_helper
INFO - 2023-07-26 09:49:36 --> Helper loaded: form_helper
INFO - 2023-07-26 09:49:36 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:49:36 --> Controller Class Initialized
DEBUG - 2023-07-26 09:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:49:36 --> Database Driver Class Initialized
INFO - 2023-07-26 09:49:37 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:49:37 --> Model "Student_model" initialized
INFO - 2023-07-26 09:49:37 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:49:37 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:49:37 --> Final output sent to browser
DEBUG - 2023-07-26 09:49:37 --> Total execution time: 0.0255
INFO - 2023-07-26 09:49:40 --> Config Class Initialized
INFO - 2023-07-26 09:49:40 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:49:40 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:49:40 --> Utf8 Class Initialized
INFO - 2023-07-26 09:49:40 --> URI Class Initialized
INFO - 2023-07-26 09:49:40 --> Router Class Initialized
INFO - 2023-07-26 09:49:40 --> Output Class Initialized
INFO - 2023-07-26 09:49:40 --> Security Class Initialized
DEBUG - 2023-07-26 09:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:49:40 --> Input Class Initialized
INFO - 2023-07-26 09:49:40 --> Language Class Initialized
INFO - 2023-07-26 09:49:40 --> Loader Class Initialized
INFO - 2023-07-26 09:49:40 --> Helper loaded: url_helper
INFO - 2023-07-26 09:49:40 --> Helper loaded: form_helper
INFO - 2023-07-26 09:49:40 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:49:40 --> Controller Class Initialized
DEBUG - 2023-07-26 09:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:49:40 --> Database Driver Class Initialized
INFO - 2023-07-26 09:49:40 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:49:40 --> Model "Student_model" initialized
INFO - 2023-07-26 09:49:40 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:49:40 --> Config Class Initialized
INFO - 2023-07-26 09:49:40 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:49:40 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:49:40 --> Utf8 Class Initialized
INFO - 2023-07-26 09:49:40 --> URI Class Initialized
INFO - 2023-07-26 09:49:40 --> Router Class Initialized
INFO - 2023-07-26 09:49:40 --> Output Class Initialized
INFO - 2023-07-26 09:49:40 --> Security Class Initialized
DEBUG - 2023-07-26 09:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:49:40 --> Input Class Initialized
INFO - 2023-07-26 09:49:40 --> Language Class Initialized
INFO - 2023-07-26 09:49:40 --> Loader Class Initialized
INFO - 2023-07-26 09:49:40 --> Helper loaded: url_helper
INFO - 2023-07-26 09:49:40 --> Helper loaded: form_helper
INFO - 2023-07-26 09:49:40 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:49:40 --> Controller Class Initialized
DEBUG - 2023-07-26 09:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:49:40 --> Database Driver Class Initialized
INFO - 2023-07-26 09:49:40 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:49:40 --> Model "Student_model" initialized
INFO - 2023-07-26 09:49:40 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:49:40 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:49:40 --> Final output sent to browser
DEBUG - 2023-07-26 09:49:40 --> Total execution time: 0.0417
INFO - 2023-07-26 09:59:19 --> Config Class Initialized
INFO - 2023-07-26 09:59:19 --> Hooks Class Initialized
DEBUG - 2023-07-26 09:59:19 --> UTF-8 Support Enabled
INFO - 2023-07-26 09:59:19 --> Utf8 Class Initialized
INFO - 2023-07-26 09:59:19 --> URI Class Initialized
INFO - 2023-07-26 09:59:19 --> Router Class Initialized
INFO - 2023-07-26 09:59:19 --> Output Class Initialized
INFO - 2023-07-26 09:59:19 --> Security Class Initialized
DEBUG - 2023-07-26 09:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 09:59:19 --> Input Class Initialized
INFO - 2023-07-26 09:59:19 --> Language Class Initialized
INFO - 2023-07-26 09:59:19 --> Loader Class Initialized
INFO - 2023-07-26 09:59:19 --> Helper loaded: url_helper
INFO - 2023-07-26 09:59:19 --> Helper loaded: form_helper
INFO - 2023-07-26 09:59:19 --> Form Validation Class Initialized
DEBUG - 2023-07-26 09:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 09:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 09:59:19 --> Controller Class Initialized
DEBUG - 2023-07-26 09:59:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 09:59:19 --> Database Driver Class Initialized
INFO - 2023-07-26 09:59:19 --> Model "Admin_model" initialized
INFO - 2023-07-26 09:59:19 --> Model "Student_model" initialized
INFO - 2023-07-26 09:59:19 --> Model "Teacher_model" initialized
INFO - 2023-07-26 09:59:19 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 09:59:19 --> Final output sent to browser
DEBUG - 2023-07-26 09:59:19 --> Total execution time: 0.0261
INFO - 2023-07-26 10:01:48 --> Config Class Initialized
INFO - 2023-07-26 10:01:48 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:01:48 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:01:48 --> Utf8 Class Initialized
INFO - 2023-07-26 10:01:48 --> URI Class Initialized
DEBUG - 2023-07-26 10:01:48 --> No URI present. Default controller set.
INFO - 2023-07-26 10:01:48 --> Router Class Initialized
INFO - 2023-07-26 10:01:48 --> Output Class Initialized
INFO - 2023-07-26 10:01:48 --> Security Class Initialized
DEBUG - 2023-07-26 10:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:01:48 --> Input Class Initialized
INFO - 2023-07-26 10:01:48 --> Language Class Initialized
INFO - 2023-07-26 10:01:48 --> Loader Class Initialized
INFO - 2023-07-26 10:01:48 --> Helper loaded: url_helper
INFO - 2023-07-26 10:01:48 --> Helper loaded: form_helper
INFO - 2023-07-26 10:01:48 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:01:48 --> Controller Class Initialized
INFO - 2023-07-26 10:01:48 --> Database Driver Class Initialized
INFO - 2023-07-26 10:01:48 --> Model "Student_model" initialized
DEBUG - 2023-07-26 10:01:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:01:48 --> File loaded: C:\xampp\htdocs\Project\application\views\register.php
INFO - 2023-07-26 10:01:48 --> Final output sent to browser
DEBUG - 2023-07-26 10:01:48 --> Total execution time: 0.0375
INFO - 2023-07-26 10:01:51 --> Config Class Initialized
INFO - 2023-07-26 10:01:51 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:01:51 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:01:51 --> Utf8 Class Initialized
INFO - 2023-07-26 10:01:51 --> URI Class Initialized
INFO - 2023-07-26 10:01:51 --> Router Class Initialized
INFO - 2023-07-26 10:01:51 --> Output Class Initialized
INFO - 2023-07-26 10:01:51 --> Security Class Initialized
DEBUG - 2023-07-26 10:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:01:51 --> Input Class Initialized
INFO - 2023-07-26 10:01:51 --> Language Class Initialized
INFO - 2023-07-26 10:01:51 --> Loader Class Initialized
INFO - 2023-07-26 10:01:51 --> Helper loaded: url_helper
INFO - 2023-07-26 10:01:51 --> Helper loaded: form_helper
INFO - 2023-07-26 10:01:51 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:01:51 --> Controller Class Initialized
DEBUG - 2023-07-26 10:01:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:01:51 --> Database Driver Class Initialized
INFO - 2023-07-26 10:01:51 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:01:51 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/login.php
INFO - 2023-07-26 10:01:51 --> Final output sent to browser
DEBUG - 2023-07-26 10:01:51 --> Total execution time: 0.0394
INFO - 2023-07-26 10:02:00 --> Config Class Initialized
INFO - 2023-07-26 10:02:00 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:02:00 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:02:00 --> Utf8 Class Initialized
INFO - 2023-07-26 10:02:00 --> URI Class Initialized
INFO - 2023-07-26 10:02:00 --> Router Class Initialized
INFO - 2023-07-26 10:02:00 --> Output Class Initialized
INFO - 2023-07-26 10:02:00 --> Security Class Initialized
DEBUG - 2023-07-26 10:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:02:00 --> Input Class Initialized
INFO - 2023-07-26 10:02:00 --> Language Class Initialized
INFO - 2023-07-26 10:02:00 --> Loader Class Initialized
INFO - 2023-07-26 10:02:00 --> Helper loaded: url_helper
INFO - 2023-07-26 10:02:00 --> Helper loaded: form_helper
INFO - 2023-07-26 10:02:00 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:02:00 --> Controller Class Initialized
DEBUG - 2023-07-26 10:02:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:02:00 --> Database Driver Class Initialized
INFO - 2023-07-26 10:02:00 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:02:00 --> Config Class Initialized
INFO - 2023-07-26 10:02:00 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:02:00 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:02:00 --> Utf8 Class Initialized
INFO - 2023-07-26 10:02:00 --> URI Class Initialized
INFO - 2023-07-26 10:02:00 --> Router Class Initialized
INFO - 2023-07-26 10:02:00 --> Output Class Initialized
INFO - 2023-07-26 10:02:00 --> Security Class Initialized
DEBUG - 2023-07-26 10:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:02:00 --> Input Class Initialized
INFO - 2023-07-26 10:02:00 --> Language Class Initialized
INFO - 2023-07-26 10:02:00 --> Loader Class Initialized
INFO - 2023-07-26 10:02:00 --> Helper loaded: url_helper
INFO - 2023-07-26 10:02:00 --> Helper loaded: form_helper
INFO - 2023-07-26 10:02:00 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:02:00 --> Controller Class Initialized
DEBUG - 2023-07-26 10:02:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:02:00 --> Database Driver Class Initialized
INFO - 2023-07-26 10:02:00 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:02:00 --> Model "Student_model" initialized
INFO - 2023-07-26 10:02:00 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:02:00 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/dashboard.php
INFO - 2023-07-26 10:02:00 --> Final output sent to browser
DEBUG - 2023-07-26 10:02:00 --> Total execution time: 0.0479
INFO - 2023-07-26 10:02:14 --> Config Class Initialized
INFO - 2023-07-26 10:02:14 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:02:14 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:02:14 --> Utf8 Class Initialized
INFO - 2023-07-26 10:02:14 --> URI Class Initialized
INFO - 2023-07-26 10:02:14 --> Router Class Initialized
INFO - 2023-07-26 10:02:14 --> Output Class Initialized
INFO - 2023-07-26 10:02:14 --> Security Class Initialized
DEBUG - 2023-07-26 10:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:02:14 --> Input Class Initialized
INFO - 2023-07-26 10:02:14 --> Language Class Initialized
INFO - 2023-07-26 10:02:14 --> Loader Class Initialized
INFO - 2023-07-26 10:02:14 --> Helper loaded: url_helper
INFO - 2023-07-26 10:02:14 --> Helper loaded: form_helper
INFO - 2023-07-26 10:02:14 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:02:14 --> Controller Class Initialized
DEBUG - 2023-07-26 10:02:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:02:14 --> Database Driver Class Initialized
INFO - 2023-07-26 10:02:14 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:02:14 --> Model "Student_model" initialized
INFO - 2023-07-26 10:02:14 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:02:14 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_student.php
INFO - 2023-07-26 10:02:14 --> Final output sent to browser
DEBUG - 2023-07-26 10:02:14 --> Total execution time: 0.0448
INFO - 2023-07-26 10:02:19 --> Config Class Initialized
INFO - 2023-07-26 10:02:19 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:02:19 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:02:19 --> Utf8 Class Initialized
INFO - 2023-07-26 10:02:19 --> URI Class Initialized
INFO - 2023-07-26 10:02:19 --> Router Class Initialized
INFO - 2023-07-26 10:02:19 --> Output Class Initialized
INFO - 2023-07-26 10:02:19 --> Security Class Initialized
DEBUG - 2023-07-26 10:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:02:19 --> Input Class Initialized
INFO - 2023-07-26 10:02:19 --> Language Class Initialized
INFO - 2023-07-26 10:02:19 --> Loader Class Initialized
INFO - 2023-07-26 10:02:19 --> Helper loaded: url_helper
INFO - 2023-07-26 10:02:19 --> Helper loaded: form_helper
INFO - 2023-07-26 10:02:19 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:02:19 --> Controller Class Initialized
DEBUG - 2023-07-26 10:02:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:02:19 --> Database Driver Class Initialized
INFO - 2023-07-26 10:02:19 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:02:19 --> Model "Student_model" initialized
INFO - 2023-07-26 10:02:19 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:02:20 --> Config Class Initialized
INFO - 2023-07-26 10:02:20 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:02:20 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:02:20 --> Utf8 Class Initialized
INFO - 2023-07-26 10:02:20 --> URI Class Initialized
INFO - 2023-07-26 10:02:20 --> Router Class Initialized
INFO - 2023-07-26 10:02:20 --> Output Class Initialized
INFO - 2023-07-26 10:02:20 --> Security Class Initialized
DEBUG - 2023-07-26 10:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:02:20 --> Input Class Initialized
INFO - 2023-07-26 10:02:20 --> Language Class Initialized
INFO - 2023-07-26 10:02:20 --> Loader Class Initialized
INFO - 2023-07-26 10:02:20 --> Helper loaded: url_helper
INFO - 2023-07-26 10:02:20 --> Helper loaded: form_helper
INFO - 2023-07-26 10:02:20 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:02:20 --> Controller Class Initialized
DEBUG - 2023-07-26 10:02:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:02:20 --> Database Driver Class Initialized
INFO - 2023-07-26 10:02:20 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:02:20 --> Model "Student_model" initialized
INFO - 2023-07-26 10:02:20 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:02:20 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/dashboard.php
INFO - 2023-07-26 10:02:20 --> Final output sent to browser
DEBUG - 2023-07-26 10:02:20 --> Total execution time: 0.0415
INFO - 2023-07-26 10:02:30 --> Config Class Initialized
INFO - 2023-07-26 10:02:30 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:02:30 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:02:30 --> Utf8 Class Initialized
INFO - 2023-07-26 10:02:30 --> URI Class Initialized
INFO - 2023-07-26 10:02:30 --> Router Class Initialized
INFO - 2023-07-26 10:02:30 --> Output Class Initialized
INFO - 2023-07-26 10:02:30 --> Security Class Initialized
DEBUG - 2023-07-26 10:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:02:30 --> Input Class Initialized
INFO - 2023-07-26 10:02:30 --> Language Class Initialized
INFO - 2023-07-26 10:02:30 --> Loader Class Initialized
INFO - 2023-07-26 10:02:30 --> Helper loaded: url_helper
INFO - 2023-07-26 10:02:30 --> Helper loaded: form_helper
INFO - 2023-07-26 10:02:30 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:02:30 --> Controller Class Initialized
DEBUG - 2023-07-26 10:02:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:02:30 --> Database Driver Class Initialized
INFO - 2023-07-26 10:02:30 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:02:30 --> Model "Student_model" initialized
INFO - 2023-07-26 10:02:30 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:02:30 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:02:30 --> Final output sent to browser
DEBUG - 2023-07-26 10:02:30 --> Total execution time: 0.0464
INFO - 2023-07-26 10:11:14 --> Config Class Initialized
INFO - 2023-07-26 10:11:14 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:11:14 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:11:14 --> Utf8 Class Initialized
INFO - 2023-07-26 10:11:14 --> URI Class Initialized
INFO - 2023-07-26 10:11:14 --> Router Class Initialized
INFO - 2023-07-26 10:11:14 --> Output Class Initialized
INFO - 2023-07-26 10:11:14 --> Security Class Initialized
DEBUG - 2023-07-26 10:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:11:14 --> Input Class Initialized
INFO - 2023-07-26 10:11:14 --> Language Class Initialized
INFO - 2023-07-26 10:11:14 --> Loader Class Initialized
INFO - 2023-07-26 10:11:14 --> Helper loaded: url_helper
INFO - 2023-07-26 10:11:14 --> Helper loaded: form_helper
INFO - 2023-07-26 10:11:14 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:11:14 --> Controller Class Initialized
DEBUG - 2023-07-26 10:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:11:14 --> Database Driver Class Initialized
INFO - 2023-07-26 10:11:14 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:11:14 --> Model "Student_model" initialized
INFO - 2023-07-26 10:11:14 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:11:14 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:11:14 --> Final output sent to browser
DEBUG - 2023-07-26 10:11:14 --> Total execution time: 0.0260
INFO - 2023-07-26 10:12:20 --> Config Class Initialized
INFO - 2023-07-26 10:12:20 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:12:20 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:12:20 --> Utf8 Class Initialized
INFO - 2023-07-26 10:12:20 --> URI Class Initialized
INFO - 2023-07-26 10:12:20 --> Router Class Initialized
INFO - 2023-07-26 10:12:20 --> Output Class Initialized
INFO - 2023-07-26 10:12:20 --> Security Class Initialized
DEBUG - 2023-07-26 10:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:12:20 --> Input Class Initialized
INFO - 2023-07-26 10:12:20 --> Language Class Initialized
INFO - 2023-07-26 10:12:20 --> Loader Class Initialized
INFO - 2023-07-26 10:12:20 --> Helper loaded: url_helper
INFO - 2023-07-26 10:12:20 --> Helper loaded: form_helper
INFO - 2023-07-26 10:12:20 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:12:20 --> Controller Class Initialized
DEBUG - 2023-07-26 10:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:12:20 --> Database Driver Class Initialized
INFO - 2023-07-26 10:12:20 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:12:20 --> Model "Student_model" initialized
INFO - 2023-07-26 10:12:20 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:12:20 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:12:20 --> Final output sent to browser
DEBUG - 2023-07-26 10:12:20 --> Total execution time: 0.0410
INFO - 2023-07-26 10:12:26 --> Config Class Initialized
INFO - 2023-07-26 10:12:26 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:12:26 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:12:26 --> Utf8 Class Initialized
INFO - 2023-07-26 10:12:26 --> URI Class Initialized
INFO - 2023-07-26 10:12:26 --> Router Class Initialized
INFO - 2023-07-26 10:12:26 --> Output Class Initialized
INFO - 2023-07-26 10:12:26 --> Security Class Initialized
DEBUG - 2023-07-26 10:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:12:26 --> Input Class Initialized
INFO - 2023-07-26 10:12:26 --> Language Class Initialized
ERROR - 2023-07-26 10:12:26 --> 404 Page Not Found: Teacher_dashboard/import_csv
INFO - 2023-07-26 10:12:52 --> Config Class Initialized
INFO - 2023-07-26 10:12:52 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:12:52 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:12:52 --> Utf8 Class Initialized
INFO - 2023-07-26 10:12:52 --> URI Class Initialized
INFO - 2023-07-26 10:12:52 --> Router Class Initialized
INFO - 2023-07-26 10:12:52 --> Output Class Initialized
INFO - 2023-07-26 10:12:52 --> Security Class Initialized
DEBUG - 2023-07-26 10:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:12:52 --> Input Class Initialized
INFO - 2023-07-26 10:12:52 --> Language Class Initialized
ERROR - 2023-07-26 10:12:52 --> 404 Page Not Found: Teacher_dashboard/import_csv
INFO - 2023-07-26 10:12:53 --> Config Class Initialized
INFO - 2023-07-26 10:12:53 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:12:53 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:12:53 --> Utf8 Class Initialized
INFO - 2023-07-26 10:12:53 --> URI Class Initialized
INFO - 2023-07-26 10:12:53 --> Router Class Initialized
INFO - 2023-07-26 10:12:53 --> Output Class Initialized
INFO - 2023-07-26 10:12:53 --> Security Class Initialized
DEBUG - 2023-07-26 10:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:12:53 --> Input Class Initialized
INFO - 2023-07-26 10:12:53 --> Language Class Initialized
INFO - 2023-07-26 10:12:53 --> Loader Class Initialized
INFO - 2023-07-26 10:12:53 --> Helper loaded: url_helper
INFO - 2023-07-26 10:12:53 --> Helper loaded: form_helper
INFO - 2023-07-26 10:12:53 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:12:53 --> Controller Class Initialized
DEBUG - 2023-07-26 10:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:12:53 --> Database Driver Class Initialized
INFO - 2023-07-26 10:12:53 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:12:53 --> Model "Student_model" initialized
INFO - 2023-07-26 10:12:53 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:12:53 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:12:53 --> Final output sent to browser
DEBUG - 2023-07-26 10:12:53 --> Total execution time: 0.0259
INFO - 2023-07-26 10:12:58 --> Config Class Initialized
INFO - 2023-07-26 10:12:58 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:12:58 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:12:58 --> Utf8 Class Initialized
INFO - 2023-07-26 10:12:58 --> URI Class Initialized
INFO - 2023-07-26 10:12:58 --> Router Class Initialized
INFO - 2023-07-26 10:12:58 --> Output Class Initialized
INFO - 2023-07-26 10:12:58 --> Security Class Initialized
DEBUG - 2023-07-26 10:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:12:58 --> Input Class Initialized
INFO - 2023-07-26 10:12:58 --> Language Class Initialized
ERROR - 2023-07-26 10:12:58 --> 404 Page Not Found: Teacher_dashboard/import_csv
INFO - 2023-07-26 10:12:59 --> Config Class Initialized
INFO - 2023-07-26 10:12:59 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:12:59 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:12:59 --> Utf8 Class Initialized
INFO - 2023-07-26 10:12:59 --> URI Class Initialized
INFO - 2023-07-26 10:12:59 --> Router Class Initialized
INFO - 2023-07-26 10:12:59 --> Output Class Initialized
INFO - 2023-07-26 10:12:59 --> Security Class Initialized
DEBUG - 2023-07-26 10:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:12:59 --> Input Class Initialized
INFO - 2023-07-26 10:12:59 --> Language Class Initialized
INFO - 2023-07-26 10:12:59 --> Loader Class Initialized
INFO - 2023-07-26 10:12:59 --> Helper loaded: url_helper
INFO - 2023-07-26 10:12:59 --> Helper loaded: form_helper
INFO - 2023-07-26 10:12:59 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:12:59 --> Controller Class Initialized
DEBUG - 2023-07-26 10:12:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:12:59 --> Database Driver Class Initialized
INFO - 2023-07-26 10:12:59 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:12:59 --> Model "Student_model" initialized
INFO - 2023-07-26 10:12:59 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:12:59 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:12:59 --> Final output sent to browser
DEBUG - 2023-07-26 10:12:59 --> Total execution time: 0.0485
INFO - 2023-07-26 10:14:30 --> Config Class Initialized
INFO - 2023-07-26 10:14:30 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:14:30 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:14:30 --> Utf8 Class Initialized
INFO - 2023-07-26 10:14:30 --> URI Class Initialized
INFO - 2023-07-26 10:14:30 --> Router Class Initialized
INFO - 2023-07-26 10:14:30 --> Output Class Initialized
INFO - 2023-07-26 10:14:30 --> Security Class Initialized
DEBUG - 2023-07-26 10:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:14:30 --> Input Class Initialized
INFO - 2023-07-26 10:14:30 --> Language Class Initialized
INFO - 2023-07-26 10:14:30 --> Loader Class Initialized
INFO - 2023-07-26 10:14:30 --> Helper loaded: url_helper
INFO - 2023-07-26 10:14:30 --> Helper loaded: form_helper
INFO - 2023-07-26 10:14:30 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:14:30 --> Controller Class Initialized
DEBUG - 2023-07-26 10:14:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:14:30 --> Database Driver Class Initialized
INFO - 2023-07-26 10:14:30 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:14:30 --> Model "Student_model" initialized
INFO - 2023-07-26 10:14:30 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:14:30 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:14:30 --> Final output sent to browser
DEBUG - 2023-07-26 10:14:30 --> Total execution time: 0.0424
INFO - 2023-07-26 10:14:36 --> Config Class Initialized
INFO - 2023-07-26 10:14:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:14:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:14:36 --> Utf8 Class Initialized
INFO - 2023-07-26 10:14:36 --> URI Class Initialized
INFO - 2023-07-26 10:14:36 --> Router Class Initialized
INFO - 2023-07-26 10:14:36 --> Output Class Initialized
INFO - 2023-07-26 10:14:36 --> Security Class Initialized
DEBUG - 2023-07-26 10:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:14:36 --> Input Class Initialized
INFO - 2023-07-26 10:14:36 --> Language Class Initialized
ERROR - 2023-07-26 10:14:36 --> 404 Page Not Found: Teacher_dashboard/import_csv
INFO - 2023-07-26 10:16:39 --> Config Class Initialized
INFO - 2023-07-26 10:16:39 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:16:39 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:16:39 --> Utf8 Class Initialized
INFO - 2023-07-26 10:16:39 --> URI Class Initialized
INFO - 2023-07-26 10:16:39 --> Router Class Initialized
INFO - 2023-07-26 10:16:39 --> Output Class Initialized
INFO - 2023-07-26 10:16:39 --> Security Class Initialized
DEBUG - 2023-07-26 10:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:16:39 --> Input Class Initialized
INFO - 2023-07-26 10:16:39 --> Language Class Initialized
INFO - 2023-07-26 10:16:39 --> Loader Class Initialized
INFO - 2023-07-26 10:16:39 --> Helper loaded: url_helper
INFO - 2023-07-26 10:16:39 --> Helper loaded: form_helper
INFO - 2023-07-26 10:16:39 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:16:39 --> Controller Class Initialized
DEBUG - 2023-07-26 10:16:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:16:39 --> Database Driver Class Initialized
INFO - 2023-07-26 10:16:39 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:16:39 --> Model "Student_model" initialized
INFO - 2023-07-26 10:16:39 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:16:39 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:16:39 --> Final output sent to browser
DEBUG - 2023-07-26 10:16:39 --> Total execution time: 0.0467
INFO - 2023-07-26 10:16:41 --> Config Class Initialized
INFO - 2023-07-26 10:16:41 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:16:41 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:16:41 --> Utf8 Class Initialized
INFO - 2023-07-26 10:16:41 --> URI Class Initialized
INFO - 2023-07-26 10:16:41 --> Router Class Initialized
INFO - 2023-07-26 10:16:41 --> Output Class Initialized
INFO - 2023-07-26 10:16:41 --> Security Class Initialized
DEBUG - 2023-07-26 10:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:16:41 --> Input Class Initialized
INFO - 2023-07-26 10:16:41 --> Language Class Initialized
INFO - 2023-07-26 10:16:41 --> Loader Class Initialized
INFO - 2023-07-26 10:16:41 --> Helper loaded: url_helper
INFO - 2023-07-26 10:16:41 --> Helper loaded: form_helper
INFO - 2023-07-26 10:16:41 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:16:41 --> Controller Class Initialized
DEBUG - 2023-07-26 10:16:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:16:41 --> Database Driver Class Initialized
INFO - 2023-07-26 10:16:41 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:16:41 --> Model "Student_model" initialized
INFO - 2023-07-26 10:16:41 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:16:41 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:16:41 --> Final output sent to browser
DEBUG - 2023-07-26 10:16:41 --> Total execution time: 0.0422
INFO - 2023-07-26 10:16:48 --> Config Class Initialized
INFO - 2023-07-26 10:16:48 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:16:48 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:16:48 --> Utf8 Class Initialized
INFO - 2023-07-26 10:16:48 --> URI Class Initialized
INFO - 2023-07-26 10:16:48 --> Router Class Initialized
INFO - 2023-07-26 10:16:48 --> Output Class Initialized
INFO - 2023-07-26 10:16:48 --> Security Class Initialized
DEBUG - 2023-07-26 10:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:16:48 --> Input Class Initialized
INFO - 2023-07-26 10:16:48 --> Language Class Initialized
INFO - 2023-07-26 10:16:48 --> Loader Class Initialized
INFO - 2023-07-26 10:16:48 --> Helper loaded: url_helper
INFO - 2023-07-26 10:16:48 --> Helper loaded: form_helper
INFO - 2023-07-26 10:16:48 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:16:48 --> Controller Class Initialized
DEBUG - 2023-07-26 10:16:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:16:48 --> Database Driver Class Initialized
INFO - 2023-07-26 10:16:48 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:16:48 --> Model "Student_model" initialized
INFO - 2023-07-26 10:16:48 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:16:48 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:16:48 --> Final output sent to browser
DEBUG - 2023-07-26 10:16:48 --> Total execution time: 0.0342
INFO - 2023-07-26 10:17:20 --> Config Class Initialized
INFO - 2023-07-26 10:17:20 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:17:20 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:17:20 --> Utf8 Class Initialized
INFO - 2023-07-26 10:17:20 --> URI Class Initialized
INFO - 2023-07-26 10:17:20 --> Router Class Initialized
INFO - 2023-07-26 10:17:20 --> Output Class Initialized
INFO - 2023-07-26 10:17:20 --> Security Class Initialized
DEBUG - 2023-07-26 10:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:17:20 --> Input Class Initialized
INFO - 2023-07-26 10:17:20 --> Language Class Initialized
INFO - 2023-07-26 10:17:20 --> Loader Class Initialized
INFO - 2023-07-26 10:17:20 --> Helper loaded: url_helper
INFO - 2023-07-26 10:17:20 --> Helper loaded: form_helper
INFO - 2023-07-26 10:17:20 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:17:20 --> Controller Class Initialized
DEBUG - 2023-07-26 10:17:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:17:20 --> Database Driver Class Initialized
INFO - 2023-07-26 10:17:20 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:17:20 --> Model "Student_model" initialized
INFO - 2023-07-26 10:17:20 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:17:20 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:17:20 --> Final output sent to browser
DEBUG - 2023-07-26 10:17:20 --> Total execution time: 0.0249
INFO - 2023-07-26 10:17:23 --> Config Class Initialized
INFO - 2023-07-26 10:17:23 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:17:23 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:17:23 --> Utf8 Class Initialized
INFO - 2023-07-26 10:17:23 --> URI Class Initialized
INFO - 2023-07-26 10:17:23 --> Router Class Initialized
INFO - 2023-07-26 10:17:23 --> Output Class Initialized
INFO - 2023-07-26 10:17:23 --> Security Class Initialized
DEBUG - 2023-07-26 10:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:17:23 --> Input Class Initialized
INFO - 2023-07-26 10:17:23 --> Language Class Initialized
INFO - 2023-07-26 10:17:23 --> Loader Class Initialized
INFO - 2023-07-26 10:17:23 --> Helper loaded: url_helper
INFO - 2023-07-26 10:17:23 --> Helper loaded: form_helper
INFO - 2023-07-26 10:17:23 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:17:23 --> Controller Class Initialized
DEBUG - 2023-07-26 10:17:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:17:23 --> Database Driver Class Initialized
INFO - 2023-07-26 10:17:23 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:17:23 --> Model "Student_model" initialized
INFO - 2023-07-26 10:17:23 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:17:23 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:17:23 --> Final output sent to browser
DEBUG - 2023-07-26 10:17:23 --> Total execution time: 0.0237
INFO - 2023-07-26 10:17:39 --> Config Class Initialized
INFO - 2023-07-26 10:17:39 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:17:39 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:17:39 --> Utf8 Class Initialized
INFO - 2023-07-26 10:17:39 --> URI Class Initialized
INFO - 2023-07-26 10:17:39 --> Router Class Initialized
INFO - 2023-07-26 10:17:39 --> Output Class Initialized
INFO - 2023-07-26 10:17:39 --> Security Class Initialized
DEBUG - 2023-07-26 10:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:17:39 --> Input Class Initialized
INFO - 2023-07-26 10:17:39 --> Language Class Initialized
INFO - 2023-07-26 10:17:39 --> Loader Class Initialized
INFO - 2023-07-26 10:17:39 --> Helper loaded: url_helper
INFO - 2023-07-26 10:17:39 --> Helper loaded: form_helper
INFO - 2023-07-26 10:17:39 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:17:39 --> Controller Class Initialized
DEBUG - 2023-07-26 10:17:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:17:39 --> Database Driver Class Initialized
INFO - 2023-07-26 10:17:39 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:17:39 --> Model "Student_model" initialized
INFO - 2023-07-26 10:17:39 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:17:39 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:17:39 --> Final output sent to browser
DEBUG - 2023-07-26 10:17:39 --> Total execution time: 0.0260
INFO - 2023-07-26 10:19:59 --> Config Class Initialized
INFO - 2023-07-26 10:19:59 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:19:59 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:19:59 --> Utf8 Class Initialized
INFO - 2023-07-26 10:19:59 --> URI Class Initialized
INFO - 2023-07-26 10:19:59 --> Router Class Initialized
INFO - 2023-07-26 10:19:59 --> Output Class Initialized
INFO - 2023-07-26 10:19:59 --> Security Class Initialized
DEBUG - 2023-07-26 10:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:19:59 --> Input Class Initialized
INFO - 2023-07-26 10:19:59 --> Language Class Initialized
INFO - 2023-07-26 10:19:59 --> Loader Class Initialized
INFO - 2023-07-26 10:19:59 --> Helper loaded: url_helper
INFO - 2023-07-26 10:19:59 --> Helper loaded: form_helper
INFO - 2023-07-26 10:19:59 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:19:59 --> Controller Class Initialized
DEBUG - 2023-07-26 10:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:19:59 --> Database Driver Class Initialized
INFO - 2023-07-26 10:19:59 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:19:59 --> Model "Student_model" initialized
INFO - 2023-07-26 10:19:59 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:19:59 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:19:59 --> Final output sent to browser
DEBUG - 2023-07-26 10:19:59 --> Total execution time: 0.0404
INFO - 2023-07-26 10:20:01 --> Config Class Initialized
INFO - 2023-07-26 10:20:01 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:20:01 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:20:01 --> Utf8 Class Initialized
INFO - 2023-07-26 10:20:01 --> URI Class Initialized
INFO - 2023-07-26 10:20:01 --> Router Class Initialized
INFO - 2023-07-26 10:20:01 --> Output Class Initialized
INFO - 2023-07-26 10:20:01 --> Security Class Initialized
DEBUG - 2023-07-26 10:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:20:01 --> Input Class Initialized
INFO - 2023-07-26 10:20:01 --> Language Class Initialized
INFO - 2023-07-26 10:20:01 --> Loader Class Initialized
INFO - 2023-07-26 10:20:01 --> Helper loaded: url_helper
INFO - 2023-07-26 10:20:01 --> Helper loaded: form_helper
INFO - 2023-07-26 10:20:01 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:20:01 --> Controller Class Initialized
DEBUG - 2023-07-26 10:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:20:01 --> Database Driver Class Initialized
INFO - 2023-07-26 10:20:01 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:20:01 --> Model "Student_model" initialized
INFO - 2023-07-26 10:20:01 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:20:01 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:20:01 --> Final output sent to browser
DEBUG - 2023-07-26 10:20:01 --> Total execution time: 0.0408
INFO - 2023-07-26 10:20:27 --> Config Class Initialized
INFO - 2023-07-26 10:20:27 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:20:27 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:20:27 --> Utf8 Class Initialized
INFO - 2023-07-26 10:20:27 --> URI Class Initialized
INFO - 2023-07-26 10:20:27 --> Router Class Initialized
INFO - 2023-07-26 10:20:27 --> Output Class Initialized
INFO - 2023-07-26 10:20:27 --> Security Class Initialized
DEBUG - 2023-07-26 10:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:20:27 --> Input Class Initialized
INFO - 2023-07-26 10:20:27 --> Language Class Initialized
INFO - 2023-07-26 10:20:27 --> Loader Class Initialized
INFO - 2023-07-26 10:20:27 --> Helper loaded: url_helper
INFO - 2023-07-26 10:20:27 --> Helper loaded: form_helper
INFO - 2023-07-26 10:20:27 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:20:27 --> Controller Class Initialized
DEBUG - 2023-07-26 10:20:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:20:27 --> Database Driver Class Initialized
INFO - 2023-07-26 10:20:27 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:20:27 --> Model "Student_model" initialized
INFO - 2023-07-26 10:20:27 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:20:27 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:20:27 --> Final output sent to browser
DEBUG - 2023-07-26 10:20:27 --> Total execution time: 0.0383
INFO - 2023-07-26 10:20:30 --> Config Class Initialized
INFO - 2023-07-26 10:20:30 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:20:30 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:20:30 --> Utf8 Class Initialized
INFO - 2023-07-26 10:20:30 --> URI Class Initialized
INFO - 2023-07-26 10:20:30 --> Router Class Initialized
INFO - 2023-07-26 10:20:30 --> Output Class Initialized
INFO - 2023-07-26 10:20:30 --> Security Class Initialized
DEBUG - 2023-07-26 10:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:20:30 --> Input Class Initialized
INFO - 2023-07-26 10:20:30 --> Language Class Initialized
INFO - 2023-07-26 10:20:30 --> Loader Class Initialized
INFO - 2023-07-26 10:20:30 --> Helper loaded: url_helper
INFO - 2023-07-26 10:20:30 --> Helper loaded: form_helper
INFO - 2023-07-26 10:20:30 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:20:30 --> Controller Class Initialized
DEBUG - 2023-07-26 10:20:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:20:30 --> Database Driver Class Initialized
INFO - 2023-07-26 10:20:30 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:20:30 --> Model "Student_model" initialized
INFO - 2023-07-26 10:20:30 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:20:30 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:20:30 --> Final output sent to browser
DEBUG - 2023-07-26 10:20:30 --> Total execution time: 0.0441
INFO - 2023-07-26 10:21:01 --> Config Class Initialized
INFO - 2023-07-26 10:21:01 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:21:01 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:21:01 --> Utf8 Class Initialized
INFO - 2023-07-26 10:21:01 --> URI Class Initialized
INFO - 2023-07-26 10:21:01 --> Router Class Initialized
INFO - 2023-07-26 10:21:01 --> Output Class Initialized
INFO - 2023-07-26 10:21:01 --> Security Class Initialized
DEBUG - 2023-07-26 10:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:21:01 --> Input Class Initialized
INFO - 2023-07-26 10:21:01 --> Language Class Initialized
INFO - 2023-07-26 10:21:01 --> Loader Class Initialized
INFO - 2023-07-26 10:21:01 --> Helper loaded: url_helper
INFO - 2023-07-26 10:21:01 --> Helper loaded: form_helper
INFO - 2023-07-26 10:21:01 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:21:01 --> Controller Class Initialized
DEBUG - 2023-07-26 10:21:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:21:01 --> Database Driver Class Initialized
INFO - 2023-07-26 10:21:01 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:21:01 --> Model "Student_model" initialized
INFO - 2023-07-26 10:21:01 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:21:01 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:21:01 --> Final output sent to browser
DEBUG - 2023-07-26 10:21:01 --> Total execution time: 0.0262
INFO - 2023-07-26 10:21:10 --> Config Class Initialized
INFO - 2023-07-26 10:21:10 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:21:10 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:21:10 --> Utf8 Class Initialized
INFO - 2023-07-26 10:21:10 --> URI Class Initialized
INFO - 2023-07-26 10:21:10 --> Router Class Initialized
INFO - 2023-07-26 10:21:10 --> Output Class Initialized
INFO - 2023-07-26 10:21:10 --> Security Class Initialized
DEBUG - 2023-07-26 10:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:21:10 --> Input Class Initialized
INFO - 2023-07-26 10:21:10 --> Language Class Initialized
INFO - 2023-07-26 10:21:10 --> Loader Class Initialized
INFO - 2023-07-26 10:21:10 --> Helper loaded: url_helper
INFO - 2023-07-26 10:21:10 --> Helper loaded: form_helper
INFO - 2023-07-26 10:21:10 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:21:10 --> Controller Class Initialized
DEBUG - 2023-07-26 10:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:21:10 --> Database Driver Class Initialized
INFO - 2023-07-26 10:21:10 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:21:10 --> Model "Student_model" initialized
INFO - 2023-07-26 10:21:10 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:21:10 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:21:10 --> Final output sent to browser
DEBUG - 2023-07-26 10:21:10 --> Total execution time: 0.0360
INFO - 2023-07-26 10:21:35 --> Config Class Initialized
INFO - 2023-07-26 10:21:35 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:21:35 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:21:35 --> Utf8 Class Initialized
INFO - 2023-07-26 10:21:35 --> URI Class Initialized
INFO - 2023-07-26 10:21:35 --> Router Class Initialized
INFO - 2023-07-26 10:21:35 --> Output Class Initialized
INFO - 2023-07-26 10:21:35 --> Security Class Initialized
DEBUG - 2023-07-26 10:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:21:35 --> Input Class Initialized
INFO - 2023-07-26 10:21:35 --> Language Class Initialized
INFO - 2023-07-26 10:21:35 --> Loader Class Initialized
INFO - 2023-07-26 10:21:35 --> Helper loaded: url_helper
INFO - 2023-07-26 10:21:35 --> Helper loaded: form_helper
INFO - 2023-07-26 10:21:35 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:21:35 --> Controller Class Initialized
DEBUG - 2023-07-26 10:21:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:21:35 --> Database Driver Class Initialized
INFO - 2023-07-26 10:21:35 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:21:35 --> Model "Student_model" initialized
INFO - 2023-07-26 10:21:35 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:21:35 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:21:35 --> Final output sent to browser
DEBUG - 2023-07-26 10:21:35 --> Total execution time: 0.0440
INFO - 2023-07-26 10:53:16 --> Config Class Initialized
INFO - 2023-07-26 10:53:16 --> Hooks Class Initialized
DEBUG - 2023-07-26 10:53:16 --> UTF-8 Support Enabled
INFO - 2023-07-26 10:53:16 --> Utf8 Class Initialized
INFO - 2023-07-26 10:53:16 --> URI Class Initialized
INFO - 2023-07-26 10:53:16 --> Router Class Initialized
INFO - 2023-07-26 10:53:16 --> Output Class Initialized
INFO - 2023-07-26 10:53:16 --> Security Class Initialized
DEBUG - 2023-07-26 10:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 10:53:16 --> Input Class Initialized
INFO - 2023-07-26 10:53:16 --> Language Class Initialized
INFO - 2023-07-26 10:53:16 --> Loader Class Initialized
INFO - 2023-07-26 10:53:16 --> Helper loaded: url_helper
INFO - 2023-07-26 10:53:16 --> Helper loaded: form_helper
INFO - 2023-07-26 10:53:16 --> Form Validation Class Initialized
DEBUG - 2023-07-26 10:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 10:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 10:53:16 --> Controller Class Initialized
DEBUG - 2023-07-26 10:53:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 10:53:16 --> Database Driver Class Initialized
INFO - 2023-07-26 10:53:16 --> Model "Admin_model" initialized
INFO - 2023-07-26 10:53:16 --> Model "Student_model" initialized
INFO - 2023-07-26 10:53:16 --> Model "Teacher_model" initialized
INFO - 2023-07-26 10:53:16 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 10:53:16 --> Final output sent to browser
DEBUG - 2023-07-26 10:53:16 --> Total execution time: 0.0249
INFO - 2023-07-26 11:20:48 --> Config Class Initialized
INFO - 2023-07-26 11:20:48 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:20:48 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:20:48 --> Utf8 Class Initialized
INFO - 2023-07-26 11:20:48 --> URI Class Initialized
INFO - 2023-07-26 11:20:48 --> Router Class Initialized
INFO - 2023-07-26 11:20:48 --> Output Class Initialized
INFO - 2023-07-26 11:20:48 --> Security Class Initialized
DEBUG - 2023-07-26 11:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:20:48 --> Input Class Initialized
INFO - 2023-07-26 11:20:48 --> Language Class Initialized
INFO - 2023-07-26 11:20:48 --> Loader Class Initialized
INFO - 2023-07-26 11:20:48 --> Helper loaded: url_helper
INFO - 2023-07-26 11:20:48 --> Helper loaded: form_helper
INFO - 2023-07-26 11:20:48 --> Form Validation Class Initialized
DEBUG - 2023-07-26 11:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 11:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 11:20:48 --> Controller Class Initialized
DEBUG - 2023-07-26 11:20:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 11:20:48 --> Database Driver Class Initialized
INFO - 2023-07-26 11:20:48 --> Model "Admin_model" initialized
INFO - 2023-07-26 11:20:48 --> Model "Student_model" initialized
INFO - 2023-07-26 11:20:48 --> Model "Teacher_model" initialized
INFO - 2023-07-26 11:20:48 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 11:20:48 --> Final output sent to browser
DEBUG - 2023-07-26 11:20:48 --> Total execution time: 0.5245
INFO - 2023-07-26 11:21:37 --> Config Class Initialized
INFO - 2023-07-26 11:21:37 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:21:37 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:21:37 --> Utf8 Class Initialized
INFO - 2023-07-26 11:21:37 --> URI Class Initialized
INFO - 2023-07-26 11:21:37 --> Router Class Initialized
INFO - 2023-07-26 11:21:37 --> Output Class Initialized
INFO - 2023-07-26 11:21:37 --> Security Class Initialized
DEBUG - 2023-07-26 11:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:21:37 --> Input Class Initialized
INFO - 2023-07-26 11:21:37 --> Language Class Initialized
INFO - 2023-07-26 11:21:37 --> Loader Class Initialized
INFO - 2023-07-26 11:21:37 --> Helper loaded: url_helper
INFO - 2023-07-26 11:21:37 --> Helper loaded: form_helper
INFO - 2023-07-26 11:21:37 --> Form Validation Class Initialized
DEBUG - 2023-07-26 11:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 11:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 11:21:37 --> Controller Class Initialized
DEBUG - 2023-07-26 11:21:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 11:21:37 --> Database Driver Class Initialized
INFO - 2023-07-26 11:21:37 --> Model "Admin_model" initialized
INFO - 2023-07-26 11:21:37 --> Model "Student_model" initialized
INFO - 2023-07-26 11:21:37 --> Model "Teacher_model" initialized
INFO - 2023-07-26 11:21:37 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 11:21:37 --> Final output sent to browser
DEBUG - 2023-07-26 11:21:37 --> Total execution time: 0.0439
INFO - 2023-07-26 11:31:03 --> Config Class Initialized
INFO - 2023-07-26 11:31:03 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:31:03 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:31:03 --> Utf8 Class Initialized
INFO - 2023-07-26 11:31:03 --> URI Class Initialized
INFO - 2023-07-26 11:31:03 --> Router Class Initialized
INFO - 2023-07-26 11:31:03 --> Output Class Initialized
INFO - 2023-07-26 11:31:03 --> Security Class Initialized
DEBUG - 2023-07-26 11:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:31:03 --> Input Class Initialized
INFO - 2023-07-26 11:31:03 --> Language Class Initialized
INFO - 2023-07-26 11:31:03 --> Loader Class Initialized
INFO - 2023-07-26 11:31:03 --> Helper loaded: url_helper
INFO - 2023-07-26 11:31:03 --> Helper loaded: form_helper
INFO - 2023-07-26 11:31:03 --> Form Validation Class Initialized
DEBUG - 2023-07-26 11:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 11:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 11:31:03 --> Controller Class Initialized
DEBUG - 2023-07-26 11:31:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 11:31:03 --> Database Driver Class Initialized
INFO - 2023-07-26 11:31:03 --> Model "Admin_model" initialized
INFO - 2023-07-26 11:31:03 --> Model "Student_model" initialized
INFO - 2023-07-26 11:31:03 --> Model "Teacher_model" initialized
INFO - 2023-07-26 11:31:03 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 11:31:03 --> Final output sent to browser
DEBUG - 2023-07-26 11:31:03 --> Total execution time: 0.0361
INFO - 2023-07-26 11:31:08 --> Config Class Initialized
INFO - 2023-07-26 11:31:08 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:31:08 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:31:08 --> Utf8 Class Initialized
INFO - 2023-07-26 11:31:08 --> URI Class Initialized
INFO - 2023-07-26 11:31:08 --> Router Class Initialized
INFO - 2023-07-26 11:31:08 --> Output Class Initialized
INFO - 2023-07-26 11:31:08 --> Security Class Initialized
DEBUG - 2023-07-26 11:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:31:08 --> Input Class Initialized
INFO - 2023-07-26 11:31:08 --> Language Class Initialized
INFO - 2023-07-26 11:31:08 --> Loader Class Initialized
INFO - 2023-07-26 11:31:08 --> Helper loaded: url_helper
INFO - 2023-07-26 11:31:08 --> Helper loaded: form_helper
INFO - 2023-07-26 11:31:08 --> Form Validation Class Initialized
DEBUG - 2023-07-26 11:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 11:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 11:31:08 --> Controller Class Initialized
DEBUG - 2023-07-26 11:31:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 11:31:08 --> Database Driver Class Initialized
INFO - 2023-07-26 11:31:09 --> Model "Admin_model" initialized
INFO - 2023-07-26 11:31:09 --> Model "Student_model" initialized
INFO - 2023-07-26 11:31:09 --> Model "Teacher_model" initialized
INFO - 2023-07-26 11:31:09 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 11:31:09 --> Final output sent to browser
DEBUG - 2023-07-26 11:31:09 --> Total execution time: 0.0517
INFO - 2023-07-26 11:31:25 --> Config Class Initialized
INFO - 2023-07-26 11:31:25 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:31:25 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:31:25 --> Utf8 Class Initialized
INFO - 2023-07-26 11:31:25 --> URI Class Initialized
INFO - 2023-07-26 11:31:25 --> Router Class Initialized
INFO - 2023-07-26 11:31:25 --> Output Class Initialized
INFO - 2023-07-26 11:31:25 --> Security Class Initialized
DEBUG - 2023-07-26 11:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:31:25 --> Input Class Initialized
INFO - 2023-07-26 11:31:25 --> Language Class Initialized
INFO - 2023-07-26 11:31:25 --> Loader Class Initialized
INFO - 2023-07-26 11:31:25 --> Helper loaded: url_helper
INFO - 2023-07-26 11:31:25 --> Helper loaded: form_helper
INFO - 2023-07-26 11:31:25 --> Form Validation Class Initialized
DEBUG - 2023-07-26 11:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 11:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 11:31:25 --> Controller Class Initialized
DEBUG - 2023-07-26 11:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 11:31:25 --> Database Driver Class Initialized
INFO - 2023-07-26 11:31:25 --> Model "Admin_model" initialized
INFO - 2023-07-26 11:31:25 --> Model "Student_model" initialized
INFO - 2023-07-26 11:31:25 --> Model "Teacher_model" initialized
INFO - 2023-07-26 11:31:25 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 11:31:25 --> Final output sent to browser
DEBUG - 2023-07-26 11:31:25 --> Total execution time: 0.0510
INFO - 2023-07-26 11:34:08 --> Config Class Initialized
INFO - 2023-07-26 11:34:08 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:34:08 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:34:08 --> Utf8 Class Initialized
INFO - 2023-07-26 11:34:08 --> URI Class Initialized
INFO - 2023-07-26 11:34:08 --> Router Class Initialized
INFO - 2023-07-26 11:34:08 --> Output Class Initialized
INFO - 2023-07-26 11:34:08 --> Security Class Initialized
DEBUG - 2023-07-26 11:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:34:08 --> Input Class Initialized
INFO - 2023-07-26 11:34:08 --> Language Class Initialized
INFO - 2023-07-26 11:34:08 --> Loader Class Initialized
INFO - 2023-07-26 11:34:08 --> Helper loaded: url_helper
INFO - 2023-07-26 11:34:08 --> Helper loaded: form_helper
INFO - 2023-07-26 11:34:08 --> Form Validation Class Initialized
DEBUG - 2023-07-26 11:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 11:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 11:34:08 --> Controller Class Initialized
DEBUG - 2023-07-26 11:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 11:34:08 --> Database Driver Class Initialized
INFO - 2023-07-26 11:34:08 --> Model "Admin_model" initialized
INFO - 2023-07-26 11:34:08 --> Model "Student_model" initialized
INFO - 2023-07-26 11:34:08 --> Model "Teacher_model" initialized
INFO - 2023-07-26 11:34:08 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 11:34:08 --> Final output sent to browser
DEBUG - 2023-07-26 11:34:08 --> Total execution time: 0.0480
INFO - 2023-07-26 11:39:11 --> Config Class Initialized
INFO - 2023-07-26 11:39:11 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:39:11 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:39:11 --> Utf8 Class Initialized
INFO - 2023-07-26 11:39:11 --> URI Class Initialized
INFO - 2023-07-26 11:39:11 --> Router Class Initialized
INFO - 2023-07-26 11:39:11 --> Output Class Initialized
INFO - 2023-07-26 11:39:11 --> Security Class Initialized
DEBUG - 2023-07-26 11:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:39:11 --> Input Class Initialized
INFO - 2023-07-26 11:39:11 --> Language Class Initialized
INFO - 2023-07-26 11:39:11 --> Loader Class Initialized
INFO - 2023-07-26 11:39:11 --> Helper loaded: url_helper
INFO - 2023-07-26 11:39:11 --> Helper loaded: form_helper
INFO - 2023-07-26 11:39:11 --> Form Validation Class Initialized
DEBUG - 2023-07-26 11:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 11:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 11:39:11 --> Controller Class Initialized
DEBUG - 2023-07-26 11:39:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 11:39:11 --> Database Driver Class Initialized
INFO - 2023-07-26 11:39:11 --> Model "Admin_model" initialized
INFO - 2023-07-26 11:39:11 --> Model "Student_model" initialized
INFO - 2023-07-26 11:39:11 --> Model "Teacher_model" initialized
INFO - 2023-07-26 11:39:11 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 11:39:11 --> Final output sent to browser
DEBUG - 2023-07-26 11:39:11 --> Total execution time: 0.0385
INFO - 2023-07-26 11:39:20 --> Config Class Initialized
INFO - 2023-07-26 11:39:20 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:39:20 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:39:20 --> Utf8 Class Initialized
INFO - 2023-07-26 11:39:20 --> URI Class Initialized
INFO - 2023-07-26 11:39:20 --> Router Class Initialized
INFO - 2023-07-26 11:39:20 --> Output Class Initialized
INFO - 2023-07-26 11:39:20 --> Security Class Initialized
DEBUG - 2023-07-26 11:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:39:20 --> Input Class Initialized
INFO - 2023-07-26 11:39:20 --> Language Class Initialized
INFO - 2023-07-26 11:39:20 --> Loader Class Initialized
INFO - 2023-07-26 11:39:20 --> Helper loaded: url_helper
INFO - 2023-07-26 11:39:20 --> Helper loaded: form_helper
INFO - 2023-07-26 11:39:20 --> Form Validation Class Initialized
DEBUG - 2023-07-26 11:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 11:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 11:39:20 --> Controller Class Initialized
DEBUG - 2023-07-26 11:39:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 11:39:20 --> Database Driver Class Initialized
INFO - 2023-07-26 11:39:20 --> Model "Admin_model" initialized
INFO - 2023-07-26 11:39:20 --> Model "Student_model" initialized
INFO - 2023-07-26 11:39:20 --> Model "Teacher_model" initialized
INFO - 2023-07-26 11:39:20 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 11:39:20 --> Final output sent to browser
DEBUG - 2023-07-26 11:39:20 --> Total execution time: 0.0489
INFO - 2023-07-26 11:50:55 --> Config Class Initialized
INFO - 2023-07-26 11:50:55 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:50:55 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:50:55 --> Utf8 Class Initialized
INFO - 2023-07-26 11:50:55 --> URI Class Initialized
INFO - 2023-07-26 11:50:55 --> Router Class Initialized
INFO - 2023-07-26 11:50:55 --> Output Class Initialized
INFO - 2023-07-26 11:50:55 --> Security Class Initialized
DEBUG - 2023-07-26 11:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:50:55 --> Input Class Initialized
INFO - 2023-07-26 11:50:55 --> Language Class Initialized
ERROR - 2023-07-26 11:50:55 --> Severity: Parsing Error --> syntax error, unexpected 'private' (T_PRIVATE) C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 153
INFO - 2023-07-26 11:50:55 --> Config Class Initialized
INFO - 2023-07-26 11:50:55 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:50:55 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:50:55 --> Utf8 Class Initialized
INFO - 2023-07-26 11:50:55 --> URI Class Initialized
INFO - 2023-07-26 11:50:55 --> Router Class Initialized
INFO - 2023-07-26 11:50:55 --> Output Class Initialized
INFO - 2023-07-26 11:50:55 --> Security Class Initialized
DEBUG - 2023-07-26 11:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:50:55 --> Input Class Initialized
INFO - 2023-07-26 11:50:55 --> Language Class Initialized
ERROR - 2023-07-26 11:50:55 --> Severity: Parsing Error --> syntax error, unexpected 'private' (T_PRIVATE) C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 153
INFO - 2023-07-26 11:50:56 --> Config Class Initialized
INFO - 2023-07-26 11:50:56 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:50:56 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:50:56 --> Utf8 Class Initialized
INFO - 2023-07-26 11:50:56 --> URI Class Initialized
INFO - 2023-07-26 11:50:56 --> Router Class Initialized
INFO - 2023-07-26 11:50:56 --> Output Class Initialized
INFO - 2023-07-26 11:50:56 --> Security Class Initialized
DEBUG - 2023-07-26 11:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:50:56 --> Input Class Initialized
INFO - 2023-07-26 11:50:56 --> Language Class Initialized
ERROR - 2023-07-26 11:50:56 --> Severity: Parsing Error --> syntax error, unexpected 'private' (T_PRIVATE) C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 153
INFO - 2023-07-26 11:50:57 --> Config Class Initialized
INFO - 2023-07-26 11:50:57 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:50:57 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:50:57 --> Utf8 Class Initialized
INFO - 2023-07-26 11:50:57 --> URI Class Initialized
INFO - 2023-07-26 11:50:57 --> Router Class Initialized
INFO - 2023-07-26 11:50:57 --> Output Class Initialized
INFO - 2023-07-26 11:50:57 --> Security Class Initialized
DEBUG - 2023-07-26 11:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:50:57 --> Input Class Initialized
INFO - 2023-07-26 11:50:57 --> Language Class Initialized
ERROR - 2023-07-26 11:50:57 --> Severity: Parsing Error --> syntax error, unexpected 'private' (T_PRIVATE) C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 153
INFO - 2023-07-26 11:50:58 --> Config Class Initialized
INFO - 2023-07-26 11:50:58 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:50:58 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:50:58 --> Utf8 Class Initialized
INFO - 2023-07-26 11:50:58 --> URI Class Initialized
INFO - 2023-07-26 11:50:58 --> Router Class Initialized
INFO - 2023-07-26 11:50:58 --> Output Class Initialized
INFO - 2023-07-26 11:50:58 --> Security Class Initialized
DEBUG - 2023-07-26 11:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:50:58 --> Input Class Initialized
INFO - 2023-07-26 11:50:58 --> Language Class Initialized
ERROR - 2023-07-26 11:50:58 --> Severity: Parsing Error --> syntax error, unexpected 'private' (T_PRIVATE) C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 153
INFO - 2023-07-26 11:53:46 --> Config Class Initialized
INFO - 2023-07-26 11:53:46 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:53:46 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:53:46 --> Utf8 Class Initialized
INFO - 2023-07-26 11:53:46 --> URI Class Initialized
INFO - 2023-07-26 11:53:46 --> Router Class Initialized
INFO - 2023-07-26 11:53:46 --> Output Class Initialized
INFO - 2023-07-26 11:53:46 --> Security Class Initialized
DEBUG - 2023-07-26 11:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:53:46 --> Input Class Initialized
INFO - 2023-07-26 11:53:46 --> Language Class Initialized
INFO - 2023-07-26 11:53:46 --> Loader Class Initialized
INFO - 2023-07-26 11:53:46 --> Helper loaded: url_helper
INFO - 2023-07-26 11:53:46 --> Helper loaded: form_helper
INFO - 2023-07-26 11:53:46 --> Form Validation Class Initialized
DEBUG - 2023-07-26 11:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 11:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 11:53:46 --> Controller Class Initialized
DEBUG - 2023-07-26 11:53:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 11:53:46 --> Database Driver Class Initialized
INFO - 2023-07-26 11:53:47 --> Model "Admin_model" initialized
INFO - 2023-07-26 11:53:47 --> Model "Student_model" initialized
INFO - 2023-07-26 11:53:47 --> Model "Teacher_model" initialized
INFO - 2023-07-26 11:53:47 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 11:53:47 --> Final output sent to browser
DEBUG - 2023-07-26 11:53:47 --> Total execution time: 0.0389
INFO - 2023-07-26 11:53:48 --> Config Class Initialized
INFO - 2023-07-26 11:53:48 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:53:48 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:53:48 --> Utf8 Class Initialized
INFO - 2023-07-26 11:53:48 --> URI Class Initialized
INFO - 2023-07-26 11:53:48 --> Router Class Initialized
INFO - 2023-07-26 11:53:48 --> Output Class Initialized
INFO - 2023-07-26 11:53:48 --> Security Class Initialized
DEBUG - 2023-07-26 11:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:53:48 --> Input Class Initialized
INFO - 2023-07-26 11:53:48 --> Language Class Initialized
INFO - 2023-07-26 11:53:48 --> Loader Class Initialized
INFO - 2023-07-26 11:53:48 --> Helper loaded: url_helper
INFO - 2023-07-26 11:53:48 --> Helper loaded: form_helper
INFO - 2023-07-26 11:53:48 --> Form Validation Class Initialized
DEBUG - 2023-07-26 11:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 11:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 11:53:48 --> Controller Class Initialized
DEBUG - 2023-07-26 11:53:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 11:53:48 --> Database Driver Class Initialized
INFO - 2023-07-26 11:53:48 --> Model "Admin_model" initialized
INFO - 2023-07-26 11:53:48 --> Model "Student_model" initialized
INFO - 2023-07-26 11:53:48 --> Model "Teacher_model" initialized
INFO - 2023-07-26 11:53:48 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 11:53:48 --> Final output sent to browser
DEBUG - 2023-07-26 11:53:48 --> Total execution time: 0.0388
INFO - 2023-07-26 11:54:13 --> Config Class Initialized
INFO - 2023-07-26 11:54:13 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:54:13 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:54:13 --> Utf8 Class Initialized
INFO - 2023-07-26 11:54:13 --> URI Class Initialized
INFO - 2023-07-26 11:54:13 --> Router Class Initialized
INFO - 2023-07-26 11:54:13 --> Output Class Initialized
INFO - 2023-07-26 11:54:13 --> Security Class Initialized
DEBUG - 2023-07-26 11:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:54:13 --> Input Class Initialized
INFO - 2023-07-26 11:54:13 --> Language Class Initialized
INFO - 2023-07-26 11:54:13 --> Loader Class Initialized
INFO - 2023-07-26 11:54:13 --> Helper loaded: url_helper
INFO - 2023-07-26 11:54:13 --> Helper loaded: form_helper
INFO - 2023-07-26 11:54:13 --> Form Validation Class Initialized
DEBUG - 2023-07-26 11:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 11:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 11:54:13 --> Controller Class Initialized
DEBUG - 2023-07-26 11:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 11:54:13 --> Database Driver Class Initialized
INFO - 2023-07-26 11:54:13 --> Model "Admin_model" initialized
INFO - 2023-07-26 11:54:13 --> Model "Student_model" initialized
INFO - 2023-07-26 11:54:13 --> Model "Teacher_model" initialized
INFO - 2023-07-26 11:54:13 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 11:54:13 --> Final output sent to browser
DEBUG - 2023-07-26 11:54:13 --> Total execution time: 0.0594
INFO - 2023-07-26 11:54:15 --> Config Class Initialized
INFO - 2023-07-26 11:54:15 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:54:15 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:54:15 --> Utf8 Class Initialized
INFO - 2023-07-26 11:54:15 --> URI Class Initialized
INFO - 2023-07-26 11:54:15 --> Router Class Initialized
INFO - 2023-07-26 11:54:15 --> Output Class Initialized
INFO - 2023-07-26 11:54:15 --> Security Class Initialized
DEBUG - 2023-07-26 11:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:54:15 --> Input Class Initialized
INFO - 2023-07-26 11:54:15 --> Language Class Initialized
INFO - 2023-07-26 11:54:15 --> Loader Class Initialized
INFO - 2023-07-26 11:54:15 --> Helper loaded: url_helper
INFO - 2023-07-26 11:54:15 --> Helper loaded: form_helper
INFO - 2023-07-26 11:54:15 --> Form Validation Class Initialized
DEBUG - 2023-07-26 11:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 11:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 11:54:15 --> Controller Class Initialized
DEBUG - 2023-07-26 11:54:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 11:54:15 --> Database Driver Class Initialized
INFO - 2023-07-26 11:54:15 --> Model "Admin_model" initialized
INFO - 2023-07-26 11:54:15 --> Model "Student_model" initialized
INFO - 2023-07-26 11:54:15 --> Model "Teacher_model" initialized
INFO - 2023-07-26 11:54:15 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 11:54:15 --> Final output sent to browser
DEBUG - 2023-07-26 11:54:15 --> Total execution time: 0.0561
INFO - 2023-07-26 11:54:16 --> Config Class Initialized
INFO - 2023-07-26 11:54:16 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:54:16 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:54:16 --> Utf8 Class Initialized
INFO - 2023-07-26 11:54:16 --> URI Class Initialized
INFO - 2023-07-26 11:54:16 --> Router Class Initialized
INFO - 2023-07-26 11:54:16 --> Output Class Initialized
INFO - 2023-07-26 11:54:16 --> Security Class Initialized
DEBUG - 2023-07-26 11:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:54:16 --> Input Class Initialized
INFO - 2023-07-26 11:54:16 --> Language Class Initialized
INFO - 2023-07-26 11:54:16 --> Loader Class Initialized
INFO - 2023-07-26 11:54:16 --> Helper loaded: url_helper
INFO - 2023-07-26 11:54:16 --> Helper loaded: form_helper
INFO - 2023-07-26 11:54:16 --> Form Validation Class Initialized
DEBUG - 2023-07-26 11:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 11:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 11:54:16 --> Controller Class Initialized
DEBUG - 2023-07-26 11:54:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 11:54:16 --> Database Driver Class Initialized
INFO - 2023-07-26 11:54:16 --> Model "Admin_model" initialized
INFO - 2023-07-26 11:54:16 --> Model "Student_model" initialized
INFO - 2023-07-26 11:54:16 --> Model "Teacher_model" initialized
INFO - 2023-07-26 11:54:16 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 11:54:16 --> Final output sent to browser
DEBUG - 2023-07-26 11:54:16 --> Total execution time: 0.0489
INFO - 2023-07-26 11:56:54 --> Config Class Initialized
INFO - 2023-07-26 11:56:54 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:56:54 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:56:54 --> Utf8 Class Initialized
INFO - 2023-07-26 11:56:54 --> URI Class Initialized
INFO - 2023-07-26 11:56:54 --> Router Class Initialized
INFO - 2023-07-26 11:56:54 --> Output Class Initialized
INFO - 2023-07-26 11:56:54 --> Security Class Initialized
DEBUG - 2023-07-26 11:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:56:54 --> Input Class Initialized
INFO - 2023-07-26 11:56:54 --> Language Class Initialized
INFO - 2023-07-26 11:56:54 --> Loader Class Initialized
INFO - 2023-07-26 11:56:54 --> Helper loaded: url_helper
INFO - 2023-07-26 11:56:54 --> Helper loaded: form_helper
INFO - 2023-07-26 11:56:54 --> Form Validation Class Initialized
DEBUG - 2023-07-26 11:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 11:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 11:56:54 --> Controller Class Initialized
DEBUG - 2023-07-26 11:56:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 11:56:54 --> Database Driver Class Initialized
INFO - 2023-07-26 11:56:54 --> Model "Admin_model" initialized
INFO - 2023-07-26 11:56:54 --> Model "Student_model" initialized
INFO - 2023-07-26 11:56:54 --> Model "Teacher_model" initialized
INFO - 2023-07-26 11:56:54 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 11:56:54 --> Final output sent to browser
DEBUG - 2023-07-26 11:56:54 --> Total execution time: 0.0431
INFO - 2023-07-26 11:56:54 --> Config Class Initialized
INFO - 2023-07-26 11:56:54 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:56:54 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:56:54 --> Utf8 Class Initialized
INFO - 2023-07-26 11:56:54 --> URI Class Initialized
INFO - 2023-07-26 11:56:54 --> Router Class Initialized
INFO - 2023-07-26 11:56:54 --> Output Class Initialized
INFO - 2023-07-26 11:56:54 --> Security Class Initialized
DEBUG - 2023-07-26 11:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:56:54 --> Input Class Initialized
INFO - 2023-07-26 11:56:54 --> Language Class Initialized
INFO - 2023-07-26 11:56:54 --> Loader Class Initialized
INFO - 2023-07-26 11:56:54 --> Helper loaded: url_helper
INFO - 2023-07-26 11:56:54 --> Helper loaded: form_helper
INFO - 2023-07-26 11:56:54 --> Form Validation Class Initialized
DEBUG - 2023-07-26 11:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 11:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 11:56:54 --> Controller Class Initialized
DEBUG - 2023-07-26 11:56:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 11:56:54 --> Database Driver Class Initialized
INFO - 2023-07-26 11:56:54 --> Model "Admin_model" initialized
INFO - 2023-07-26 11:56:54 --> Model "Student_model" initialized
INFO - 2023-07-26 11:56:54 --> Model "Teacher_model" initialized
INFO - 2023-07-26 11:56:54 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 11:56:54 --> Final output sent to browser
DEBUG - 2023-07-26 11:56:54 --> Total execution time: 0.0351
INFO - 2023-07-26 11:56:54 --> Config Class Initialized
INFO - 2023-07-26 11:56:54 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:56:54 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:56:54 --> Utf8 Class Initialized
INFO - 2023-07-26 11:56:54 --> URI Class Initialized
INFO - 2023-07-26 11:56:54 --> Router Class Initialized
INFO - 2023-07-26 11:56:54 --> Output Class Initialized
INFO - 2023-07-26 11:56:54 --> Security Class Initialized
DEBUG - 2023-07-26 11:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:56:54 --> Input Class Initialized
INFO - 2023-07-26 11:56:54 --> Language Class Initialized
INFO - 2023-07-26 11:56:54 --> Loader Class Initialized
INFO - 2023-07-26 11:56:54 --> Helper loaded: url_helper
INFO - 2023-07-26 11:56:54 --> Helper loaded: form_helper
INFO - 2023-07-26 11:56:54 --> Form Validation Class Initialized
DEBUG - 2023-07-26 11:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 11:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 11:56:54 --> Controller Class Initialized
DEBUG - 2023-07-26 11:56:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 11:56:54 --> Database Driver Class Initialized
INFO - 2023-07-26 11:56:54 --> Model "Admin_model" initialized
INFO - 2023-07-26 11:56:54 --> Model "Student_model" initialized
INFO - 2023-07-26 11:56:54 --> Model "Teacher_model" initialized
INFO - 2023-07-26 11:56:54 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 11:56:54 --> Final output sent to browser
DEBUG - 2023-07-26 11:56:54 --> Total execution time: 0.0351
INFO - 2023-07-26 11:56:54 --> Config Class Initialized
INFO - 2023-07-26 11:56:54 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:56:54 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:56:54 --> Utf8 Class Initialized
INFO - 2023-07-26 11:56:54 --> URI Class Initialized
INFO - 2023-07-26 11:56:54 --> Router Class Initialized
INFO - 2023-07-26 11:56:54 --> Output Class Initialized
INFO - 2023-07-26 11:56:54 --> Security Class Initialized
DEBUG - 2023-07-26 11:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:56:54 --> Input Class Initialized
INFO - 2023-07-26 11:56:54 --> Language Class Initialized
INFO - 2023-07-26 11:56:54 --> Loader Class Initialized
INFO - 2023-07-26 11:56:54 --> Helper loaded: url_helper
INFO - 2023-07-26 11:56:54 --> Helper loaded: form_helper
INFO - 2023-07-26 11:56:54 --> Form Validation Class Initialized
DEBUG - 2023-07-26 11:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 11:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 11:56:54 --> Controller Class Initialized
DEBUG - 2023-07-26 11:56:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 11:56:54 --> Database Driver Class Initialized
INFO - 2023-07-26 11:56:55 --> Model "Admin_model" initialized
INFO - 2023-07-26 11:56:55 --> Model "Student_model" initialized
INFO - 2023-07-26 11:56:55 --> Model "Teacher_model" initialized
INFO - 2023-07-26 11:56:55 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 11:56:55 --> Final output sent to browser
DEBUG - 2023-07-26 11:56:55 --> Total execution time: 0.0587
INFO - 2023-07-26 11:56:55 --> Config Class Initialized
INFO - 2023-07-26 11:56:55 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:56:55 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:56:55 --> Utf8 Class Initialized
INFO - 2023-07-26 11:56:55 --> URI Class Initialized
INFO - 2023-07-26 11:56:55 --> Router Class Initialized
INFO - 2023-07-26 11:56:55 --> Output Class Initialized
INFO - 2023-07-26 11:56:55 --> Security Class Initialized
DEBUG - 2023-07-26 11:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:56:55 --> Input Class Initialized
INFO - 2023-07-26 11:56:55 --> Language Class Initialized
INFO - 2023-07-26 11:56:55 --> Loader Class Initialized
INFO - 2023-07-26 11:56:55 --> Helper loaded: url_helper
INFO - 2023-07-26 11:56:55 --> Helper loaded: form_helper
INFO - 2023-07-26 11:56:55 --> Form Validation Class Initialized
DEBUG - 2023-07-26 11:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 11:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 11:56:55 --> Controller Class Initialized
DEBUG - 2023-07-26 11:56:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 11:56:55 --> Database Driver Class Initialized
INFO - 2023-07-26 11:56:55 --> Model "Admin_model" initialized
INFO - 2023-07-26 11:56:55 --> Model "Student_model" initialized
INFO - 2023-07-26 11:56:55 --> Model "Teacher_model" initialized
INFO - 2023-07-26 11:56:55 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 11:56:55 --> Final output sent to browser
DEBUG - 2023-07-26 11:56:55 --> Total execution time: 0.0397
INFO - 2023-07-26 11:59:24 --> Config Class Initialized
INFO - 2023-07-26 11:59:24 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:59:24 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:59:24 --> Utf8 Class Initialized
INFO - 2023-07-26 11:59:24 --> URI Class Initialized
INFO - 2023-07-26 11:59:24 --> Router Class Initialized
INFO - 2023-07-26 11:59:24 --> Output Class Initialized
INFO - 2023-07-26 11:59:24 --> Security Class Initialized
DEBUG - 2023-07-26 11:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:59:24 --> Input Class Initialized
INFO - 2023-07-26 11:59:24 --> Language Class Initialized
ERROR - 2023-07-26 11:59:24 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 148
INFO - 2023-07-26 11:59:24 --> Config Class Initialized
INFO - 2023-07-26 11:59:24 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:59:24 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:59:24 --> Utf8 Class Initialized
INFO - 2023-07-26 11:59:24 --> URI Class Initialized
INFO - 2023-07-26 11:59:24 --> Router Class Initialized
INFO - 2023-07-26 11:59:24 --> Output Class Initialized
INFO - 2023-07-26 11:59:24 --> Security Class Initialized
DEBUG - 2023-07-26 11:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:59:24 --> Input Class Initialized
INFO - 2023-07-26 11:59:24 --> Language Class Initialized
ERROR - 2023-07-26 11:59:24 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 148
INFO - 2023-07-26 11:59:24 --> Config Class Initialized
INFO - 2023-07-26 11:59:24 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:59:24 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:59:24 --> Utf8 Class Initialized
INFO - 2023-07-26 11:59:24 --> URI Class Initialized
INFO - 2023-07-26 11:59:24 --> Router Class Initialized
INFO - 2023-07-26 11:59:24 --> Output Class Initialized
INFO - 2023-07-26 11:59:24 --> Security Class Initialized
DEBUG - 2023-07-26 11:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:59:24 --> Input Class Initialized
INFO - 2023-07-26 11:59:24 --> Language Class Initialized
ERROR - 2023-07-26 11:59:24 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 148
INFO - 2023-07-26 11:59:24 --> Config Class Initialized
INFO - 2023-07-26 11:59:24 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:59:24 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:59:24 --> Utf8 Class Initialized
INFO - 2023-07-26 11:59:24 --> URI Class Initialized
INFO - 2023-07-26 11:59:24 --> Router Class Initialized
INFO - 2023-07-26 11:59:24 --> Output Class Initialized
INFO - 2023-07-26 11:59:24 --> Security Class Initialized
DEBUG - 2023-07-26 11:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:59:24 --> Input Class Initialized
INFO - 2023-07-26 11:59:24 --> Language Class Initialized
ERROR - 2023-07-26 11:59:24 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 148
INFO - 2023-07-26 11:59:25 --> Config Class Initialized
INFO - 2023-07-26 11:59:25 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:59:25 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:59:25 --> Utf8 Class Initialized
INFO - 2023-07-26 11:59:25 --> URI Class Initialized
INFO - 2023-07-26 11:59:25 --> Router Class Initialized
INFO - 2023-07-26 11:59:25 --> Output Class Initialized
INFO - 2023-07-26 11:59:25 --> Security Class Initialized
DEBUG - 2023-07-26 11:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:59:25 --> Input Class Initialized
INFO - 2023-07-26 11:59:25 --> Language Class Initialized
ERROR - 2023-07-26 11:59:25 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 148
INFO - 2023-07-26 11:59:26 --> Config Class Initialized
INFO - 2023-07-26 11:59:26 --> Hooks Class Initialized
DEBUG - 2023-07-26 11:59:26 --> UTF-8 Support Enabled
INFO - 2023-07-26 11:59:26 --> Utf8 Class Initialized
INFO - 2023-07-26 11:59:26 --> URI Class Initialized
INFO - 2023-07-26 11:59:26 --> Router Class Initialized
INFO - 2023-07-26 11:59:26 --> Output Class Initialized
INFO - 2023-07-26 11:59:26 --> Security Class Initialized
DEBUG - 2023-07-26 11:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 11:59:26 --> Input Class Initialized
INFO - 2023-07-26 11:59:26 --> Language Class Initialized
ERROR - 2023-07-26 11:59:26 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 148
INFO - 2023-07-26 12:00:49 --> Config Class Initialized
INFO - 2023-07-26 12:00:49 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:00:49 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:00:49 --> Utf8 Class Initialized
INFO - 2023-07-26 12:00:49 --> URI Class Initialized
INFO - 2023-07-26 12:00:49 --> Router Class Initialized
INFO - 2023-07-26 12:00:49 --> Output Class Initialized
INFO - 2023-07-26 12:00:49 --> Security Class Initialized
DEBUG - 2023-07-26 12:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:00:49 --> Input Class Initialized
INFO - 2023-07-26 12:00:49 --> Language Class Initialized
INFO - 2023-07-26 12:00:49 --> Loader Class Initialized
INFO - 2023-07-26 12:00:49 --> Helper loaded: url_helper
INFO - 2023-07-26 12:00:49 --> Helper loaded: form_helper
INFO - 2023-07-26 12:00:49 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:00:49 --> Controller Class Initialized
DEBUG - 2023-07-26 12:00:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:00:49 --> Database Driver Class Initialized
INFO - 2023-07-26 12:00:49 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:00:49 --> Model "Student_model" initialized
INFO - 2023-07-26 12:00:49 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:00:49 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:00:49 --> Final output sent to browser
DEBUG - 2023-07-26 12:00:49 --> Total execution time: 0.0399
INFO - 2023-07-26 12:00:50 --> Config Class Initialized
INFO - 2023-07-26 12:00:50 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:00:50 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:00:50 --> Utf8 Class Initialized
INFO - 2023-07-26 12:00:50 --> URI Class Initialized
INFO - 2023-07-26 12:00:50 --> Router Class Initialized
INFO - 2023-07-26 12:00:50 --> Output Class Initialized
INFO - 2023-07-26 12:00:50 --> Security Class Initialized
DEBUG - 2023-07-26 12:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:00:50 --> Input Class Initialized
INFO - 2023-07-26 12:00:50 --> Language Class Initialized
INFO - 2023-07-26 12:00:50 --> Loader Class Initialized
INFO - 2023-07-26 12:00:50 --> Helper loaded: url_helper
INFO - 2023-07-26 12:00:50 --> Helper loaded: form_helper
INFO - 2023-07-26 12:00:50 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:00:50 --> Controller Class Initialized
DEBUG - 2023-07-26 12:00:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:00:50 --> Database Driver Class Initialized
INFO - 2023-07-26 12:00:50 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:00:50 --> Model "Student_model" initialized
INFO - 2023-07-26 12:00:50 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:00:50 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:00:50 --> Final output sent to browser
DEBUG - 2023-07-26 12:00:50 --> Total execution time: 0.0494
INFO - 2023-07-26 12:00:50 --> Config Class Initialized
INFO - 2023-07-26 12:00:50 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:00:50 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:00:50 --> Utf8 Class Initialized
INFO - 2023-07-26 12:00:50 --> URI Class Initialized
INFO - 2023-07-26 12:00:50 --> Router Class Initialized
INFO - 2023-07-26 12:00:50 --> Output Class Initialized
INFO - 2023-07-26 12:00:50 --> Security Class Initialized
DEBUG - 2023-07-26 12:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:00:50 --> Input Class Initialized
INFO - 2023-07-26 12:00:50 --> Language Class Initialized
INFO - 2023-07-26 12:00:50 --> Loader Class Initialized
INFO - 2023-07-26 12:00:50 --> Helper loaded: url_helper
INFO - 2023-07-26 12:00:50 --> Helper loaded: form_helper
INFO - 2023-07-26 12:00:50 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:00:50 --> Controller Class Initialized
DEBUG - 2023-07-26 12:00:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:00:50 --> Database Driver Class Initialized
INFO - 2023-07-26 12:00:50 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:00:50 --> Model "Student_model" initialized
INFO - 2023-07-26 12:00:50 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:00:50 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:00:50 --> Final output sent to browser
DEBUG - 2023-07-26 12:00:50 --> Total execution time: 0.0499
INFO - 2023-07-26 12:00:50 --> Config Class Initialized
INFO - 2023-07-26 12:00:50 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:00:50 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:00:50 --> Utf8 Class Initialized
INFO - 2023-07-26 12:00:50 --> URI Class Initialized
INFO - 2023-07-26 12:00:50 --> Router Class Initialized
INFO - 2023-07-26 12:00:50 --> Output Class Initialized
INFO - 2023-07-26 12:00:50 --> Security Class Initialized
DEBUG - 2023-07-26 12:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:00:50 --> Input Class Initialized
INFO - 2023-07-26 12:00:50 --> Language Class Initialized
INFO - 2023-07-26 12:00:50 --> Loader Class Initialized
INFO - 2023-07-26 12:00:50 --> Helper loaded: url_helper
INFO - 2023-07-26 12:00:50 --> Helper loaded: form_helper
INFO - 2023-07-26 12:00:50 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:00:50 --> Controller Class Initialized
DEBUG - 2023-07-26 12:00:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:00:50 --> Database Driver Class Initialized
INFO - 2023-07-26 12:00:50 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:00:50 --> Model "Student_model" initialized
INFO - 2023-07-26 12:00:50 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:00:50 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:00:50 --> Final output sent to browser
DEBUG - 2023-07-26 12:00:50 --> Total execution time: 0.0493
INFO - 2023-07-26 12:00:50 --> Config Class Initialized
INFO - 2023-07-26 12:00:50 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:00:50 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:00:50 --> Utf8 Class Initialized
INFO - 2023-07-26 12:00:50 --> URI Class Initialized
INFO - 2023-07-26 12:00:50 --> Router Class Initialized
INFO - 2023-07-26 12:00:50 --> Output Class Initialized
INFO - 2023-07-26 12:00:50 --> Security Class Initialized
DEBUG - 2023-07-26 12:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:00:50 --> Input Class Initialized
INFO - 2023-07-26 12:00:50 --> Language Class Initialized
INFO - 2023-07-26 12:00:50 --> Loader Class Initialized
INFO - 2023-07-26 12:00:50 --> Helper loaded: url_helper
INFO - 2023-07-26 12:00:50 --> Helper loaded: form_helper
INFO - 2023-07-26 12:00:50 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:00:50 --> Controller Class Initialized
DEBUG - 2023-07-26 12:00:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:00:50 --> Database Driver Class Initialized
INFO - 2023-07-26 12:00:50 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:00:50 --> Model "Student_model" initialized
INFO - 2023-07-26 12:00:50 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:00:50 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:00:50 --> Final output sent to browser
DEBUG - 2023-07-26 12:00:50 --> Total execution time: 0.0489
INFO - 2023-07-26 12:00:50 --> Config Class Initialized
INFO - 2023-07-26 12:00:50 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:00:50 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:00:50 --> Utf8 Class Initialized
INFO - 2023-07-26 12:00:50 --> URI Class Initialized
INFO - 2023-07-26 12:00:50 --> Router Class Initialized
INFO - 2023-07-26 12:00:50 --> Output Class Initialized
INFO - 2023-07-26 12:00:50 --> Security Class Initialized
DEBUG - 2023-07-26 12:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:00:50 --> Input Class Initialized
INFO - 2023-07-26 12:00:50 --> Language Class Initialized
INFO - 2023-07-26 12:00:50 --> Loader Class Initialized
INFO - 2023-07-26 12:00:50 --> Helper loaded: url_helper
INFO - 2023-07-26 12:00:50 --> Helper loaded: form_helper
INFO - 2023-07-26 12:00:50 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:00:50 --> Controller Class Initialized
DEBUG - 2023-07-26 12:00:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:00:50 --> Database Driver Class Initialized
INFO - 2023-07-26 12:00:50 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:00:50 --> Model "Student_model" initialized
INFO - 2023-07-26 12:00:50 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:00:50 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:00:50 --> Final output sent to browser
DEBUG - 2023-07-26 12:00:50 --> Total execution time: 0.0415
INFO - 2023-07-26 12:00:58 --> Config Class Initialized
INFO - 2023-07-26 12:00:58 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:00:58 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:00:58 --> Utf8 Class Initialized
INFO - 2023-07-26 12:00:58 --> URI Class Initialized
INFO - 2023-07-26 12:00:58 --> Router Class Initialized
INFO - 2023-07-26 12:00:58 --> Output Class Initialized
INFO - 2023-07-26 12:00:58 --> Security Class Initialized
DEBUG - 2023-07-26 12:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:00:58 --> Input Class Initialized
INFO - 2023-07-26 12:00:58 --> Language Class Initialized
INFO - 2023-07-26 12:00:58 --> Loader Class Initialized
INFO - 2023-07-26 12:00:58 --> Helper loaded: url_helper
INFO - 2023-07-26 12:00:58 --> Helper loaded: form_helper
INFO - 2023-07-26 12:00:58 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:00:58 --> Controller Class Initialized
DEBUG - 2023-07-26 12:00:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:00:58 --> Database Driver Class Initialized
INFO - 2023-07-26 12:00:58 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:00:58 --> Model "Student_model" initialized
INFO - 2023-07-26 12:00:58 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:00:58 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:00:58 --> Final output sent to browser
DEBUG - 2023-07-26 12:00:58 --> Total execution time: 0.0382
INFO - 2023-07-26 12:01:46 --> Config Class Initialized
INFO - 2023-07-26 12:01:46 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:01:46 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:01:46 --> Utf8 Class Initialized
INFO - 2023-07-26 12:01:46 --> URI Class Initialized
INFO - 2023-07-26 12:01:46 --> Router Class Initialized
INFO - 2023-07-26 12:01:46 --> Output Class Initialized
INFO - 2023-07-26 12:01:46 --> Security Class Initialized
DEBUG - 2023-07-26 12:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:01:46 --> Input Class Initialized
INFO - 2023-07-26 12:01:46 --> Language Class Initialized
INFO - 2023-07-26 12:01:46 --> Loader Class Initialized
INFO - 2023-07-26 12:01:46 --> Helper loaded: url_helper
INFO - 2023-07-26 12:01:46 --> Helper loaded: form_helper
INFO - 2023-07-26 12:01:46 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:01:46 --> Controller Class Initialized
DEBUG - 2023-07-26 12:01:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:01:46 --> Database Driver Class Initialized
INFO - 2023-07-26 12:01:46 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:01:46 --> Model "Student_model" initialized
INFO - 2023-07-26 12:01:46 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:01:46 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:01:46 --> Final output sent to browser
DEBUG - 2023-07-26 12:01:46 --> Total execution time: 0.0491
INFO - 2023-07-26 12:11:03 --> Config Class Initialized
INFO - 2023-07-26 12:11:03 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:11:03 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:11:03 --> Utf8 Class Initialized
INFO - 2023-07-26 12:11:03 --> URI Class Initialized
INFO - 2023-07-26 12:11:03 --> Router Class Initialized
INFO - 2023-07-26 12:11:03 --> Output Class Initialized
INFO - 2023-07-26 12:11:03 --> Security Class Initialized
DEBUG - 2023-07-26 12:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:11:03 --> Input Class Initialized
INFO - 2023-07-26 12:11:03 --> Language Class Initialized
INFO - 2023-07-26 12:11:03 --> Loader Class Initialized
INFO - 2023-07-26 12:11:03 --> Helper loaded: url_helper
INFO - 2023-07-26 12:11:03 --> Helper loaded: form_helper
INFO - 2023-07-26 12:11:03 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:11:03 --> Controller Class Initialized
DEBUG - 2023-07-26 12:11:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:11:04 --> Database Driver Class Initialized
INFO - 2023-07-26 12:11:04 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:11:04 --> Model "Student_model" initialized
INFO - 2023-07-26 12:11:04 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:11:04 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:11:04 --> Final output sent to browser
DEBUG - 2023-07-26 12:11:04 --> Total execution time: 0.0345
INFO - 2023-07-26 12:11:11 --> Config Class Initialized
INFO - 2023-07-26 12:11:11 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:11:11 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:11:11 --> Utf8 Class Initialized
INFO - 2023-07-26 12:11:11 --> URI Class Initialized
INFO - 2023-07-26 12:11:11 --> Router Class Initialized
INFO - 2023-07-26 12:11:11 --> Output Class Initialized
INFO - 2023-07-26 12:11:11 --> Security Class Initialized
DEBUG - 2023-07-26 12:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:11:11 --> Input Class Initialized
INFO - 2023-07-26 12:11:11 --> Language Class Initialized
INFO - 2023-07-26 12:11:11 --> Loader Class Initialized
INFO - 2023-07-26 12:11:11 --> Helper loaded: url_helper
INFO - 2023-07-26 12:11:11 --> Helper loaded: form_helper
INFO - 2023-07-26 12:11:11 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:11:11 --> Controller Class Initialized
DEBUG - 2023-07-26 12:11:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:11:11 --> Database Driver Class Initialized
INFO - 2023-07-26 12:11:11 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:11:11 --> Model "Student_model" initialized
INFO - 2023-07-26 12:11:11 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:11:11 --> Config Class Initialized
INFO - 2023-07-26 12:11:11 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:11:11 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:11:11 --> Utf8 Class Initialized
INFO - 2023-07-26 12:11:11 --> URI Class Initialized
INFO - 2023-07-26 12:11:11 --> Router Class Initialized
INFO - 2023-07-26 12:11:11 --> Output Class Initialized
INFO - 2023-07-26 12:11:11 --> Security Class Initialized
DEBUG - 2023-07-26 12:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:11:11 --> Input Class Initialized
INFO - 2023-07-26 12:11:11 --> Language Class Initialized
ERROR - 2023-07-26 12:11:11 --> 404 Page Not Found: Admin/teachers_dashboard
INFO - 2023-07-26 12:11:30 --> Config Class Initialized
INFO - 2023-07-26 12:11:30 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:11:30 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:11:30 --> Utf8 Class Initialized
INFO - 2023-07-26 12:11:30 --> URI Class Initialized
INFO - 2023-07-26 12:11:30 --> Router Class Initialized
INFO - 2023-07-26 12:11:30 --> Output Class Initialized
INFO - 2023-07-26 12:11:30 --> Security Class Initialized
DEBUG - 2023-07-26 12:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:11:30 --> Input Class Initialized
INFO - 2023-07-26 12:11:30 --> Language Class Initialized
INFO - 2023-07-26 12:11:30 --> Loader Class Initialized
INFO - 2023-07-26 12:11:30 --> Helper loaded: url_helper
INFO - 2023-07-26 12:11:30 --> Helper loaded: form_helper
INFO - 2023-07-26 12:11:30 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:11:30 --> Controller Class Initialized
DEBUG - 2023-07-26 12:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:11:30 --> Database Driver Class Initialized
INFO - 2023-07-26 12:11:30 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:11:30 --> Model "Student_model" initialized
INFO - 2023-07-26 12:11:30 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:11:30 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:11:30 --> Final output sent to browser
DEBUG - 2023-07-26 12:11:30 --> Total execution time: 0.0367
INFO - 2023-07-26 12:11:34 --> Config Class Initialized
INFO - 2023-07-26 12:11:34 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:11:34 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:11:34 --> Utf8 Class Initialized
INFO - 2023-07-26 12:11:34 --> URI Class Initialized
INFO - 2023-07-26 12:11:34 --> Router Class Initialized
INFO - 2023-07-26 12:11:34 --> Output Class Initialized
INFO - 2023-07-26 12:11:34 --> Security Class Initialized
DEBUG - 2023-07-26 12:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:11:34 --> Input Class Initialized
INFO - 2023-07-26 12:11:34 --> Language Class Initialized
INFO - 2023-07-26 12:11:34 --> Loader Class Initialized
INFO - 2023-07-26 12:11:34 --> Helper loaded: url_helper
INFO - 2023-07-26 12:11:34 --> Helper loaded: form_helper
INFO - 2023-07-26 12:11:34 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:11:34 --> Controller Class Initialized
DEBUG - 2023-07-26 12:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:11:34 --> Database Driver Class Initialized
INFO - 2023-07-26 12:11:34 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:11:34 --> Model "Student_model" initialized
INFO - 2023-07-26 12:11:34 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:11:34 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:11:34 --> Final output sent to browser
DEBUG - 2023-07-26 12:11:34 --> Total execution time: 0.0571
INFO - 2023-07-26 12:11:45 --> Config Class Initialized
INFO - 2023-07-26 12:11:45 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:11:45 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:11:45 --> Utf8 Class Initialized
INFO - 2023-07-26 12:11:45 --> URI Class Initialized
INFO - 2023-07-26 12:11:45 --> Router Class Initialized
INFO - 2023-07-26 12:11:45 --> Output Class Initialized
INFO - 2023-07-26 12:11:45 --> Security Class Initialized
DEBUG - 2023-07-26 12:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:11:45 --> Input Class Initialized
INFO - 2023-07-26 12:11:45 --> Language Class Initialized
INFO - 2023-07-26 12:11:45 --> Loader Class Initialized
INFO - 2023-07-26 12:11:45 --> Helper loaded: url_helper
INFO - 2023-07-26 12:11:45 --> Helper loaded: form_helper
INFO - 2023-07-26 12:11:45 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:11:45 --> Controller Class Initialized
DEBUG - 2023-07-26 12:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:11:46 --> Database Driver Class Initialized
INFO - 2023-07-26 12:11:46 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:11:46 --> Model "Student_model" initialized
INFO - 2023-07-26 12:11:46 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:11:46 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:11:46 --> Final output sent to browser
DEBUG - 2023-07-26 12:11:46 --> Total execution time: 0.0559
INFO - 2023-07-26 12:12:12 --> Config Class Initialized
INFO - 2023-07-26 12:12:12 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:12:12 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:12:12 --> Utf8 Class Initialized
INFO - 2023-07-26 12:12:12 --> URI Class Initialized
INFO - 2023-07-26 12:12:12 --> Router Class Initialized
INFO - 2023-07-26 12:12:12 --> Output Class Initialized
INFO - 2023-07-26 12:12:12 --> Security Class Initialized
DEBUG - 2023-07-26 12:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:12:12 --> Input Class Initialized
INFO - 2023-07-26 12:12:12 --> Language Class Initialized
INFO - 2023-07-26 12:12:12 --> Loader Class Initialized
INFO - 2023-07-26 12:12:12 --> Helper loaded: url_helper
INFO - 2023-07-26 12:12:12 --> Helper loaded: form_helper
INFO - 2023-07-26 12:12:12 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:12:12 --> Controller Class Initialized
DEBUG - 2023-07-26 12:12:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:12:12 --> Database Driver Class Initialized
INFO - 2023-07-26 12:12:12 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:12:12 --> Model "Student_model" initialized
INFO - 2023-07-26 12:12:12 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:12:12 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:12:12 --> Final output sent to browser
DEBUG - 2023-07-26 12:12:12 --> Total execution time: 0.0346
INFO - 2023-07-26 12:12:14 --> Config Class Initialized
INFO - 2023-07-26 12:12:14 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:12:14 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:12:14 --> Utf8 Class Initialized
INFO - 2023-07-26 12:12:14 --> URI Class Initialized
INFO - 2023-07-26 12:12:14 --> Router Class Initialized
INFO - 2023-07-26 12:12:14 --> Output Class Initialized
INFO - 2023-07-26 12:12:14 --> Security Class Initialized
DEBUG - 2023-07-26 12:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:12:14 --> Input Class Initialized
INFO - 2023-07-26 12:12:14 --> Language Class Initialized
INFO - 2023-07-26 12:12:14 --> Loader Class Initialized
INFO - 2023-07-26 12:12:14 --> Helper loaded: url_helper
INFO - 2023-07-26 12:12:14 --> Helper loaded: form_helper
INFO - 2023-07-26 12:12:14 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:12:14 --> Controller Class Initialized
DEBUG - 2023-07-26 12:12:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:12:14 --> Database Driver Class Initialized
INFO - 2023-07-26 12:12:14 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:12:14 --> Model "Student_model" initialized
INFO - 2023-07-26 12:12:14 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:12:14 --> Config Class Initialized
INFO - 2023-07-26 12:12:14 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:12:14 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:12:14 --> Utf8 Class Initialized
INFO - 2023-07-26 12:12:14 --> URI Class Initialized
INFO - 2023-07-26 12:12:14 --> Router Class Initialized
INFO - 2023-07-26 12:12:14 --> Output Class Initialized
INFO - 2023-07-26 12:12:14 --> Security Class Initialized
DEBUG - 2023-07-26 12:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:12:14 --> Input Class Initialized
INFO - 2023-07-26 12:12:14 --> Language Class Initialized
INFO - 2023-07-26 12:12:14 --> Loader Class Initialized
INFO - 2023-07-26 12:12:14 --> Helper loaded: url_helper
INFO - 2023-07-26 12:12:14 --> Helper loaded: form_helper
INFO - 2023-07-26 12:12:14 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:12:14 --> Controller Class Initialized
DEBUG - 2023-07-26 12:12:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:12:14 --> Database Driver Class Initialized
INFO - 2023-07-26 12:12:14 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:12:14 --> Model "Student_model" initialized
INFO - 2023-07-26 12:12:14 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:12:14 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:12:14 --> Final output sent to browser
DEBUG - 2023-07-26 12:12:14 --> Total execution time: 0.0471
INFO - 2023-07-26 12:12:37 --> Config Class Initialized
INFO - 2023-07-26 12:12:37 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:12:37 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:12:37 --> Utf8 Class Initialized
INFO - 2023-07-26 12:12:37 --> URI Class Initialized
INFO - 2023-07-26 12:12:37 --> Router Class Initialized
INFO - 2023-07-26 12:12:37 --> Output Class Initialized
INFO - 2023-07-26 12:12:37 --> Security Class Initialized
DEBUG - 2023-07-26 12:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:12:37 --> Input Class Initialized
INFO - 2023-07-26 12:12:37 --> Language Class Initialized
INFO - 2023-07-26 12:12:37 --> Loader Class Initialized
INFO - 2023-07-26 12:12:37 --> Helper loaded: url_helper
INFO - 2023-07-26 12:12:37 --> Helper loaded: form_helper
INFO - 2023-07-26 12:12:37 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:12:37 --> Controller Class Initialized
DEBUG - 2023-07-26 12:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:12:37 --> Database Driver Class Initialized
INFO - 2023-07-26 12:12:37 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:12:37 --> Model "Student_model" initialized
INFO - 2023-07-26 12:12:37 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:12:37 --> Config Class Initialized
INFO - 2023-07-26 12:12:37 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:12:37 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:12:37 --> Utf8 Class Initialized
INFO - 2023-07-26 12:12:37 --> URI Class Initialized
INFO - 2023-07-26 12:12:37 --> Router Class Initialized
INFO - 2023-07-26 12:12:37 --> Output Class Initialized
INFO - 2023-07-26 12:12:37 --> Security Class Initialized
DEBUG - 2023-07-26 12:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:12:37 --> Input Class Initialized
INFO - 2023-07-26 12:12:37 --> Language Class Initialized
INFO - 2023-07-26 12:12:37 --> Loader Class Initialized
INFO - 2023-07-26 12:12:37 --> Helper loaded: url_helper
INFO - 2023-07-26 12:12:37 --> Helper loaded: form_helper
INFO - 2023-07-26 12:12:37 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:12:37 --> Controller Class Initialized
DEBUG - 2023-07-26 12:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:12:37 --> Database Driver Class Initialized
INFO - 2023-07-26 12:12:37 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:12:37 --> Model "Student_model" initialized
INFO - 2023-07-26 12:12:37 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:12:37 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:12:37 --> Final output sent to browser
DEBUG - 2023-07-26 12:12:37 --> Total execution time: 0.0463
INFO - 2023-07-26 12:12:41 --> Config Class Initialized
INFO - 2023-07-26 12:12:41 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:12:41 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:12:41 --> Utf8 Class Initialized
INFO - 2023-07-26 12:12:41 --> URI Class Initialized
INFO - 2023-07-26 12:12:41 --> Router Class Initialized
INFO - 2023-07-26 12:12:41 --> Output Class Initialized
INFO - 2023-07-26 12:12:41 --> Security Class Initialized
DEBUG - 2023-07-26 12:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:12:41 --> Input Class Initialized
INFO - 2023-07-26 12:12:41 --> Language Class Initialized
INFO - 2023-07-26 12:12:41 --> Loader Class Initialized
INFO - 2023-07-26 12:12:41 --> Helper loaded: url_helper
INFO - 2023-07-26 12:12:41 --> Helper loaded: form_helper
INFO - 2023-07-26 12:12:41 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:12:41 --> Controller Class Initialized
DEBUG - 2023-07-26 12:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:12:41 --> Database Driver Class Initialized
INFO - 2023-07-26 12:12:41 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:12:41 --> Model "Student_model" initialized
INFO - 2023-07-26 12:12:41 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:12:41 --> Config Class Initialized
INFO - 2023-07-26 12:12:41 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:12:41 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:12:41 --> Utf8 Class Initialized
INFO - 2023-07-26 12:12:41 --> URI Class Initialized
INFO - 2023-07-26 12:12:41 --> Router Class Initialized
INFO - 2023-07-26 12:12:41 --> Output Class Initialized
INFO - 2023-07-26 12:12:41 --> Security Class Initialized
DEBUG - 2023-07-26 12:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:12:41 --> Input Class Initialized
INFO - 2023-07-26 12:12:41 --> Language Class Initialized
INFO - 2023-07-26 12:12:41 --> Loader Class Initialized
INFO - 2023-07-26 12:12:41 --> Helper loaded: url_helper
INFO - 2023-07-26 12:12:41 --> Helper loaded: form_helper
INFO - 2023-07-26 12:12:41 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:12:41 --> Controller Class Initialized
DEBUG - 2023-07-26 12:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:12:41 --> Database Driver Class Initialized
INFO - 2023-07-26 12:12:41 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:12:41 --> Model "Student_model" initialized
INFO - 2023-07-26 12:12:41 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:12:41 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:12:41 --> Final output sent to browser
DEBUG - 2023-07-26 12:12:41 --> Total execution time: 0.0450
INFO - 2023-07-26 12:12:42 --> Config Class Initialized
INFO - 2023-07-26 12:12:42 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:12:42 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:12:42 --> Utf8 Class Initialized
INFO - 2023-07-26 12:12:42 --> URI Class Initialized
INFO - 2023-07-26 12:12:42 --> Router Class Initialized
INFO - 2023-07-26 12:12:42 --> Output Class Initialized
INFO - 2023-07-26 12:12:42 --> Security Class Initialized
DEBUG - 2023-07-26 12:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:12:42 --> Input Class Initialized
INFO - 2023-07-26 12:12:42 --> Language Class Initialized
INFO - 2023-07-26 12:12:42 --> Loader Class Initialized
INFO - 2023-07-26 12:12:42 --> Helper loaded: url_helper
INFO - 2023-07-26 12:12:42 --> Helper loaded: form_helper
INFO - 2023-07-26 12:12:42 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:12:42 --> Controller Class Initialized
DEBUG - 2023-07-26 12:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:12:42 --> Database Driver Class Initialized
INFO - 2023-07-26 12:12:42 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:12:42 --> Model "Student_model" initialized
INFO - 2023-07-26 12:12:42 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:12:42 --> Config Class Initialized
INFO - 2023-07-26 12:12:42 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:12:42 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:12:42 --> Utf8 Class Initialized
INFO - 2023-07-26 12:12:42 --> URI Class Initialized
INFO - 2023-07-26 12:12:42 --> Router Class Initialized
INFO - 2023-07-26 12:12:42 --> Output Class Initialized
INFO - 2023-07-26 12:12:42 --> Security Class Initialized
DEBUG - 2023-07-26 12:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:12:42 --> Input Class Initialized
INFO - 2023-07-26 12:12:42 --> Language Class Initialized
INFO - 2023-07-26 12:12:42 --> Loader Class Initialized
INFO - 2023-07-26 12:12:42 --> Helper loaded: url_helper
INFO - 2023-07-26 12:12:42 --> Helper loaded: form_helper
INFO - 2023-07-26 12:12:42 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:12:42 --> Controller Class Initialized
DEBUG - 2023-07-26 12:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:12:42 --> Database Driver Class Initialized
INFO - 2023-07-26 12:12:42 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:12:42 --> Model "Student_model" initialized
INFO - 2023-07-26 12:12:42 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:12:42 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:12:42 --> Final output sent to browser
DEBUG - 2023-07-26 12:12:42 --> Total execution time: 0.0552
INFO - 2023-07-26 12:12:45 --> Config Class Initialized
INFO - 2023-07-26 12:12:45 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:12:45 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:12:45 --> Utf8 Class Initialized
INFO - 2023-07-26 12:12:45 --> URI Class Initialized
INFO - 2023-07-26 12:12:45 --> Router Class Initialized
INFO - 2023-07-26 12:12:45 --> Output Class Initialized
INFO - 2023-07-26 12:12:45 --> Security Class Initialized
DEBUG - 2023-07-26 12:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:12:45 --> Input Class Initialized
INFO - 2023-07-26 12:12:45 --> Language Class Initialized
INFO - 2023-07-26 12:12:45 --> Loader Class Initialized
INFO - 2023-07-26 12:12:45 --> Helper loaded: url_helper
INFO - 2023-07-26 12:12:45 --> Helper loaded: form_helper
INFO - 2023-07-26 12:12:45 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:12:45 --> Controller Class Initialized
DEBUG - 2023-07-26 12:12:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:12:45 --> Database Driver Class Initialized
INFO - 2023-07-26 12:12:45 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:12:45 --> Model "Student_model" initialized
INFO - 2023-07-26 12:12:45 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:12:45 --> Config Class Initialized
INFO - 2023-07-26 12:12:45 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:12:45 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:12:45 --> Utf8 Class Initialized
INFO - 2023-07-26 12:12:45 --> URI Class Initialized
INFO - 2023-07-26 12:12:45 --> Router Class Initialized
INFO - 2023-07-26 12:12:45 --> Output Class Initialized
INFO - 2023-07-26 12:12:45 --> Security Class Initialized
DEBUG - 2023-07-26 12:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:12:45 --> Input Class Initialized
INFO - 2023-07-26 12:12:45 --> Language Class Initialized
INFO - 2023-07-26 12:12:45 --> Loader Class Initialized
INFO - 2023-07-26 12:12:45 --> Helper loaded: url_helper
INFO - 2023-07-26 12:12:45 --> Helper loaded: form_helper
INFO - 2023-07-26 12:12:45 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:12:45 --> Controller Class Initialized
DEBUG - 2023-07-26 12:12:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:12:45 --> Database Driver Class Initialized
INFO - 2023-07-26 12:12:45 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:12:45 --> Model "Student_model" initialized
INFO - 2023-07-26 12:12:45 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:12:45 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:12:45 --> Final output sent to browser
DEBUG - 2023-07-26 12:12:45 --> Total execution time: 0.0577
INFO - 2023-07-26 12:12:53 --> Config Class Initialized
INFO - 2023-07-26 12:12:53 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:12:53 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:12:53 --> Utf8 Class Initialized
INFO - 2023-07-26 12:12:53 --> URI Class Initialized
INFO - 2023-07-26 12:12:53 --> Router Class Initialized
INFO - 2023-07-26 12:12:53 --> Output Class Initialized
INFO - 2023-07-26 12:12:53 --> Security Class Initialized
DEBUG - 2023-07-26 12:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:12:53 --> Input Class Initialized
INFO - 2023-07-26 12:12:53 --> Language Class Initialized
INFO - 2023-07-26 12:12:53 --> Loader Class Initialized
INFO - 2023-07-26 12:12:53 --> Helper loaded: url_helper
INFO - 2023-07-26 12:12:53 --> Helper loaded: form_helper
INFO - 2023-07-26 12:12:53 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:12:53 --> Controller Class Initialized
DEBUG - 2023-07-26 12:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:12:53 --> Database Driver Class Initialized
INFO - 2023-07-26 12:12:53 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:12:53 --> Model "Student_model" initialized
INFO - 2023-07-26 12:12:53 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:12:53 --> Config Class Initialized
INFO - 2023-07-26 12:12:53 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:12:53 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:12:53 --> Utf8 Class Initialized
INFO - 2023-07-26 12:12:53 --> URI Class Initialized
INFO - 2023-07-26 12:12:53 --> Router Class Initialized
INFO - 2023-07-26 12:12:53 --> Output Class Initialized
INFO - 2023-07-26 12:12:53 --> Security Class Initialized
DEBUG - 2023-07-26 12:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:12:53 --> Input Class Initialized
INFO - 2023-07-26 12:12:53 --> Language Class Initialized
INFO - 2023-07-26 12:12:53 --> Loader Class Initialized
INFO - 2023-07-26 12:12:53 --> Helper loaded: url_helper
INFO - 2023-07-26 12:12:53 --> Helper loaded: form_helper
INFO - 2023-07-26 12:12:53 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:12:53 --> Controller Class Initialized
DEBUG - 2023-07-26 12:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:12:53 --> Database Driver Class Initialized
INFO - 2023-07-26 12:12:53 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:12:53 --> Model "Student_model" initialized
INFO - 2023-07-26 12:12:53 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:12:53 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:12:53 --> Final output sent to browser
DEBUG - 2023-07-26 12:12:53 --> Total execution time: 0.0550
INFO - 2023-07-26 12:13:05 --> Config Class Initialized
INFO - 2023-07-26 12:13:05 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:13:05 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:13:05 --> Utf8 Class Initialized
INFO - 2023-07-26 12:13:05 --> URI Class Initialized
INFO - 2023-07-26 12:13:05 --> Router Class Initialized
INFO - 2023-07-26 12:13:05 --> Output Class Initialized
INFO - 2023-07-26 12:13:05 --> Security Class Initialized
DEBUG - 2023-07-26 12:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:13:05 --> Input Class Initialized
INFO - 2023-07-26 12:13:05 --> Language Class Initialized
INFO - 2023-07-26 12:13:05 --> Loader Class Initialized
INFO - 2023-07-26 12:13:05 --> Helper loaded: url_helper
INFO - 2023-07-26 12:13:05 --> Helper loaded: form_helper
INFO - 2023-07-26 12:13:05 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:13:05 --> Controller Class Initialized
DEBUG - 2023-07-26 12:13:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:13:05 --> Database Driver Class Initialized
INFO - 2023-07-26 12:13:05 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:13:05 --> Model "Student_model" initialized
INFO - 2023-07-26 12:13:05 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:13:05 --> Config Class Initialized
INFO - 2023-07-26 12:13:05 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:13:05 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:13:05 --> Utf8 Class Initialized
INFO - 2023-07-26 12:13:05 --> URI Class Initialized
INFO - 2023-07-26 12:13:05 --> Router Class Initialized
INFO - 2023-07-26 12:13:05 --> Output Class Initialized
INFO - 2023-07-26 12:13:05 --> Security Class Initialized
DEBUG - 2023-07-26 12:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:13:05 --> Input Class Initialized
INFO - 2023-07-26 12:13:05 --> Language Class Initialized
INFO - 2023-07-26 12:13:05 --> Loader Class Initialized
INFO - 2023-07-26 12:13:05 --> Helper loaded: url_helper
INFO - 2023-07-26 12:13:05 --> Helper loaded: form_helper
INFO - 2023-07-26 12:13:05 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:13:05 --> Controller Class Initialized
DEBUG - 2023-07-26 12:13:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:13:05 --> Database Driver Class Initialized
INFO - 2023-07-26 12:13:05 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:13:05 --> Model "Student_model" initialized
INFO - 2023-07-26 12:13:05 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:13:05 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:13:05 --> Final output sent to browser
DEBUG - 2023-07-26 12:13:05 --> Total execution time: 0.0550
INFO - 2023-07-26 12:13:08 --> Config Class Initialized
INFO - 2023-07-26 12:13:08 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:13:08 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:13:08 --> Utf8 Class Initialized
INFO - 2023-07-26 12:13:08 --> URI Class Initialized
INFO - 2023-07-26 12:13:08 --> Router Class Initialized
INFO - 2023-07-26 12:13:08 --> Output Class Initialized
INFO - 2023-07-26 12:13:08 --> Security Class Initialized
DEBUG - 2023-07-26 12:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:13:08 --> Input Class Initialized
INFO - 2023-07-26 12:13:08 --> Language Class Initialized
INFO - 2023-07-26 12:13:08 --> Loader Class Initialized
INFO - 2023-07-26 12:13:08 --> Helper loaded: url_helper
INFO - 2023-07-26 12:13:08 --> Helper loaded: form_helper
INFO - 2023-07-26 12:13:08 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:13:08 --> Controller Class Initialized
DEBUG - 2023-07-26 12:13:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:13:08 --> Database Driver Class Initialized
INFO - 2023-07-26 12:13:08 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:13:08 --> Model "Student_model" initialized
INFO - 2023-07-26 12:13:08 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:13:08 --> Config Class Initialized
INFO - 2023-07-26 12:13:08 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:13:08 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:13:08 --> Utf8 Class Initialized
INFO - 2023-07-26 12:13:08 --> URI Class Initialized
INFO - 2023-07-26 12:13:08 --> Router Class Initialized
INFO - 2023-07-26 12:13:08 --> Output Class Initialized
INFO - 2023-07-26 12:13:08 --> Security Class Initialized
DEBUG - 2023-07-26 12:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:13:08 --> Input Class Initialized
INFO - 2023-07-26 12:13:08 --> Language Class Initialized
INFO - 2023-07-26 12:13:08 --> Loader Class Initialized
INFO - 2023-07-26 12:13:08 --> Helper loaded: url_helper
INFO - 2023-07-26 12:13:08 --> Helper loaded: form_helper
INFO - 2023-07-26 12:13:08 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:13:08 --> Controller Class Initialized
DEBUG - 2023-07-26 12:13:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:13:08 --> Database Driver Class Initialized
INFO - 2023-07-26 12:13:08 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:13:08 --> Model "Student_model" initialized
INFO - 2023-07-26 12:13:08 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:13:08 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:13:08 --> Final output sent to browser
DEBUG - 2023-07-26 12:13:08 --> Total execution time: 0.0488
INFO - 2023-07-26 12:13:10 --> Config Class Initialized
INFO - 2023-07-26 12:13:10 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:13:10 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:13:10 --> Utf8 Class Initialized
INFO - 2023-07-26 12:13:10 --> URI Class Initialized
INFO - 2023-07-26 12:13:10 --> Router Class Initialized
INFO - 2023-07-26 12:13:10 --> Output Class Initialized
INFO - 2023-07-26 12:13:10 --> Security Class Initialized
DEBUG - 2023-07-26 12:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:13:10 --> Input Class Initialized
INFO - 2023-07-26 12:13:10 --> Language Class Initialized
INFO - 2023-07-26 12:13:10 --> Loader Class Initialized
INFO - 2023-07-26 12:13:10 --> Helper loaded: url_helper
INFO - 2023-07-26 12:13:10 --> Helper loaded: form_helper
INFO - 2023-07-26 12:13:10 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:13:10 --> Controller Class Initialized
DEBUG - 2023-07-26 12:13:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:13:10 --> Database Driver Class Initialized
INFO - 2023-07-26 12:13:10 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:13:10 --> Model "Student_model" initialized
INFO - 2023-07-26 12:13:10 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:13:10 --> Config Class Initialized
INFO - 2023-07-26 12:13:10 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:13:10 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:13:10 --> Utf8 Class Initialized
INFO - 2023-07-26 12:13:10 --> URI Class Initialized
INFO - 2023-07-26 12:13:10 --> Router Class Initialized
INFO - 2023-07-26 12:13:10 --> Output Class Initialized
INFO - 2023-07-26 12:13:10 --> Security Class Initialized
DEBUG - 2023-07-26 12:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:13:10 --> Input Class Initialized
INFO - 2023-07-26 12:13:10 --> Language Class Initialized
INFO - 2023-07-26 12:13:10 --> Loader Class Initialized
INFO - 2023-07-26 12:13:10 --> Helper loaded: url_helper
INFO - 2023-07-26 12:13:10 --> Helper loaded: form_helper
INFO - 2023-07-26 12:13:10 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:13:10 --> Controller Class Initialized
DEBUG - 2023-07-26 12:13:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:13:10 --> Database Driver Class Initialized
INFO - 2023-07-26 12:13:10 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:13:10 --> Model "Student_model" initialized
INFO - 2023-07-26 12:13:10 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:13:10 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:13:10 --> Final output sent to browser
DEBUG - 2023-07-26 12:13:10 --> Total execution time: 0.0596
INFO - 2023-07-26 12:13:13 --> Config Class Initialized
INFO - 2023-07-26 12:13:13 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:13:13 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:13:13 --> Utf8 Class Initialized
INFO - 2023-07-26 12:13:13 --> URI Class Initialized
INFO - 2023-07-26 12:13:13 --> Router Class Initialized
INFO - 2023-07-26 12:13:13 --> Output Class Initialized
INFO - 2023-07-26 12:13:13 --> Security Class Initialized
DEBUG - 2023-07-26 12:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:13:13 --> Input Class Initialized
INFO - 2023-07-26 12:13:13 --> Language Class Initialized
INFO - 2023-07-26 12:13:13 --> Loader Class Initialized
INFO - 2023-07-26 12:13:13 --> Helper loaded: url_helper
INFO - 2023-07-26 12:13:13 --> Helper loaded: form_helper
INFO - 2023-07-26 12:13:13 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:13:13 --> Controller Class Initialized
DEBUG - 2023-07-26 12:13:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:13:13 --> Database Driver Class Initialized
INFO - 2023-07-26 12:13:13 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:13:13 --> Model "Student_model" initialized
INFO - 2023-07-26 12:13:13 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:13:13 --> Config Class Initialized
INFO - 2023-07-26 12:13:13 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:13:13 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:13:13 --> Utf8 Class Initialized
INFO - 2023-07-26 12:13:13 --> URI Class Initialized
INFO - 2023-07-26 12:13:13 --> Router Class Initialized
INFO - 2023-07-26 12:13:13 --> Output Class Initialized
INFO - 2023-07-26 12:13:13 --> Security Class Initialized
DEBUG - 2023-07-26 12:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:13:13 --> Input Class Initialized
INFO - 2023-07-26 12:13:13 --> Language Class Initialized
INFO - 2023-07-26 12:13:13 --> Loader Class Initialized
INFO - 2023-07-26 12:13:13 --> Helper loaded: url_helper
INFO - 2023-07-26 12:13:13 --> Helper loaded: form_helper
INFO - 2023-07-26 12:13:13 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:13:13 --> Controller Class Initialized
DEBUG - 2023-07-26 12:13:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:13:13 --> Database Driver Class Initialized
INFO - 2023-07-26 12:13:13 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:13:13 --> Model "Student_model" initialized
INFO - 2023-07-26 12:13:13 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:13:13 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:13:13 --> Final output sent to browser
DEBUG - 2023-07-26 12:13:13 --> Total execution time: 0.0445
INFO - 2023-07-26 12:14:01 --> Config Class Initialized
INFO - 2023-07-26 12:14:01 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:14:01 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:14:01 --> Utf8 Class Initialized
INFO - 2023-07-26 12:14:01 --> URI Class Initialized
INFO - 2023-07-26 12:14:01 --> Router Class Initialized
INFO - 2023-07-26 12:14:01 --> Output Class Initialized
INFO - 2023-07-26 12:14:01 --> Security Class Initialized
DEBUG - 2023-07-26 12:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:14:01 --> Input Class Initialized
INFO - 2023-07-26 12:14:01 --> Language Class Initialized
INFO - 2023-07-26 12:14:01 --> Loader Class Initialized
INFO - 2023-07-26 12:14:01 --> Helper loaded: url_helper
INFO - 2023-07-26 12:14:01 --> Helper loaded: form_helper
INFO - 2023-07-26 12:14:01 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:14:01 --> Controller Class Initialized
DEBUG - 2023-07-26 12:14:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:14:01 --> Database Driver Class Initialized
INFO - 2023-07-26 12:14:01 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:14:01 --> Model "Student_model" initialized
INFO - 2023-07-26 12:14:01 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:14:01 --> Config Class Initialized
INFO - 2023-07-26 12:14:01 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:14:01 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:14:01 --> Utf8 Class Initialized
INFO - 2023-07-26 12:14:01 --> URI Class Initialized
INFO - 2023-07-26 12:14:01 --> Router Class Initialized
INFO - 2023-07-26 12:14:01 --> Output Class Initialized
INFO - 2023-07-26 12:14:01 --> Security Class Initialized
DEBUG - 2023-07-26 12:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:14:01 --> Input Class Initialized
INFO - 2023-07-26 12:14:01 --> Language Class Initialized
INFO - 2023-07-26 12:14:01 --> Loader Class Initialized
INFO - 2023-07-26 12:14:01 --> Helper loaded: url_helper
INFO - 2023-07-26 12:14:01 --> Helper loaded: form_helper
INFO - 2023-07-26 12:14:01 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:14:01 --> Controller Class Initialized
DEBUG - 2023-07-26 12:14:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:14:01 --> Database Driver Class Initialized
INFO - 2023-07-26 12:14:01 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:14:01 --> Model "Student_model" initialized
INFO - 2023-07-26 12:14:01 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:14:01 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:14:01 --> Final output sent to browser
DEBUG - 2023-07-26 12:14:01 --> Total execution time: 0.0326
INFO - 2023-07-26 12:14:06 --> Config Class Initialized
INFO - 2023-07-26 12:14:06 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:14:06 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:14:06 --> Utf8 Class Initialized
INFO - 2023-07-26 12:14:06 --> URI Class Initialized
INFO - 2023-07-26 12:14:06 --> Router Class Initialized
INFO - 2023-07-26 12:14:06 --> Output Class Initialized
INFO - 2023-07-26 12:14:06 --> Security Class Initialized
DEBUG - 2023-07-26 12:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:14:06 --> Input Class Initialized
INFO - 2023-07-26 12:14:06 --> Language Class Initialized
INFO - 2023-07-26 12:14:06 --> Loader Class Initialized
INFO - 2023-07-26 12:14:06 --> Helper loaded: url_helper
INFO - 2023-07-26 12:14:06 --> Helper loaded: form_helper
INFO - 2023-07-26 12:14:06 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:14:06 --> Controller Class Initialized
DEBUG - 2023-07-26 12:14:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:14:06 --> Database Driver Class Initialized
INFO - 2023-07-26 12:14:06 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:14:06 --> Model "Student_model" initialized
INFO - 2023-07-26 12:14:06 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:14:06 --> Config Class Initialized
INFO - 2023-07-26 12:14:06 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:14:06 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:14:06 --> Utf8 Class Initialized
INFO - 2023-07-26 12:14:06 --> URI Class Initialized
INFO - 2023-07-26 12:14:06 --> Router Class Initialized
INFO - 2023-07-26 12:14:06 --> Output Class Initialized
INFO - 2023-07-26 12:14:06 --> Security Class Initialized
DEBUG - 2023-07-26 12:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:14:06 --> Input Class Initialized
INFO - 2023-07-26 12:14:06 --> Language Class Initialized
INFO - 2023-07-26 12:14:06 --> Loader Class Initialized
INFO - 2023-07-26 12:14:06 --> Helper loaded: url_helper
INFO - 2023-07-26 12:14:06 --> Helper loaded: form_helper
INFO - 2023-07-26 12:14:06 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:14:06 --> Controller Class Initialized
DEBUG - 2023-07-26 12:14:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:14:06 --> Database Driver Class Initialized
INFO - 2023-07-26 12:14:06 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:14:06 --> Model "Student_model" initialized
INFO - 2023-07-26 12:14:06 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:14:06 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:14:06 --> Final output sent to browser
DEBUG - 2023-07-26 12:14:06 --> Total execution time: 0.0587
INFO - 2023-07-26 12:14:08 --> Config Class Initialized
INFO - 2023-07-26 12:14:08 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:14:08 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:14:08 --> Utf8 Class Initialized
INFO - 2023-07-26 12:14:08 --> URI Class Initialized
INFO - 2023-07-26 12:14:08 --> Router Class Initialized
INFO - 2023-07-26 12:14:08 --> Output Class Initialized
INFO - 2023-07-26 12:14:08 --> Security Class Initialized
DEBUG - 2023-07-26 12:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:14:08 --> Input Class Initialized
INFO - 2023-07-26 12:14:08 --> Language Class Initialized
INFO - 2023-07-26 12:14:08 --> Loader Class Initialized
INFO - 2023-07-26 12:14:08 --> Helper loaded: url_helper
INFO - 2023-07-26 12:14:08 --> Helper loaded: form_helper
INFO - 2023-07-26 12:14:08 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:14:08 --> Controller Class Initialized
DEBUG - 2023-07-26 12:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:14:08 --> Database Driver Class Initialized
INFO - 2023-07-26 12:14:08 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:14:08 --> Model "Student_model" initialized
INFO - 2023-07-26 12:14:08 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:14:08 --> Config Class Initialized
INFO - 2023-07-26 12:14:08 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:14:08 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:14:08 --> Utf8 Class Initialized
INFO - 2023-07-26 12:14:08 --> URI Class Initialized
INFO - 2023-07-26 12:14:08 --> Router Class Initialized
INFO - 2023-07-26 12:14:08 --> Output Class Initialized
INFO - 2023-07-26 12:14:08 --> Security Class Initialized
DEBUG - 2023-07-26 12:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:14:08 --> Input Class Initialized
INFO - 2023-07-26 12:14:08 --> Language Class Initialized
INFO - 2023-07-26 12:14:08 --> Loader Class Initialized
INFO - 2023-07-26 12:14:08 --> Helper loaded: url_helper
INFO - 2023-07-26 12:14:08 --> Helper loaded: form_helper
INFO - 2023-07-26 12:14:08 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:14:08 --> Controller Class Initialized
DEBUG - 2023-07-26 12:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:14:08 --> Database Driver Class Initialized
INFO - 2023-07-26 12:14:08 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:14:08 --> Model "Student_model" initialized
INFO - 2023-07-26 12:14:08 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:14:08 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:14:08 --> Final output sent to browser
DEBUG - 2023-07-26 12:14:08 --> Total execution time: 0.0576
INFO - 2023-07-26 12:14:11 --> Config Class Initialized
INFO - 2023-07-26 12:14:11 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:14:11 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:14:11 --> Utf8 Class Initialized
INFO - 2023-07-26 12:14:11 --> URI Class Initialized
INFO - 2023-07-26 12:14:11 --> Router Class Initialized
INFO - 2023-07-26 12:14:11 --> Output Class Initialized
INFO - 2023-07-26 12:14:11 --> Security Class Initialized
DEBUG - 2023-07-26 12:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:14:11 --> Input Class Initialized
INFO - 2023-07-26 12:14:11 --> Language Class Initialized
INFO - 2023-07-26 12:14:11 --> Loader Class Initialized
INFO - 2023-07-26 12:14:11 --> Helper loaded: url_helper
INFO - 2023-07-26 12:14:11 --> Helper loaded: form_helper
INFO - 2023-07-26 12:14:11 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:14:11 --> Controller Class Initialized
DEBUG - 2023-07-26 12:14:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:14:11 --> Database Driver Class Initialized
INFO - 2023-07-26 12:14:11 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:14:11 --> Model "Student_model" initialized
INFO - 2023-07-26 12:14:11 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:14:11 --> Config Class Initialized
INFO - 2023-07-26 12:14:11 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:14:11 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:14:11 --> Utf8 Class Initialized
INFO - 2023-07-26 12:14:11 --> URI Class Initialized
INFO - 2023-07-26 12:14:11 --> Router Class Initialized
INFO - 2023-07-26 12:14:11 --> Output Class Initialized
INFO - 2023-07-26 12:14:11 --> Security Class Initialized
DEBUG - 2023-07-26 12:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:14:11 --> Input Class Initialized
INFO - 2023-07-26 12:14:11 --> Language Class Initialized
INFO - 2023-07-26 12:14:11 --> Loader Class Initialized
INFO - 2023-07-26 12:14:11 --> Helper loaded: url_helper
INFO - 2023-07-26 12:14:11 --> Helper loaded: form_helper
INFO - 2023-07-26 12:14:11 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:14:11 --> Controller Class Initialized
DEBUG - 2023-07-26 12:14:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:14:11 --> Database Driver Class Initialized
INFO - 2023-07-26 12:14:11 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:14:11 --> Model "Student_model" initialized
INFO - 2023-07-26 12:14:11 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:14:11 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:14:11 --> Final output sent to browser
DEBUG - 2023-07-26 12:14:11 --> Total execution time: 0.0510
INFO - 2023-07-26 12:14:13 --> Config Class Initialized
INFO - 2023-07-26 12:14:13 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:14:13 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:14:13 --> Utf8 Class Initialized
INFO - 2023-07-26 12:14:13 --> URI Class Initialized
INFO - 2023-07-26 12:14:13 --> Router Class Initialized
INFO - 2023-07-26 12:14:13 --> Output Class Initialized
INFO - 2023-07-26 12:14:13 --> Security Class Initialized
DEBUG - 2023-07-26 12:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:14:13 --> Input Class Initialized
INFO - 2023-07-26 12:14:13 --> Language Class Initialized
INFO - 2023-07-26 12:14:13 --> Loader Class Initialized
INFO - 2023-07-26 12:14:13 --> Helper loaded: url_helper
INFO - 2023-07-26 12:14:13 --> Helper loaded: form_helper
INFO - 2023-07-26 12:14:13 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:14:13 --> Controller Class Initialized
DEBUG - 2023-07-26 12:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:14:13 --> Database Driver Class Initialized
INFO - 2023-07-26 12:14:13 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:14:13 --> Model "Student_model" initialized
INFO - 2023-07-26 12:14:13 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:14:13 --> Config Class Initialized
INFO - 2023-07-26 12:14:13 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:14:13 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:14:13 --> Utf8 Class Initialized
INFO - 2023-07-26 12:14:13 --> URI Class Initialized
INFO - 2023-07-26 12:14:13 --> Router Class Initialized
INFO - 2023-07-26 12:14:13 --> Output Class Initialized
INFO - 2023-07-26 12:14:13 --> Security Class Initialized
DEBUG - 2023-07-26 12:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:14:13 --> Input Class Initialized
INFO - 2023-07-26 12:14:13 --> Language Class Initialized
INFO - 2023-07-26 12:14:13 --> Loader Class Initialized
INFO - 2023-07-26 12:14:13 --> Helper loaded: url_helper
INFO - 2023-07-26 12:14:13 --> Helper loaded: form_helper
INFO - 2023-07-26 12:14:13 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:14:13 --> Controller Class Initialized
DEBUG - 2023-07-26 12:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:14:13 --> Database Driver Class Initialized
INFO - 2023-07-26 12:14:13 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:14:13 --> Model "Student_model" initialized
INFO - 2023-07-26 12:14:13 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:14:13 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:14:13 --> Final output sent to browser
DEBUG - 2023-07-26 12:14:13 --> Total execution time: 0.0434
INFO - 2023-07-26 12:18:21 --> Config Class Initialized
INFO - 2023-07-26 12:18:21 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:18:21 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:18:21 --> Utf8 Class Initialized
INFO - 2023-07-26 12:18:21 --> URI Class Initialized
INFO - 2023-07-26 12:18:21 --> Router Class Initialized
INFO - 2023-07-26 12:18:21 --> Output Class Initialized
INFO - 2023-07-26 12:18:21 --> Security Class Initialized
DEBUG - 2023-07-26 12:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:18:21 --> Input Class Initialized
INFO - 2023-07-26 12:18:21 --> Language Class Initialized
INFO - 2023-07-26 12:18:21 --> Loader Class Initialized
INFO - 2023-07-26 12:18:21 --> Helper loaded: url_helper
INFO - 2023-07-26 12:18:21 --> Helper loaded: form_helper
INFO - 2023-07-26 12:18:21 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:18:21 --> Controller Class Initialized
DEBUG - 2023-07-26 12:18:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:18:21 --> Database Driver Class Initialized
INFO - 2023-07-26 12:18:21 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:18:21 --> Model "Student_model" initialized
INFO - 2023-07-26 12:18:21 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:18:21 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:18:21 --> Final output sent to browser
DEBUG - 2023-07-26 12:18:21 --> Total execution time: 0.0390
INFO - 2023-07-26 12:18:34 --> Config Class Initialized
INFO - 2023-07-26 12:18:34 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:18:34 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:18:34 --> Utf8 Class Initialized
INFO - 2023-07-26 12:18:34 --> URI Class Initialized
INFO - 2023-07-26 12:18:34 --> Router Class Initialized
INFO - 2023-07-26 12:18:34 --> Output Class Initialized
INFO - 2023-07-26 12:18:34 --> Security Class Initialized
DEBUG - 2023-07-26 12:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:18:34 --> Input Class Initialized
INFO - 2023-07-26 12:18:34 --> Language Class Initialized
ERROR - 2023-07-26 12:18:34 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:18:35 --> Config Class Initialized
INFO - 2023-07-26 12:18:35 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:18:35 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:18:35 --> Utf8 Class Initialized
INFO - 2023-07-26 12:18:35 --> URI Class Initialized
INFO - 2023-07-26 12:18:35 --> Router Class Initialized
INFO - 2023-07-26 12:18:35 --> Output Class Initialized
INFO - 2023-07-26 12:18:35 --> Security Class Initialized
DEBUG - 2023-07-26 12:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:18:35 --> Input Class Initialized
INFO - 2023-07-26 12:18:35 --> Language Class Initialized
INFO - 2023-07-26 12:18:35 --> Loader Class Initialized
INFO - 2023-07-26 12:18:35 --> Helper loaded: url_helper
INFO - 2023-07-26 12:18:35 --> Helper loaded: form_helper
INFO - 2023-07-26 12:18:35 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:18:35 --> Controller Class Initialized
DEBUG - 2023-07-26 12:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:18:35 --> Database Driver Class Initialized
INFO - 2023-07-26 12:18:35 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:18:35 --> Model "Student_model" initialized
INFO - 2023-07-26 12:18:35 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:18:35 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:18:35 --> Final output sent to browser
DEBUG - 2023-07-26 12:18:35 --> Total execution time: 0.0423
INFO - 2023-07-26 12:21:24 --> Config Class Initialized
INFO - 2023-07-26 12:21:24 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:21:24 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:21:24 --> Utf8 Class Initialized
INFO - 2023-07-26 12:21:24 --> URI Class Initialized
INFO - 2023-07-26 12:21:24 --> Router Class Initialized
INFO - 2023-07-26 12:21:24 --> Output Class Initialized
INFO - 2023-07-26 12:21:24 --> Security Class Initialized
DEBUG - 2023-07-26 12:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:21:24 --> Input Class Initialized
INFO - 2023-07-26 12:21:24 --> Language Class Initialized
INFO - 2023-07-26 12:21:24 --> Loader Class Initialized
INFO - 2023-07-26 12:21:24 --> Helper loaded: url_helper
INFO - 2023-07-26 12:21:24 --> Helper loaded: form_helper
INFO - 2023-07-26 12:21:24 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:21:24 --> Controller Class Initialized
DEBUG - 2023-07-26 12:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:21:24 --> Database Driver Class Initialized
INFO - 2023-07-26 12:21:24 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:21:24 --> Model "Student_model" initialized
INFO - 2023-07-26 12:21:24 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:21:24 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:21:24 --> Final output sent to browser
DEBUG - 2023-07-26 12:21:24 --> Total execution time: 0.0567
INFO - 2023-07-26 12:21:47 --> Config Class Initialized
INFO - 2023-07-26 12:21:47 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:21:47 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:21:47 --> Utf8 Class Initialized
INFO - 2023-07-26 12:21:47 --> URI Class Initialized
INFO - 2023-07-26 12:21:47 --> Router Class Initialized
INFO - 2023-07-26 12:21:47 --> Output Class Initialized
INFO - 2023-07-26 12:21:47 --> Security Class Initialized
DEBUG - 2023-07-26 12:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:21:47 --> Input Class Initialized
INFO - 2023-07-26 12:21:47 --> Language Class Initialized
INFO - 2023-07-26 12:21:47 --> Loader Class Initialized
INFO - 2023-07-26 12:21:47 --> Helper loaded: url_helper
INFO - 2023-07-26 12:21:47 --> Helper loaded: form_helper
INFO - 2023-07-26 12:21:47 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:21:47 --> Controller Class Initialized
DEBUG - 2023-07-26 12:21:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:21:47 --> Database Driver Class Initialized
INFO - 2023-07-26 12:21:47 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:21:47 --> Model "Student_model" initialized
INFO - 2023-07-26 12:21:47 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:21:47 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:21:47 --> Final output sent to browser
DEBUG - 2023-07-26 12:21:47 --> Total execution time: 0.0391
INFO - 2023-07-26 12:21:50 --> Config Class Initialized
INFO - 2023-07-26 12:21:50 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:21:50 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:21:50 --> Utf8 Class Initialized
INFO - 2023-07-26 12:21:50 --> URI Class Initialized
INFO - 2023-07-26 12:21:50 --> Router Class Initialized
INFO - 2023-07-26 12:21:50 --> Output Class Initialized
INFO - 2023-07-26 12:21:50 --> Security Class Initialized
DEBUG - 2023-07-26 12:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:21:50 --> Input Class Initialized
INFO - 2023-07-26 12:21:50 --> Language Class Initialized
ERROR - 2023-07-26 12:21:50 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:21:51 --> Config Class Initialized
INFO - 2023-07-26 12:21:51 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:21:51 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:21:51 --> Utf8 Class Initialized
INFO - 2023-07-26 12:21:51 --> URI Class Initialized
INFO - 2023-07-26 12:21:51 --> Router Class Initialized
INFO - 2023-07-26 12:21:51 --> Output Class Initialized
INFO - 2023-07-26 12:21:51 --> Security Class Initialized
DEBUG - 2023-07-26 12:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:21:51 --> Input Class Initialized
INFO - 2023-07-26 12:21:51 --> Language Class Initialized
INFO - 2023-07-26 12:21:51 --> Loader Class Initialized
INFO - 2023-07-26 12:21:51 --> Helper loaded: url_helper
INFO - 2023-07-26 12:21:51 --> Helper loaded: form_helper
INFO - 2023-07-26 12:21:51 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:21:51 --> Controller Class Initialized
DEBUG - 2023-07-26 12:21:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:21:51 --> Database Driver Class Initialized
INFO - 2023-07-26 12:21:51 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:21:51 --> Model "Student_model" initialized
INFO - 2023-07-26 12:21:51 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:21:51 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:21:51 --> Final output sent to browser
DEBUG - 2023-07-26 12:21:51 --> Total execution time: 0.0430
INFO - 2023-07-26 12:21:53 --> Config Class Initialized
INFO - 2023-07-26 12:21:53 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:21:53 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:21:53 --> Utf8 Class Initialized
INFO - 2023-07-26 12:21:53 --> URI Class Initialized
INFO - 2023-07-26 12:21:53 --> Router Class Initialized
INFO - 2023-07-26 12:21:53 --> Output Class Initialized
INFO - 2023-07-26 12:21:53 --> Security Class Initialized
DEBUG - 2023-07-26 12:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:21:53 --> Input Class Initialized
INFO - 2023-07-26 12:21:53 --> Language Class Initialized
ERROR - 2023-07-26 12:21:53 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:23:23 --> Config Class Initialized
INFO - 2023-07-26 12:23:23 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:23:23 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:23:23 --> Utf8 Class Initialized
INFO - 2023-07-26 12:23:23 --> URI Class Initialized
INFO - 2023-07-26 12:23:23 --> Router Class Initialized
INFO - 2023-07-26 12:23:23 --> Output Class Initialized
INFO - 2023-07-26 12:23:23 --> Security Class Initialized
DEBUG - 2023-07-26 12:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:23:23 --> Input Class Initialized
INFO - 2023-07-26 12:23:23 --> Language Class Initialized
INFO - 2023-07-26 12:23:23 --> Loader Class Initialized
INFO - 2023-07-26 12:23:23 --> Helper loaded: url_helper
INFO - 2023-07-26 12:23:23 --> Helper loaded: form_helper
INFO - 2023-07-26 12:23:23 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:23:23 --> Controller Class Initialized
DEBUG - 2023-07-26 12:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:23:23 --> Database Driver Class Initialized
INFO - 2023-07-26 12:23:23 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:23:23 --> Model "Student_model" initialized
INFO - 2023-07-26 12:23:23 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:23:23 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:23:23 --> Final output sent to browser
DEBUG - 2023-07-26 12:23:23 --> Total execution time: 0.0495
INFO - 2023-07-26 12:23:25 --> Config Class Initialized
INFO - 2023-07-26 12:23:25 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:23:25 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:23:25 --> Utf8 Class Initialized
INFO - 2023-07-26 12:23:25 --> URI Class Initialized
INFO - 2023-07-26 12:23:25 --> Router Class Initialized
INFO - 2023-07-26 12:23:25 --> Output Class Initialized
INFO - 2023-07-26 12:23:25 --> Security Class Initialized
DEBUG - 2023-07-26 12:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:23:25 --> Input Class Initialized
INFO - 2023-07-26 12:23:25 --> Language Class Initialized
ERROR - 2023-07-26 12:23:25 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:23:26 --> Config Class Initialized
INFO - 2023-07-26 12:23:26 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:23:26 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:23:26 --> Utf8 Class Initialized
INFO - 2023-07-26 12:23:26 --> URI Class Initialized
INFO - 2023-07-26 12:23:26 --> Router Class Initialized
INFO - 2023-07-26 12:23:26 --> Output Class Initialized
INFO - 2023-07-26 12:23:26 --> Security Class Initialized
DEBUG - 2023-07-26 12:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:23:26 --> Input Class Initialized
INFO - 2023-07-26 12:23:26 --> Language Class Initialized
INFO - 2023-07-26 12:23:26 --> Loader Class Initialized
INFO - 2023-07-26 12:23:26 --> Helper loaded: url_helper
INFO - 2023-07-26 12:23:26 --> Helper loaded: form_helper
INFO - 2023-07-26 12:23:26 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:23:26 --> Controller Class Initialized
DEBUG - 2023-07-26 12:23:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:23:26 --> Database Driver Class Initialized
INFO - 2023-07-26 12:23:26 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:23:26 --> Model "Student_model" initialized
INFO - 2023-07-26 12:23:26 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:23:26 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:23:26 --> Final output sent to browser
DEBUG - 2023-07-26 12:23:26 --> Total execution time: 0.0449
INFO - 2023-07-26 12:23:28 --> Config Class Initialized
INFO - 2023-07-26 12:23:28 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:23:28 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:23:28 --> Utf8 Class Initialized
INFO - 2023-07-26 12:23:28 --> URI Class Initialized
INFO - 2023-07-26 12:23:28 --> Router Class Initialized
INFO - 2023-07-26 12:23:28 --> Output Class Initialized
INFO - 2023-07-26 12:23:28 --> Security Class Initialized
DEBUG - 2023-07-26 12:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:23:28 --> Input Class Initialized
INFO - 2023-07-26 12:23:28 --> Language Class Initialized
INFO - 2023-07-26 12:23:28 --> Loader Class Initialized
INFO - 2023-07-26 12:23:28 --> Helper loaded: url_helper
INFO - 2023-07-26 12:23:28 --> Helper loaded: form_helper
INFO - 2023-07-26 12:23:28 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:23:28 --> Controller Class Initialized
DEBUG - 2023-07-26 12:23:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:23:28 --> Database Driver Class Initialized
INFO - 2023-07-26 12:23:28 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:23:28 --> Model "Student_model" initialized
INFO - 2023-07-26 12:23:28 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:23:28 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:23:28 --> Final output sent to browser
DEBUG - 2023-07-26 12:23:28 --> Total execution time: 0.0441
INFO - 2023-07-26 12:23:30 --> Config Class Initialized
INFO - 2023-07-26 12:23:30 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:23:30 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:23:30 --> Utf8 Class Initialized
INFO - 2023-07-26 12:23:30 --> URI Class Initialized
INFO - 2023-07-26 12:23:30 --> Router Class Initialized
INFO - 2023-07-26 12:23:30 --> Output Class Initialized
INFO - 2023-07-26 12:23:30 --> Security Class Initialized
DEBUG - 2023-07-26 12:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:23:30 --> Input Class Initialized
INFO - 2023-07-26 12:23:30 --> Language Class Initialized
ERROR - 2023-07-26 12:23:30 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:24:14 --> Config Class Initialized
INFO - 2023-07-26 12:24:14 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:24:14 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:24:14 --> Utf8 Class Initialized
INFO - 2023-07-26 12:24:14 --> URI Class Initialized
INFO - 2023-07-26 12:24:14 --> Router Class Initialized
INFO - 2023-07-26 12:24:14 --> Output Class Initialized
INFO - 2023-07-26 12:24:14 --> Security Class Initialized
DEBUG - 2023-07-26 12:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:24:14 --> Input Class Initialized
INFO - 2023-07-26 12:24:14 --> Language Class Initialized
ERROR - 2023-07-26 12:24:14 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:24:14 --> Config Class Initialized
INFO - 2023-07-26 12:24:14 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:24:14 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:24:14 --> Utf8 Class Initialized
INFO - 2023-07-26 12:24:14 --> URI Class Initialized
INFO - 2023-07-26 12:24:14 --> Router Class Initialized
INFO - 2023-07-26 12:24:14 --> Output Class Initialized
INFO - 2023-07-26 12:24:14 --> Security Class Initialized
DEBUG - 2023-07-26 12:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:24:14 --> Input Class Initialized
INFO - 2023-07-26 12:24:14 --> Language Class Initialized
ERROR - 2023-07-26 12:24:15 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:24:15 --> Config Class Initialized
INFO - 2023-07-26 12:24:15 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:24:15 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:24:15 --> Utf8 Class Initialized
INFO - 2023-07-26 12:24:15 --> URI Class Initialized
INFO - 2023-07-26 12:24:15 --> Router Class Initialized
INFO - 2023-07-26 12:24:15 --> Output Class Initialized
INFO - 2023-07-26 12:24:15 --> Security Class Initialized
DEBUG - 2023-07-26 12:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:24:15 --> Input Class Initialized
INFO - 2023-07-26 12:24:15 --> Language Class Initialized
ERROR - 2023-07-26 12:24:15 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:24:15 --> Config Class Initialized
INFO - 2023-07-26 12:24:15 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:24:15 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:24:15 --> Utf8 Class Initialized
INFO - 2023-07-26 12:24:15 --> URI Class Initialized
INFO - 2023-07-26 12:24:15 --> Router Class Initialized
INFO - 2023-07-26 12:24:15 --> Output Class Initialized
INFO - 2023-07-26 12:24:15 --> Security Class Initialized
DEBUG - 2023-07-26 12:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:24:15 --> Input Class Initialized
INFO - 2023-07-26 12:24:15 --> Language Class Initialized
INFO - 2023-07-26 12:24:15 --> Loader Class Initialized
INFO - 2023-07-26 12:24:15 --> Helper loaded: url_helper
INFO - 2023-07-26 12:24:15 --> Helper loaded: form_helper
INFO - 2023-07-26 12:24:15 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:24:15 --> Controller Class Initialized
DEBUG - 2023-07-26 12:24:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:24:15 --> Database Driver Class Initialized
INFO - 2023-07-26 12:24:15 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:24:15 --> Model "Student_model" initialized
INFO - 2023-07-26 12:24:15 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:24:15 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:24:15 --> Final output sent to browser
DEBUG - 2023-07-26 12:24:15 --> Total execution time: 0.0435
INFO - 2023-07-26 12:24:17 --> Config Class Initialized
INFO - 2023-07-26 12:24:17 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:24:17 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:24:17 --> Utf8 Class Initialized
INFO - 2023-07-26 12:24:17 --> URI Class Initialized
INFO - 2023-07-26 12:24:17 --> Router Class Initialized
INFO - 2023-07-26 12:24:17 --> Output Class Initialized
INFO - 2023-07-26 12:24:17 --> Security Class Initialized
DEBUG - 2023-07-26 12:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:24:17 --> Input Class Initialized
INFO - 2023-07-26 12:24:17 --> Language Class Initialized
ERROR - 2023-07-26 12:24:17 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:24:18 --> Config Class Initialized
INFO - 2023-07-26 12:24:18 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:24:18 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:24:18 --> Utf8 Class Initialized
INFO - 2023-07-26 12:24:18 --> URI Class Initialized
INFO - 2023-07-26 12:24:18 --> Router Class Initialized
INFO - 2023-07-26 12:24:18 --> Output Class Initialized
INFO - 2023-07-26 12:24:18 --> Security Class Initialized
DEBUG - 2023-07-26 12:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:24:18 --> Input Class Initialized
INFO - 2023-07-26 12:24:18 --> Language Class Initialized
ERROR - 2023-07-26 12:24:18 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:24:35 --> Config Class Initialized
INFO - 2023-07-26 12:24:35 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:24:35 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:24:35 --> Utf8 Class Initialized
INFO - 2023-07-26 12:24:35 --> URI Class Initialized
INFO - 2023-07-26 12:24:35 --> Router Class Initialized
INFO - 2023-07-26 12:24:35 --> Output Class Initialized
INFO - 2023-07-26 12:24:35 --> Security Class Initialized
DEBUG - 2023-07-26 12:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:24:35 --> Input Class Initialized
INFO - 2023-07-26 12:24:35 --> Language Class Initialized
ERROR - 2023-07-26 12:24:35 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:24:36 --> Config Class Initialized
INFO - 2023-07-26 12:24:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:24:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:24:36 --> Utf8 Class Initialized
INFO - 2023-07-26 12:24:36 --> URI Class Initialized
INFO - 2023-07-26 12:24:36 --> Router Class Initialized
INFO - 2023-07-26 12:24:36 --> Output Class Initialized
INFO - 2023-07-26 12:24:36 --> Security Class Initialized
DEBUG - 2023-07-26 12:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:24:36 --> Input Class Initialized
INFO - 2023-07-26 12:24:36 --> Language Class Initialized
ERROR - 2023-07-26 12:24:36 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:24:36 --> Config Class Initialized
INFO - 2023-07-26 12:24:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:24:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:24:36 --> Utf8 Class Initialized
INFO - 2023-07-26 12:24:36 --> URI Class Initialized
INFO - 2023-07-26 12:24:36 --> Router Class Initialized
INFO - 2023-07-26 12:24:36 --> Output Class Initialized
INFO - 2023-07-26 12:24:36 --> Security Class Initialized
DEBUG - 2023-07-26 12:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:24:36 --> Input Class Initialized
INFO - 2023-07-26 12:24:36 --> Language Class Initialized
ERROR - 2023-07-26 12:24:36 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:24:36 --> Config Class Initialized
INFO - 2023-07-26 12:24:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:24:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:24:36 --> Utf8 Class Initialized
INFO - 2023-07-26 12:24:36 --> URI Class Initialized
INFO - 2023-07-26 12:24:36 --> Router Class Initialized
INFO - 2023-07-26 12:24:36 --> Output Class Initialized
INFO - 2023-07-26 12:24:36 --> Security Class Initialized
DEBUG - 2023-07-26 12:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:24:36 --> Input Class Initialized
INFO - 2023-07-26 12:24:36 --> Language Class Initialized
ERROR - 2023-07-26 12:24:36 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:24:36 --> Config Class Initialized
INFO - 2023-07-26 12:24:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:24:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:24:36 --> Utf8 Class Initialized
INFO - 2023-07-26 12:24:36 --> URI Class Initialized
INFO - 2023-07-26 12:24:36 --> Router Class Initialized
INFO - 2023-07-26 12:24:36 --> Output Class Initialized
INFO - 2023-07-26 12:24:36 --> Security Class Initialized
DEBUG - 2023-07-26 12:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:24:36 --> Input Class Initialized
INFO - 2023-07-26 12:24:36 --> Language Class Initialized
ERROR - 2023-07-26 12:24:36 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:24:36 --> Config Class Initialized
INFO - 2023-07-26 12:24:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:24:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:24:36 --> Utf8 Class Initialized
INFO - 2023-07-26 12:24:36 --> URI Class Initialized
INFO - 2023-07-26 12:24:36 --> Router Class Initialized
INFO - 2023-07-26 12:24:36 --> Output Class Initialized
INFO - 2023-07-26 12:24:36 --> Security Class Initialized
DEBUG - 2023-07-26 12:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:24:36 --> Input Class Initialized
INFO - 2023-07-26 12:24:36 --> Language Class Initialized
ERROR - 2023-07-26 12:24:36 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:24:36 --> Config Class Initialized
INFO - 2023-07-26 12:24:36 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:24:36 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:24:36 --> Utf8 Class Initialized
INFO - 2023-07-26 12:24:36 --> URI Class Initialized
INFO - 2023-07-26 12:24:36 --> Router Class Initialized
INFO - 2023-07-26 12:24:36 --> Output Class Initialized
INFO - 2023-07-26 12:24:36 --> Security Class Initialized
DEBUG - 2023-07-26 12:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:24:36 --> Input Class Initialized
INFO - 2023-07-26 12:24:36 --> Language Class Initialized
ERROR - 2023-07-26 12:24:36 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:24:37 --> Config Class Initialized
INFO - 2023-07-26 12:24:37 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:24:37 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:24:37 --> Utf8 Class Initialized
INFO - 2023-07-26 12:24:37 --> URI Class Initialized
INFO - 2023-07-26 12:24:37 --> Router Class Initialized
INFO - 2023-07-26 12:24:37 --> Output Class Initialized
INFO - 2023-07-26 12:24:37 --> Security Class Initialized
DEBUG - 2023-07-26 12:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:24:37 --> Input Class Initialized
INFO - 2023-07-26 12:24:37 --> Language Class Initialized
ERROR - 2023-07-26 12:24:37 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:24:37 --> Config Class Initialized
INFO - 2023-07-26 12:24:37 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:24:37 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:24:37 --> Utf8 Class Initialized
INFO - 2023-07-26 12:24:37 --> URI Class Initialized
INFO - 2023-07-26 12:24:37 --> Router Class Initialized
INFO - 2023-07-26 12:24:37 --> Output Class Initialized
INFO - 2023-07-26 12:24:37 --> Security Class Initialized
DEBUG - 2023-07-26 12:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:24:37 --> Input Class Initialized
INFO - 2023-07-26 12:24:37 --> Language Class Initialized
ERROR - 2023-07-26 12:24:37 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:24:37 --> Config Class Initialized
INFO - 2023-07-26 12:24:37 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:24:37 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:24:37 --> Utf8 Class Initialized
INFO - 2023-07-26 12:24:37 --> URI Class Initialized
INFO - 2023-07-26 12:24:37 --> Router Class Initialized
INFO - 2023-07-26 12:24:37 --> Output Class Initialized
INFO - 2023-07-26 12:24:37 --> Security Class Initialized
DEBUG - 2023-07-26 12:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:24:37 --> Input Class Initialized
INFO - 2023-07-26 12:24:37 --> Language Class Initialized
ERROR - 2023-07-26 12:24:37 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:24:37 --> Config Class Initialized
INFO - 2023-07-26 12:24:37 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:24:37 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:24:37 --> Utf8 Class Initialized
INFO - 2023-07-26 12:24:37 --> URI Class Initialized
INFO - 2023-07-26 12:24:37 --> Router Class Initialized
INFO - 2023-07-26 12:24:37 --> Output Class Initialized
INFO - 2023-07-26 12:24:37 --> Security Class Initialized
DEBUG - 2023-07-26 12:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:24:37 --> Input Class Initialized
INFO - 2023-07-26 12:24:37 --> Language Class Initialized
ERROR - 2023-07-26 12:24:37 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:24:38 --> Config Class Initialized
INFO - 2023-07-26 12:24:38 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:24:38 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:24:38 --> Utf8 Class Initialized
INFO - 2023-07-26 12:24:38 --> URI Class Initialized
INFO - 2023-07-26 12:24:38 --> Router Class Initialized
INFO - 2023-07-26 12:24:38 --> Output Class Initialized
INFO - 2023-07-26 12:24:38 --> Security Class Initialized
DEBUG - 2023-07-26 12:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:24:38 --> Input Class Initialized
INFO - 2023-07-26 12:24:38 --> Language Class Initialized
INFO - 2023-07-26 12:24:38 --> Loader Class Initialized
INFO - 2023-07-26 12:24:38 --> Helper loaded: url_helper
INFO - 2023-07-26 12:24:38 --> Helper loaded: form_helper
INFO - 2023-07-26 12:24:38 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:24:38 --> Controller Class Initialized
DEBUG - 2023-07-26 12:24:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:24:38 --> Database Driver Class Initialized
INFO - 2023-07-26 12:24:38 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:24:38 --> Model "Student_model" initialized
INFO - 2023-07-26 12:24:38 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:24:38 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:24:38 --> Final output sent to browser
DEBUG - 2023-07-26 12:24:38 --> Total execution time: 0.0450
INFO - 2023-07-26 12:26:45 --> Config Class Initialized
INFO - 2023-07-26 12:26:45 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:26:45 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:26:45 --> Utf8 Class Initialized
INFO - 2023-07-26 12:26:45 --> URI Class Initialized
INFO - 2023-07-26 12:26:45 --> Router Class Initialized
INFO - 2023-07-26 12:26:45 --> Output Class Initialized
INFO - 2023-07-26 12:26:45 --> Security Class Initialized
DEBUG - 2023-07-26 12:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:26:45 --> Input Class Initialized
INFO - 2023-07-26 12:26:45 --> Language Class Initialized
ERROR - 2023-07-26 12:26:45 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:27:51 --> Config Class Initialized
INFO - 2023-07-26 12:27:51 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:27:51 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:27:51 --> Utf8 Class Initialized
INFO - 2023-07-26 12:27:51 --> URI Class Initialized
INFO - 2023-07-26 12:27:51 --> Router Class Initialized
INFO - 2023-07-26 12:27:51 --> Output Class Initialized
INFO - 2023-07-26 12:27:51 --> Security Class Initialized
DEBUG - 2023-07-26 12:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:27:51 --> Input Class Initialized
INFO - 2023-07-26 12:27:51 --> Language Class Initialized
INFO - 2023-07-26 12:27:51 --> Loader Class Initialized
INFO - 2023-07-26 12:27:51 --> Helper loaded: url_helper
INFO - 2023-07-26 12:27:51 --> Helper loaded: form_helper
INFO - 2023-07-26 12:27:51 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:27:51 --> Controller Class Initialized
DEBUG - 2023-07-26 12:27:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:27:51 --> Database Driver Class Initialized
INFO - 2023-07-26 12:27:51 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:27:51 --> Model "Student_model" initialized
INFO - 2023-07-26 12:27:51 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:27:51 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:27:51 --> Final output sent to browser
DEBUG - 2023-07-26 12:27:51 --> Total execution time: 0.0498
INFO - 2023-07-26 12:27:53 --> Config Class Initialized
INFO - 2023-07-26 12:27:53 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:27:53 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:27:53 --> Utf8 Class Initialized
INFO - 2023-07-26 12:27:53 --> URI Class Initialized
INFO - 2023-07-26 12:27:53 --> Router Class Initialized
INFO - 2023-07-26 12:27:53 --> Output Class Initialized
INFO - 2023-07-26 12:27:53 --> Security Class Initialized
DEBUG - 2023-07-26 12:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:27:53 --> Input Class Initialized
INFO - 2023-07-26 12:27:53 --> Language Class Initialized
INFO - 2023-07-26 12:27:53 --> Loader Class Initialized
INFO - 2023-07-26 12:27:53 --> Helper loaded: url_helper
INFO - 2023-07-26 12:27:53 --> Helper loaded: form_helper
INFO - 2023-07-26 12:27:53 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:27:53 --> Controller Class Initialized
DEBUG - 2023-07-26 12:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:27:53 --> Database Driver Class Initialized
INFO - 2023-07-26 12:27:53 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:27:53 --> Model "Student_model" initialized
INFO - 2023-07-26 12:27:53 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:27:53 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:27:53 --> Final output sent to browser
DEBUG - 2023-07-26 12:27:53 --> Total execution time: 0.0375
INFO - 2023-07-26 12:27:54 --> Config Class Initialized
INFO - 2023-07-26 12:27:54 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:27:54 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:27:54 --> Utf8 Class Initialized
INFO - 2023-07-26 12:27:54 --> URI Class Initialized
INFO - 2023-07-26 12:27:54 --> Router Class Initialized
INFO - 2023-07-26 12:27:54 --> Output Class Initialized
INFO - 2023-07-26 12:27:54 --> Security Class Initialized
DEBUG - 2023-07-26 12:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:27:54 --> Input Class Initialized
INFO - 2023-07-26 12:27:54 --> Language Class Initialized
INFO - 2023-07-26 12:27:54 --> Loader Class Initialized
INFO - 2023-07-26 12:27:54 --> Helper loaded: url_helper
INFO - 2023-07-26 12:27:54 --> Helper loaded: form_helper
INFO - 2023-07-26 12:27:54 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:27:54 --> Controller Class Initialized
DEBUG - 2023-07-26 12:27:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:27:54 --> Database Driver Class Initialized
INFO - 2023-07-26 12:27:54 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:27:54 --> Model "Student_model" initialized
INFO - 2023-07-26 12:27:54 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:28:44 --> Config Class Initialized
INFO - 2023-07-26 12:28:44 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:28:44 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:28:44 --> Utf8 Class Initialized
INFO - 2023-07-26 12:28:44 --> URI Class Initialized
INFO - 2023-07-26 12:28:44 --> Router Class Initialized
INFO - 2023-07-26 12:28:44 --> Output Class Initialized
INFO - 2023-07-26 12:28:44 --> Security Class Initialized
DEBUG - 2023-07-26 12:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:28:44 --> Input Class Initialized
INFO - 2023-07-26 12:28:44 --> Language Class Initialized
INFO - 2023-07-26 12:28:44 --> Loader Class Initialized
INFO - 2023-07-26 12:28:44 --> Helper loaded: url_helper
INFO - 2023-07-26 12:28:44 --> Helper loaded: form_helper
INFO - 2023-07-26 12:28:44 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:28:44 --> Controller Class Initialized
DEBUG - 2023-07-26 12:28:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:28:44 --> Database Driver Class Initialized
INFO - 2023-07-26 12:28:44 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:28:44 --> Model "Student_model" initialized
INFO - 2023-07-26 12:28:44 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:28:44 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:28:44 --> Final output sent to browser
DEBUG - 2023-07-26 12:28:44 --> Total execution time: 0.0419
INFO - 2023-07-26 12:28:45 --> Config Class Initialized
INFO - 2023-07-26 12:28:45 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:28:45 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:28:45 --> Utf8 Class Initialized
INFO - 2023-07-26 12:28:45 --> URI Class Initialized
INFO - 2023-07-26 12:28:45 --> Router Class Initialized
INFO - 2023-07-26 12:28:45 --> Output Class Initialized
INFO - 2023-07-26 12:28:45 --> Security Class Initialized
DEBUG - 2023-07-26 12:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:28:45 --> Input Class Initialized
INFO - 2023-07-26 12:28:45 --> Language Class Initialized
INFO - 2023-07-26 12:28:45 --> Loader Class Initialized
INFO - 2023-07-26 12:28:45 --> Helper loaded: url_helper
INFO - 2023-07-26 12:28:45 --> Helper loaded: form_helper
INFO - 2023-07-26 12:28:45 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:28:45 --> Controller Class Initialized
DEBUG - 2023-07-26 12:28:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:28:45 --> Database Driver Class Initialized
INFO - 2023-07-26 12:28:45 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:28:45 --> Model "Student_model" initialized
INFO - 2023-07-26 12:28:45 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:28:45 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:28:45 --> Final output sent to browser
DEBUG - 2023-07-26 12:28:45 --> Total execution time: 0.0475
INFO - 2023-07-26 12:28:47 --> Config Class Initialized
INFO - 2023-07-26 12:28:47 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:28:47 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:28:47 --> Utf8 Class Initialized
INFO - 2023-07-26 12:28:47 --> URI Class Initialized
INFO - 2023-07-26 12:28:47 --> Router Class Initialized
INFO - 2023-07-26 12:28:47 --> Output Class Initialized
INFO - 2023-07-26 12:28:47 --> Security Class Initialized
DEBUG - 2023-07-26 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:28:47 --> Input Class Initialized
INFO - 2023-07-26 12:28:47 --> Language Class Initialized
ERROR - 2023-07-26 12:28:47 --> 404 Page Not Found: Admin/add_teacher
INFO - 2023-07-26 12:28:49 --> Config Class Initialized
INFO - 2023-07-26 12:28:49 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:28:49 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:28:49 --> Utf8 Class Initialized
INFO - 2023-07-26 12:28:49 --> URI Class Initialized
INFO - 2023-07-26 12:28:49 --> Router Class Initialized
INFO - 2023-07-26 12:28:49 --> Output Class Initialized
INFO - 2023-07-26 12:28:49 --> Security Class Initialized
DEBUG - 2023-07-26 12:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:28:49 --> Input Class Initialized
INFO - 2023-07-26 12:28:49 --> Language Class Initialized
INFO - 2023-07-26 12:28:49 --> Loader Class Initialized
INFO - 2023-07-26 12:28:49 --> Helper loaded: url_helper
INFO - 2023-07-26 12:28:49 --> Helper loaded: form_helper
INFO - 2023-07-26 12:28:49 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:28:49 --> Controller Class Initialized
DEBUG - 2023-07-26 12:28:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:28:49 --> Database Driver Class Initialized
INFO - 2023-07-26 12:28:49 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:28:49 --> Model "Student_model" initialized
INFO - 2023-07-26 12:28:49 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:28:49 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:28:49 --> Final output sent to browser
DEBUG - 2023-07-26 12:28:49 --> Total execution time: 0.0445
INFO - 2023-07-26 12:29:16 --> Config Class Initialized
INFO - 2023-07-26 12:29:16 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:29:16 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:29:16 --> Utf8 Class Initialized
INFO - 2023-07-26 12:29:16 --> URI Class Initialized
INFO - 2023-07-26 12:29:16 --> Router Class Initialized
INFO - 2023-07-26 12:29:16 --> Output Class Initialized
INFO - 2023-07-26 12:29:16 --> Security Class Initialized
DEBUG - 2023-07-26 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:29:16 --> Input Class Initialized
INFO - 2023-07-26 12:29:16 --> Language Class Initialized
INFO - 2023-07-26 12:29:16 --> Loader Class Initialized
INFO - 2023-07-26 12:29:16 --> Helper loaded: url_helper
INFO - 2023-07-26 12:29:16 --> Helper loaded: form_helper
INFO - 2023-07-26 12:29:16 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:29:16 --> Controller Class Initialized
DEBUG - 2023-07-26 12:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:29:16 --> Database Driver Class Initialized
INFO - 2023-07-26 12:29:16 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:29:16 --> Model "Student_model" initialized
INFO - 2023-07-26 12:29:16 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:29:16 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 12:29:16 --> Final output sent to browser
DEBUG - 2023-07-26 12:29:16 --> Total execution time: 0.0412
INFO - 2023-07-26 12:29:44 --> Config Class Initialized
INFO - 2023-07-26 12:29:44 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:29:44 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:29:44 --> Utf8 Class Initialized
INFO - 2023-07-26 12:29:44 --> URI Class Initialized
DEBUG - 2023-07-26 12:29:44 --> No URI present. Default controller set.
INFO - 2023-07-26 12:29:44 --> Router Class Initialized
INFO - 2023-07-26 12:29:44 --> Output Class Initialized
INFO - 2023-07-26 12:29:44 --> Security Class Initialized
DEBUG - 2023-07-26 12:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:29:44 --> Input Class Initialized
INFO - 2023-07-26 12:29:44 --> Language Class Initialized
INFO - 2023-07-26 12:29:44 --> Loader Class Initialized
INFO - 2023-07-26 12:29:44 --> Helper loaded: url_helper
INFO - 2023-07-26 12:29:44 --> Helper loaded: form_helper
INFO - 2023-07-26 12:29:44 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:29:44 --> Controller Class Initialized
INFO - 2023-07-26 12:29:44 --> Database Driver Class Initialized
INFO - 2023-07-26 12:29:44 --> Model "Student_model" initialized
DEBUG - 2023-07-26 12:29:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:29:44 --> File loaded: C:\xampp\htdocs\Project\application\views\register.php
INFO - 2023-07-26 12:29:44 --> Final output sent to browser
DEBUG - 2023-07-26 12:29:44 --> Total execution time: 0.0633
INFO - 2023-07-26 12:58:43 --> Config Class Initialized
INFO - 2023-07-26 12:58:43 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:58:43 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:58:43 --> Utf8 Class Initialized
INFO - 2023-07-26 12:58:43 --> URI Class Initialized
INFO - 2023-07-26 12:58:43 --> Router Class Initialized
INFO - 2023-07-26 12:58:43 --> Output Class Initialized
INFO - 2023-07-26 12:58:43 --> Security Class Initialized
DEBUG - 2023-07-26 12:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:58:43 --> Input Class Initialized
INFO - 2023-07-26 12:58:43 --> Language Class Initialized
INFO - 2023-07-26 12:58:43 --> Loader Class Initialized
INFO - 2023-07-26 12:58:43 --> Helper loaded: url_helper
INFO - 2023-07-26 12:58:43 --> Helper loaded: form_helper
INFO - 2023-07-26 12:58:43 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:58:43 --> Controller Class Initialized
INFO - 2023-07-26 12:58:43 --> Database Driver Class Initialized
INFO - 2023-07-26 12:58:43 --> Model "Auth_model" initialized
DEBUG - 2023-07-26 12:58:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 12:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:58:43 --> File loaded: C:\xampp\htdocs\Project\application\views\login.php
INFO - 2023-07-26 12:58:43 --> Final output sent to browser
DEBUG - 2023-07-26 12:58:43 --> Total execution time: 0.0725
INFO - 2023-07-26 12:59:01 --> Config Class Initialized
INFO - 2023-07-26 12:59:01 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:59:01 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:59:01 --> Utf8 Class Initialized
INFO - 2023-07-26 12:59:01 --> URI Class Initialized
INFO - 2023-07-26 12:59:01 --> Router Class Initialized
INFO - 2023-07-26 12:59:01 --> Output Class Initialized
INFO - 2023-07-26 12:59:01 --> Security Class Initialized
DEBUG - 2023-07-26 12:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:59:01 --> Input Class Initialized
INFO - 2023-07-26 12:59:01 --> Language Class Initialized
INFO - 2023-07-26 12:59:01 --> Loader Class Initialized
INFO - 2023-07-26 12:59:01 --> Helper loaded: url_helper
INFO - 2023-07-26 12:59:01 --> Helper loaded: form_helper
INFO - 2023-07-26 12:59:01 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:59:01 --> Controller Class Initialized
INFO - 2023-07-26 12:59:01 --> Database Driver Class Initialized
INFO - 2023-07-26 12:59:01 --> Model "Auth_model" initialized
DEBUG - 2023-07-26 12:59:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 12:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:59:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-07-26 12:59:01 --> Config Class Initialized
INFO - 2023-07-26 12:59:01 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:59:01 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:59:01 --> Utf8 Class Initialized
INFO - 2023-07-26 12:59:01 --> URI Class Initialized
INFO - 2023-07-26 12:59:01 --> Router Class Initialized
INFO - 2023-07-26 12:59:01 --> Output Class Initialized
INFO - 2023-07-26 12:59:01 --> Security Class Initialized
DEBUG - 2023-07-26 12:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:59:01 --> Input Class Initialized
INFO - 2023-07-26 12:59:01 --> Language Class Initialized
INFO - 2023-07-26 12:59:01 --> Loader Class Initialized
INFO - 2023-07-26 12:59:01 --> Helper loaded: url_helper
INFO - 2023-07-26 12:59:01 --> Helper loaded: form_helper
INFO - 2023-07-26 12:59:01 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:59:01 --> Controller Class Initialized
DEBUG - 2023-07-26 12:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:59:01 --> Database Driver Class Initialized
INFO - 2023-07-26 12:59:01 --> Model "User_model" initialized
INFO - 2023-07-26 12:59:01 --> Model "Student_model" initialized
INFO - 2023-07-26 12:59:01 --> File loaded: C:\xampp\htdocs\Project\application\views\dashboard.php
INFO - 2023-07-26 12:59:01 --> Final output sent to browser
DEBUG - 2023-07-26 12:59:01 --> Total execution time: 0.0999
INFO - 2023-07-26 12:59:43 --> Config Class Initialized
INFO - 2023-07-26 12:59:43 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:59:43 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:59:43 --> Utf8 Class Initialized
INFO - 2023-07-26 12:59:43 --> URI Class Initialized
INFO - 2023-07-26 12:59:43 --> Router Class Initialized
INFO - 2023-07-26 12:59:43 --> Output Class Initialized
INFO - 2023-07-26 12:59:43 --> Security Class Initialized
DEBUG - 2023-07-26 12:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:59:43 --> Input Class Initialized
INFO - 2023-07-26 12:59:43 --> Language Class Initialized
INFO - 2023-07-26 12:59:43 --> Loader Class Initialized
INFO - 2023-07-26 12:59:43 --> Helper loaded: url_helper
INFO - 2023-07-26 12:59:43 --> Helper loaded: form_helper
INFO - 2023-07-26 12:59:43 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:59:43 --> Controller Class Initialized
INFO - 2023-07-26 12:59:43 --> Database Driver Class Initialized
INFO - 2023-07-26 12:59:43 --> Model "Auth_model" initialized
DEBUG - 2023-07-26 12:59:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 12:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:59:43 --> File loaded: C:\xampp\htdocs\Project\application\views\login.php
INFO - 2023-07-26 12:59:43 --> Final output sent to browser
DEBUG - 2023-07-26 12:59:43 --> Total execution time: 0.0568
INFO - 2023-07-26 12:59:45 --> Config Class Initialized
INFO - 2023-07-26 12:59:45 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:59:45 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:59:45 --> Utf8 Class Initialized
INFO - 2023-07-26 12:59:45 --> URI Class Initialized
INFO - 2023-07-26 12:59:45 --> Router Class Initialized
INFO - 2023-07-26 12:59:45 --> Output Class Initialized
INFO - 2023-07-26 12:59:45 --> Security Class Initialized
DEBUG - 2023-07-26 12:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:59:45 --> Input Class Initialized
INFO - 2023-07-26 12:59:45 --> Language Class Initialized
INFO - 2023-07-26 12:59:45 --> Loader Class Initialized
INFO - 2023-07-26 12:59:45 --> Helper loaded: url_helper
INFO - 2023-07-26 12:59:45 --> Helper loaded: form_helper
INFO - 2023-07-26 12:59:45 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:59:45 --> Controller Class Initialized
INFO - 2023-07-26 12:59:45 --> Database Driver Class Initialized
INFO - 2023-07-26 12:59:45 --> Model "Auth_model" initialized
DEBUG - 2023-07-26 12:59:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 12:59:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:59:45 --> Model "User_model" initialized
INFO - 2023-07-26 12:59:47 --> Config Class Initialized
INFO - 2023-07-26 12:59:47 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:59:47 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:59:47 --> Utf8 Class Initialized
INFO - 2023-07-26 12:59:47 --> URI Class Initialized
INFO - 2023-07-26 12:59:47 --> Router Class Initialized
INFO - 2023-07-26 12:59:47 --> Output Class Initialized
INFO - 2023-07-26 12:59:47 --> Security Class Initialized
DEBUG - 2023-07-26 12:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:59:47 --> Input Class Initialized
INFO - 2023-07-26 12:59:47 --> Language Class Initialized
INFO - 2023-07-26 12:59:47 --> Loader Class Initialized
INFO - 2023-07-26 12:59:47 --> Helper loaded: url_helper
INFO - 2023-07-26 12:59:47 --> Helper loaded: form_helper
INFO - 2023-07-26 12:59:47 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:59:47 --> Controller Class Initialized
INFO - 2023-07-26 12:59:47 --> Database Driver Class Initialized
INFO - 2023-07-26 12:59:47 --> Model "Auth_model" initialized
DEBUG - 2023-07-26 12:59:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 12:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:59:47 --> File loaded: C:\xampp\htdocs\Project\application\views\login.php
INFO - 2023-07-26 12:59:47 --> Final output sent to browser
DEBUG - 2023-07-26 12:59:47 --> Total execution time: 0.0497
INFO - 2023-07-26 12:59:48 --> Config Class Initialized
INFO - 2023-07-26 12:59:48 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:59:48 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:59:48 --> Utf8 Class Initialized
INFO - 2023-07-26 12:59:48 --> URI Class Initialized
DEBUG - 2023-07-26 12:59:48 --> No URI present. Default controller set.
INFO - 2023-07-26 12:59:48 --> Router Class Initialized
INFO - 2023-07-26 12:59:48 --> Output Class Initialized
INFO - 2023-07-26 12:59:48 --> Security Class Initialized
DEBUG - 2023-07-26 12:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:59:48 --> Input Class Initialized
INFO - 2023-07-26 12:59:48 --> Language Class Initialized
INFO - 2023-07-26 12:59:48 --> Loader Class Initialized
INFO - 2023-07-26 12:59:48 --> Helper loaded: url_helper
INFO - 2023-07-26 12:59:48 --> Helper loaded: form_helper
INFO - 2023-07-26 12:59:48 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:59:48 --> Controller Class Initialized
INFO - 2023-07-26 12:59:48 --> Database Driver Class Initialized
INFO - 2023-07-26 12:59:48 --> Model "Student_model" initialized
DEBUG - 2023-07-26 12:59:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:59:48 --> File loaded: C:\xampp\htdocs\Project\application\views\register.php
INFO - 2023-07-26 12:59:48 --> Final output sent to browser
DEBUG - 2023-07-26 12:59:48 --> Total execution time: 0.0335
INFO - 2023-07-26 12:59:50 --> Config Class Initialized
INFO - 2023-07-26 12:59:50 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:59:50 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:59:50 --> Utf8 Class Initialized
INFO - 2023-07-26 12:59:50 --> URI Class Initialized
INFO - 2023-07-26 12:59:50 --> Router Class Initialized
INFO - 2023-07-26 12:59:50 --> Output Class Initialized
INFO - 2023-07-26 12:59:50 --> Security Class Initialized
DEBUG - 2023-07-26 12:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:59:50 --> Input Class Initialized
INFO - 2023-07-26 12:59:50 --> Language Class Initialized
INFO - 2023-07-26 12:59:50 --> Loader Class Initialized
INFO - 2023-07-26 12:59:50 --> Helper loaded: url_helper
INFO - 2023-07-26 12:59:50 --> Helper loaded: form_helper
INFO - 2023-07-26 12:59:50 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:59:50 --> Controller Class Initialized
DEBUG - 2023-07-26 12:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:59:50 --> Database Driver Class Initialized
INFO - 2023-07-26 12:59:50 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:59:50 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/login.php
INFO - 2023-07-26 12:59:50 --> Final output sent to browser
DEBUG - 2023-07-26 12:59:50 --> Total execution time: 0.0722
INFO - 2023-07-26 12:59:59 --> Config Class Initialized
INFO - 2023-07-26 12:59:59 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:59:59 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:59:59 --> Utf8 Class Initialized
INFO - 2023-07-26 12:59:59 --> URI Class Initialized
INFO - 2023-07-26 12:59:59 --> Router Class Initialized
INFO - 2023-07-26 12:59:59 --> Output Class Initialized
INFO - 2023-07-26 12:59:59 --> Security Class Initialized
DEBUG - 2023-07-26 12:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:59:59 --> Input Class Initialized
INFO - 2023-07-26 12:59:59 --> Language Class Initialized
INFO - 2023-07-26 12:59:59 --> Loader Class Initialized
INFO - 2023-07-26 12:59:59 --> Helper loaded: url_helper
INFO - 2023-07-26 12:59:59 --> Helper loaded: form_helper
INFO - 2023-07-26 12:59:59 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:59:59 --> Controller Class Initialized
DEBUG - 2023-07-26 12:59:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:59:59 --> Database Driver Class Initialized
INFO - 2023-07-26 12:59:59 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:59:59 --> Config Class Initialized
INFO - 2023-07-26 12:59:59 --> Hooks Class Initialized
DEBUG - 2023-07-26 12:59:59 --> UTF-8 Support Enabled
INFO - 2023-07-26 12:59:59 --> Utf8 Class Initialized
INFO - 2023-07-26 12:59:59 --> URI Class Initialized
INFO - 2023-07-26 12:59:59 --> Router Class Initialized
INFO - 2023-07-26 12:59:59 --> Output Class Initialized
INFO - 2023-07-26 12:59:59 --> Security Class Initialized
DEBUG - 2023-07-26 12:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 12:59:59 --> Input Class Initialized
INFO - 2023-07-26 12:59:59 --> Language Class Initialized
INFO - 2023-07-26 12:59:59 --> Loader Class Initialized
INFO - 2023-07-26 12:59:59 --> Helper loaded: url_helper
INFO - 2023-07-26 12:59:59 --> Helper loaded: form_helper
INFO - 2023-07-26 12:59:59 --> Form Validation Class Initialized
DEBUG - 2023-07-26 12:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 12:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 12:59:59 --> Controller Class Initialized
DEBUG - 2023-07-26 12:59:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 12:59:59 --> Database Driver Class Initialized
INFO - 2023-07-26 12:59:59 --> Model "Admin_model" initialized
INFO - 2023-07-26 12:59:59 --> Model "Student_model" initialized
INFO - 2023-07-26 12:59:59 --> Model "Teacher_model" initialized
INFO - 2023-07-26 12:59:59 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/dashboard.php
INFO - 2023-07-26 12:59:59 --> Final output sent to browser
DEBUG - 2023-07-26 12:59:59 --> Total execution time: 0.0614
INFO - 2023-07-26 13:02:28 --> Config Class Initialized
INFO - 2023-07-26 13:02:28 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:02:28 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:02:28 --> Utf8 Class Initialized
INFO - 2023-07-26 13:02:28 --> URI Class Initialized
INFO - 2023-07-26 13:02:28 --> Router Class Initialized
INFO - 2023-07-26 13:02:28 --> Output Class Initialized
INFO - 2023-07-26 13:02:28 --> Security Class Initialized
DEBUG - 2023-07-26 13:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:02:28 --> Input Class Initialized
INFO - 2023-07-26 13:02:28 --> Language Class Initialized
INFO - 2023-07-26 13:02:28 --> Loader Class Initialized
INFO - 2023-07-26 13:02:28 --> Helper loaded: url_helper
INFO - 2023-07-26 13:02:28 --> Helper loaded: form_helper
INFO - 2023-07-26 13:02:28 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:02:28 --> Controller Class Initialized
DEBUG - 2023-07-26 13:02:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:02:28 --> Database Driver Class Initialized
INFO - 2023-07-26 13:02:28 --> Model "Admin_model" initialized
INFO - 2023-07-26 13:02:28 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/login.php
INFO - 2023-07-26 13:02:28 --> Final output sent to browser
DEBUG - 2023-07-26 13:02:28 --> Total execution time: 0.0464
INFO - 2023-07-26 13:02:28 --> Config Class Initialized
INFO - 2023-07-26 13:02:28 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:02:28 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:02:28 --> Utf8 Class Initialized
INFO - 2023-07-26 13:02:28 --> URI Class Initialized
DEBUG - 2023-07-26 13:02:28 --> No URI present. Default controller set.
INFO - 2023-07-26 13:02:28 --> Router Class Initialized
INFO - 2023-07-26 13:02:28 --> Output Class Initialized
INFO - 2023-07-26 13:02:28 --> Security Class Initialized
DEBUG - 2023-07-26 13:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:02:28 --> Input Class Initialized
INFO - 2023-07-26 13:02:28 --> Language Class Initialized
INFO - 2023-07-26 13:02:28 --> Loader Class Initialized
INFO - 2023-07-26 13:02:28 --> Helper loaded: url_helper
INFO - 2023-07-26 13:02:28 --> Helper loaded: form_helper
INFO - 2023-07-26 13:02:28 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:02:28 --> Controller Class Initialized
INFO - 2023-07-26 13:02:28 --> Database Driver Class Initialized
INFO - 2023-07-26 13:02:28 --> Model "Student_model" initialized
DEBUG - 2023-07-26 13:02:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:02:28 --> File loaded: C:\xampp\htdocs\Project\application\views\register.php
INFO - 2023-07-26 13:02:28 --> Final output sent to browser
DEBUG - 2023-07-26 13:02:28 --> Total execution time: 0.0552
INFO - 2023-07-26 13:14:45 --> Config Class Initialized
INFO - 2023-07-26 13:14:45 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:14:45 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:14:45 --> Utf8 Class Initialized
INFO - 2023-07-26 13:14:45 --> URI Class Initialized
INFO - 2023-07-26 13:14:45 --> Router Class Initialized
INFO - 2023-07-26 13:14:45 --> Output Class Initialized
INFO - 2023-07-26 13:14:45 --> Security Class Initialized
DEBUG - 2023-07-26 13:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:14:45 --> Input Class Initialized
INFO - 2023-07-26 13:14:45 --> Language Class Initialized
INFO - 2023-07-26 13:14:45 --> Loader Class Initialized
INFO - 2023-07-26 13:14:45 --> Helper loaded: url_helper
INFO - 2023-07-26 13:14:45 --> Helper loaded: form_helper
INFO - 2023-07-26 13:14:45 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:14:45 --> Controller Class Initialized
INFO - 2023-07-26 13:14:45 --> Database Driver Class Initialized
INFO - 2023-07-26 13:14:45 --> Model "Auth_model" initialized
DEBUG - 2023-07-26 13:14:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 13:14:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:14:45 --> File loaded: C:\xampp\htdocs\Project\application\views\login.php
INFO - 2023-07-26 13:14:45 --> Final output sent to browser
DEBUG - 2023-07-26 13:14:45 --> Total execution time: 0.0334
INFO - 2023-07-26 13:14:56 --> Config Class Initialized
INFO - 2023-07-26 13:14:56 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:14:56 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:14:56 --> Utf8 Class Initialized
INFO - 2023-07-26 13:14:56 --> URI Class Initialized
INFO - 2023-07-26 13:14:56 --> Router Class Initialized
INFO - 2023-07-26 13:14:56 --> Output Class Initialized
INFO - 2023-07-26 13:14:56 --> Security Class Initialized
DEBUG - 2023-07-26 13:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:14:56 --> Input Class Initialized
INFO - 2023-07-26 13:14:56 --> Language Class Initialized
INFO - 2023-07-26 13:14:56 --> Loader Class Initialized
INFO - 2023-07-26 13:14:56 --> Helper loaded: url_helper
INFO - 2023-07-26 13:14:56 --> Helper loaded: form_helper
INFO - 2023-07-26 13:14:56 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:14:56 --> Controller Class Initialized
INFO - 2023-07-26 13:14:56 --> Database Driver Class Initialized
INFO - 2023-07-26 13:14:57 --> Model "Auth_model" initialized
DEBUG - 2023-07-26 13:14:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 13:14:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:14:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-07-26 13:14:57 --> Config Class Initialized
INFO - 2023-07-26 13:14:57 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:14:57 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:14:57 --> Utf8 Class Initialized
INFO - 2023-07-26 13:14:57 --> URI Class Initialized
INFO - 2023-07-26 13:14:57 --> Router Class Initialized
INFO - 2023-07-26 13:14:57 --> Output Class Initialized
INFO - 2023-07-26 13:14:57 --> Security Class Initialized
DEBUG - 2023-07-26 13:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:14:57 --> Input Class Initialized
INFO - 2023-07-26 13:14:57 --> Language Class Initialized
INFO - 2023-07-26 13:14:57 --> Loader Class Initialized
INFO - 2023-07-26 13:14:57 --> Helper loaded: url_helper
INFO - 2023-07-26 13:14:57 --> Helper loaded: form_helper
INFO - 2023-07-26 13:14:57 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:14:57 --> Controller Class Initialized
DEBUG - 2023-07-26 13:14:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:14:57 --> Database Driver Class Initialized
INFO - 2023-07-26 13:14:57 --> Model "User_model" initialized
INFO - 2023-07-26 13:14:57 --> Model "Student_model" initialized
INFO - 2023-07-26 13:14:57 --> File loaded: C:\xampp\htdocs\Project\application\views\dashboard.php
INFO - 2023-07-26 13:14:57 --> Final output sent to browser
DEBUG - 2023-07-26 13:14:57 --> Total execution time: 0.0485
INFO - 2023-07-26 13:15:39 --> Config Class Initialized
INFO - 2023-07-26 13:15:39 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:15:39 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:15:39 --> Utf8 Class Initialized
INFO - 2023-07-26 13:15:39 --> URI Class Initialized
INFO - 2023-07-26 13:15:39 --> Router Class Initialized
INFO - 2023-07-26 13:15:39 --> Output Class Initialized
INFO - 2023-07-26 13:15:39 --> Security Class Initialized
DEBUG - 2023-07-26 13:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:15:39 --> Input Class Initialized
INFO - 2023-07-26 13:15:39 --> Language Class Initialized
INFO - 2023-07-26 13:15:39 --> Loader Class Initialized
INFO - 2023-07-26 13:15:39 --> Helper loaded: url_helper
INFO - 2023-07-26 13:15:39 --> Helper loaded: form_helper
INFO - 2023-07-26 13:15:39 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:15:39 --> Controller Class Initialized
DEBUG - 2023-07-26 13:15:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:15:39 --> Database Driver Class Initialized
INFO - 2023-07-26 13:15:39 --> Model "User_model" initialized
INFO - 2023-07-26 13:15:39 --> Upload Class Initialized
INFO - 2023-07-26 13:15:39 --> Model "Student_model" initialized
INFO - 2023-07-26 13:15:39 --> Config Class Initialized
INFO - 2023-07-26 13:15:39 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:15:39 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:15:39 --> Utf8 Class Initialized
INFO - 2023-07-26 13:15:39 --> URI Class Initialized
INFO - 2023-07-26 13:15:39 --> Router Class Initialized
INFO - 2023-07-26 13:15:39 --> Output Class Initialized
INFO - 2023-07-26 13:15:39 --> Security Class Initialized
DEBUG - 2023-07-26 13:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:15:39 --> Input Class Initialized
INFO - 2023-07-26 13:15:39 --> Language Class Initialized
INFO - 2023-07-26 13:15:39 --> Loader Class Initialized
INFO - 2023-07-26 13:15:39 --> Helper loaded: url_helper
INFO - 2023-07-26 13:15:39 --> Helper loaded: form_helper
INFO - 2023-07-26 13:15:39 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:15:39 --> Controller Class Initialized
DEBUG - 2023-07-26 13:15:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:15:39 --> Database Driver Class Initialized
INFO - 2023-07-26 13:15:39 --> Model "User_model" initialized
INFO - 2023-07-26 13:15:39 --> Model "Student_model" initialized
INFO - 2023-07-26 13:15:39 --> File loaded: C:\xampp\htdocs\Project\application\views\dashboard.php
INFO - 2023-07-26 13:15:39 --> Final output sent to browser
DEBUG - 2023-07-26 13:15:39 --> Total execution time: 0.0489
INFO - 2023-07-26 13:18:58 --> Config Class Initialized
INFO - 2023-07-26 13:18:58 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:18:58 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:18:58 --> Utf8 Class Initialized
INFO - 2023-07-26 13:18:58 --> URI Class Initialized
INFO - 2023-07-26 13:18:58 --> Router Class Initialized
INFO - 2023-07-26 13:18:58 --> Output Class Initialized
INFO - 2023-07-26 13:18:58 --> Security Class Initialized
DEBUG - 2023-07-26 13:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:18:58 --> Input Class Initialized
INFO - 2023-07-26 13:18:58 --> Language Class Initialized
INFO - 2023-07-26 13:18:58 --> Loader Class Initialized
INFO - 2023-07-26 13:18:58 --> Helper loaded: url_helper
INFO - 2023-07-26 13:18:58 --> Helper loaded: form_helper
INFO - 2023-07-26 13:18:58 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:18:58 --> Controller Class Initialized
INFO - 2023-07-26 13:18:58 --> Database Driver Class Initialized
INFO - 2023-07-26 13:18:58 --> Model "Auth_model" initialized
DEBUG - 2023-07-26 13:18:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 13:18:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:18:58 --> Config Class Initialized
INFO - 2023-07-26 13:18:58 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:18:58 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:18:58 --> Utf8 Class Initialized
INFO - 2023-07-26 13:18:58 --> URI Class Initialized
INFO - 2023-07-26 13:18:58 --> Router Class Initialized
INFO - 2023-07-26 13:18:58 --> Output Class Initialized
INFO - 2023-07-26 13:18:58 --> Security Class Initialized
DEBUG - 2023-07-26 13:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:18:58 --> Input Class Initialized
INFO - 2023-07-26 13:18:58 --> Language Class Initialized
INFO - 2023-07-26 13:18:58 --> Loader Class Initialized
INFO - 2023-07-26 13:18:58 --> Helper loaded: url_helper
INFO - 2023-07-26 13:18:58 --> Helper loaded: form_helper
INFO - 2023-07-26 13:18:58 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:18:58 --> Controller Class Initialized
INFO - 2023-07-26 13:18:58 --> Database Driver Class Initialized
INFO - 2023-07-26 13:18:58 --> Model "Auth_model" initialized
DEBUG - 2023-07-26 13:18:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 13:18:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:18:58 --> File loaded: C:\xampp\htdocs\Project\application\views\login.php
INFO - 2023-07-26 13:18:58 --> Final output sent to browser
DEBUG - 2023-07-26 13:18:58 --> Total execution time: 0.0556
INFO - 2023-07-26 13:18:59 --> Config Class Initialized
INFO - 2023-07-26 13:18:59 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:18:59 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:18:59 --> Utf8 Class Initialized
INFO - 2023-07-26 13:18:59 --> URI Class Initialized
INFO - 2023-07-26 13:18:59 --> Router Class Initialized
INFO - 2023-07-26 13:18:59 --> Output Class Initialized
INFO - 2023-07-26 13:18:59 --> Security Class Initialized
DEBUG - 2023-07-26 13:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:18:59 --> Input Class Initialized
INFO - 2023-07-26 13:18:59 --> Language Class Initialized
INFO - 2023-07-26 13:18:59 --> Loader Class Initialized
INFO - 2023-07-26 13:18:59 --> Helper loaded: url_helper
INFO - 2023-07-26 13:18:59 --> Helper loaded: form_helper
INFO - 2023-07-26 13:18:59 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:18:59 --> Controller Class Initialized
DEBUG - 2023-07-26 13:18:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:18:59 --> Database Driver Class Initialized
INFO - 2023-07-26 13:18:59 --> Model "User_model" initialized
INFO - 2023-07-26 13:18:59 --> Config Class Initialized
INFO - 2023-07-26 13:18:59 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:18:59 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:18:59 --> Utf8 Class Initialized
INFO - 2023-07-26 13:18:59 --> URI Class Initialized
INFO - 2023-07-26 13:18:59 --> Router Class Initialized
INFO - 2023-07-26 13:18:59 --> Output Class Initialized
INFO - 2023-07-26 13:18:59 --> Security Class Initialized
DEBUG - 2023-07-26 13:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:18:59 --> Input Class Initialized
INFO - 2023-07-26 13:18:59 --> Language Class Initialized
INFO - 2023-07-26 13:18:59 --> Loader Class Initialized
INFO - 2023-07-26 13:18:59 --> Helper loaded: url_helper
INFO - 2023-07-26 13:18:59 --> Helper loaded: form_helper
INFO - 2023-07-26 13:18:59 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:18:59 --> Controller Class Initialized
INFO - 2023-07-26 13:18:59 --> Database Driver Class Initialized
INFO - 2023-07-26 13:18:59 --> Model "Auth_model" initialized
DEBUG - 2023-07-26 13:18:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 13:18:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:18:59 --> File loaded: C:\xampp\htdocs\Project\application\views\login.php
INFO - 2023-07-26 13:18:59 --> Final output sent to browser
DEBUG - 2023-07-26 13:18:59 --> Total execution time: 0.0484
INFO - 2023-07-26 13:19:00 --> Config Class Initialized
INFO - 2023-07-26 13:19:00 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:19:00 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:19:00 --> Utf8 Class Initialized
INFO - 2023-07-26 13:19:00 --> URI Class Initialized
INFO - 2023-07-26 13:19:00 --> Router Class Initialized
INFO - 2023-07-26 13:19:00 --> Output Class Initialized
INFO - 2023-07-26 13:19:00 --> Security Class Initialized
DEBUG - 2023-07-26 13:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:19:00 --> Input Class Initialized
INFO - 2023-07-26 13:19:00 --> Language Class Initialized
INFO - 2023-07-26 13:19:00 --> Loader Class Initialized
INFO - 2023-07-26 13:19:00 --> Helper loaded: url_helper
INFO - 2023-07-26 13:19:00 --> Helper loaded: form_helper
INFO - 2023-07-26 13:19:00 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:19:00 --> Controller Class Initialized
DEBUG - 2023-07-26 13:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:19:00 --> Database Driver Class Initialized
INFO - 2023-07-26 13:19:00 --> Model "User_model" initialized
INFO - 2023-07-26 13:19:00 --> Config Class Initialized
INFO - 2023-07-26 13:19:00 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:19:00 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:19:00 --> Utf8 Class Initialized
INFO - 2023-07-26 13:19:00 --> URI Class Initialized
INFO - 2023-07-26 13:19:00 --> Router Class Initialized
INFO - 2023-07-26 13:19:00 --> Output Class Initialized
INFO - 2023-07-26 13:19:00 --> Security Class Initialized
DEBUG - 2023-07-26 13:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:19:00 --> Input Class Initialized
INFO - 2023-07-26 13:19:00 --> Language Class Initialized
INFO - 2023-07-26 13:19:00 --> Loader Class Initialized
INFO - 2023-07-26 13:19:00 --> Helper loaded: url_helper
INFO - 2023-07-26 13:19:00 --> Helper loaded: form_helper
INFO - 2023-07-26 13:19:00 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:19:00 --> Controller Class Initialized
INFO - 2023-07-26 13:19:00 --> Database Driver Class Initialized
INFO - 2023-07-26 13:19:00 --> Model "Auth_model" initialized
DEBUG - 2023-07-26 13:19:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 13:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:19:00 --> File loaded: C:\xampp\htdocs\Project\application\views\login.php
INFO - 2023-07-26 13:19:00 --> Final output sent to browser
DEBUG - 2023-07-26 13:19:00 --> Total execution time: 0.0480
INFO - 2023-07-26 13:19:01 --> Config Class Initialized
INFO - 2023-07-26 13:19:01 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:19:01 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:19:01 --> Utf8 Class Initialized
INFO - 2023-07-26 13:19:01 --> URI Class Initialized
INFO - 2023-07-26 13:19:01 --> Router Class Initialized
INFO - 2023-07-26 13:19:01 --> Output Class Initialized
INFO - 2023-07-26 13:19:01 --> Security Class Initialized
DEBUG - 2023-07-26 13:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:19:01 --> Input Class Initialized
INFO - 2023-07-26 13:19:01 --> Language Class Initialized
INFO - 2023-07-26 13:19:01 --> Loader Class Initialized
INFO - 2023-07-26 13:19:01 --> Helper loaded: url_helper
INFO - 2023-07-26 13:19:01 --> Helper loaded: form_helper
INFO - 2023-07-26 13:19:01 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:19:01 --> Controller Class Initialized
INFO - 2023-07-26 13:19:01 --> Database Driver Class Initialized
INFO - 2023-07-26 13:19:01 --> Model "Auth_model" initialized
DEBUG - 2023-07-26 13:19:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 13:19:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:19:01 --> File loaded: C:\xampp\htdocs\Project\application\views\login.php
INFO - 2023-07-26 13:19:01 --> Final output sent to browser
DEBUG - 2023-07-26 13:19:01 --> Total execution time: 0.0515
INFO - 2023-07-26 13:19:07 --> Config Class Initialized
INFO - 2023-07-26 13:19:07 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:19:07 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:19:07 --> Utf8 Class Initialized
INFO - 2023-07-26 13:19:07 --> URI Class Initialized
DEBUG - 2023-07-26 13:19:07 --> No URI present. Default controller set.
INFO - 2023-07-26 13:19:07 --> Router Class Initialized
INFO - 2023-07-26 13:19:07 --> Output Class Initialized
INFO - 2023-07-26 13:19:07 --> Security Class Initialized
DEBUG - 2023-07-26 13:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:19:07 --> Input Class Initialized
INFO - 2023-07-26 13:19:07 --> Language Class Initialized
INFO - 2023-07-26 13:19:07 --> Loader Class Initialized
INFO - 2023-07-26 13:19:07 --> Helper loaded: url_helper
INFO - 2023-07-26 13:19:07 --> Helper loaded: form_helper
INFO - 2023-07-26 13:19:07 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:19:07 --> Controller Class Initialized
INFO - 2023-07-26 13:19:07 --> Database Driver Class Initialized
INFO - 2023-07-26 13:19:07 --> Model "Student_model" initialized
DEBUG - 2023-07-26 13:19:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:19:07 --> File loaded: C:\xampp\htdocs\Project\application\views\register.php
INFO - 2023-07-26 13:19:07 --> Final output sent to browser
DEBUG - 2023-07-26 13:19:07 --> Total execution time: 0.0396
INFO - 2023-07-26 13:23:03 --> Config Class Initialized
INFO - 2023-07-26 13:23:03 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:23:03 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:23:03 --> Utf8 Class Initialized
INFO - 2023-07-26 13:23:03 --> URI Class Initialized
INFO - 2023-07-26 13:23:03 --> Router Class Initialized
INFO - 2023-07-26 13:23:03 --> Output Class Initialized
INFO - 2023-07-26 13:23:03 --> Security Class Initialized
DEBUG - 2023-07-26 13:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:23:03 --> Input Class Initialized
INFO - 2023-07-26 13:23:03 --> Language Class Initialized
INFO - 2023-07-26 13:23:03 --> Loader Class Initialized
INFO - 2023-07-26 13:23:03 --> Helper loaded: url_helper
INFO - 2023-07-26 13:23:03 --> Helper loaded: form_helper
INFO - 2023-07-26 13:23:03 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:23:03 --> Controller Class Initialized
DEBUG - 2023-07-26 13:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:23:03 --> Database Driver Class Initialized
INFO - 2023-07-26 13:23:03 --> Model "Admin_model" initialized
INFO - 2023-07-26 13:23:03 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/login.php
INFO - 2023-07-26 13:23:03 --> Final output sent to browser
DEBUG - 2023-07-26 13:23:03 --> Total execution time: 0.0499
INFO - 2023-07-26 13:23:16 --> Config Class Initialized
INFO - 2023-07-26 13:23:16 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:23:16 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:23:16 --> Utf8 Class Initialized
INFO - 2023-07-26 13:23:16 --> URI Class Initialized
INFO - 2023-07-26 13:23:16 --> Router Class Initialized
INFO - 2023-07-26 13:23:16 --> Output Class Initialized
INFO - 2023-07-26 13:23:16 --> Security Class Initialized
DEBUG - 2023-07-26 13:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:23:16 --> Input Class Initialized
INFO - 2023-07-26 13:23:16 --> Language Class Initialized
INFO - 2023-07-26 13:23:16 --> Loader Class Initialized
INFO - 2023-07-26 13:23:16 --> Helper loaded: url_helper
INFO - 2023-07-26 13:23:16 --> Helper loaded: form_helper
INFO - 2023-07-26 13:23:16 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:23:16 --> Controller Class Initialized
DEBUG - 2023-07-26 13:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:23:16 --> Database Driver Class Initialized
INFO - 2023-07-26 13:23:16 --> Model "Admin_model" initialized
INFO - 2023-07-26 13:23:16 --> Config Class Initialized
INFO - 2023-07-26 13:23:16 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:23:16 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:23:16 --> Utf8 Class Initialized
INFO - 2023-07-26 13:23:16 --> URI Class Initialized
INFO - 2023-07-26 13:23:16 --> Router Class Initialized
INFO - 2023-07-26 13:23:16 --> Output Class Initialized
INFO - 2023-07-26 13:23:16 --> Security Class Initialized
DEBUG - 2023-07-26 13:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:23:16 --> Input Class Initialized
INFO - 2023-07-26 13:23:16 --> Language Class Initialized
INFO - 2023-07-26 13:23:16 --> Loader Class Initialized
INFO - 2023-07-26 13:23:16 --> Helper loaded: url_helper
INFO - 2023-07-26 13:23:16 --> Helper loaded: form_helper
INFO - 2023-07-26 13:23:16 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:23:16 --> Controller Class Initialized
DEBUG - 2023-07-26 13:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:23:16 --> Database Driver Class Initialized
INFO - 2023-07-26 13:23:16 --> Model "Admin_model" initialized
INFO - 2023-07-26 13:23:16 --> Model "Student_model" initialized
INFO - 2023-07-26 13:23:16 --> Model "Teacher_model" initialized
INFO - 2023-07-26 13:23:16 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/dashboard.php
INFO - 2023-07-26 13:23:16 --> Final output sent to browser
DEBUG - 2023-07-26 13:23:16 --> Total execution time: 0.0556
INFO - 2023-07-26 13:23:22 --> Config Class Initialized
INFO - 2023-07-26 13:23:22 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:23:22 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:23:22 --> Utf8 Class Initialized
INFO - 2023-07-26 13:23:22 --> URI Class Initialized
INFO - 2023-07-26 13:23:22 --> Router Class Initialized
INFO - 2023-07-26 13:23:22 --> Output Class Initialized
INFO - 2023-07-26 13:23:22 --> Security Class Initialized
DEBUG - 2023-07-26 13:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:23:22 --> Input Class Initialized
INFO - 2023-07-26 13:23:22 --> Language Class Initialized
INFO - 2023-07-26 13:23:22 --> Loader Class Initialized
INFO - 2023-07-26 13:23:22 --> Helper loaded: url_helper
INFO - 2023-07-26 13:23:22 --> Helper loaded: form_helper
INFO - 2023-07-26 13:23:22 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:23:22 --> Controller Class Initialized
DEBUG - 2023-07-26 13:23:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:23:22 --> Database Driver Class Initialized
INFO - 2023-07-26 13:23:23 --> Model "Admin_model" initialized
INFO - 2023-07-26 13:23:23 --> Model "Student_model" initialized
INFO - 2023-07-26 13:23:23 --> Model "Teacher_model" initialized
INFO - 2023-07-26 13:23:23 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_student.php
INFO - 2023-07-26 13:23:23 --> Final output sent to browser
DEBUG - 2023-07-26 13:23:23 --> Total execution time: 0.0540
INFO - 2023-07-26 13:23:31 --> Config Class Initialized
INFO - 2023-07-26 13:23:31 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:23:31 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:23:31 --> Utf8 Class Initialized
INFO - 2023-07-26 13:23:31 --> URI Class Initialized
INFO - 2023-07-26 13:23:31 --> Router Class Initialized
INFO - 2023-07-26 13:23:31 --> Output Class Initialized
INFO - 2023-07-26 13:23:31 --> Security Class Initialized
DEBUG - 2023-07-26 13:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:23:31 --> Input Class Initialized
INFO - 2023-07-26 13:23:31 --> Language Class Initialized
INFO - 2023-07-26 13:23:31 --> Loader Class Initialized
INFO - 2023-07-26 13:23:31 --> Helper loaded: url_helper
INFO - 2023-07-26 13:23:31 --> Helper loaded: form_helper
INFO - 2023-07-26 13:23:31 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:23:31 --> Controller Class Initialized
DEBUG - 2023-07-26 13:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:23:31 --> Database Driver Class Initialized
INFO - 2023-07-26 13:23:31 --> Model "Admin_model" initialized
INFO - 2023-07-26 13:23:31 --> Model "Student_model" initialized
INFO - 2023-07-26 13:23:31 --> Model "Teacher_model" initialized
INFO - 2023-07-26 13:23:31 --> Config Class Initialized
INFO - 2023-07-26 13:23:31 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:23:31 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:23:31 --> Utf8 Class Initialized
INFO - 2023-07-26 13:23:31 --> URI Class Initialized
INFO - 2023-07-26 13:23:31 --> Router Class Initialized
INFO - 2023-07-26 13:23:31 --> Output Class Initialized
INFO - 2023-07-26 13:23:31 --> Security Class Initialized
DEBUG - 2023-07-26 13:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:23:31 --> Input Class Initialized
INFO - 2023-07-26 13:23:31 --> Language Class Initialized
INFO - 2023-07-26 13:23:31 --> Loader Class Initialized
INFO - 2023-07-26 13:23:31 --> Helper loaded: url_helper
INFO - 2023-07-26 13:23:31 --> Helper loaded: form_helper
INFO - 2023-07-26 13:23:31 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:23:31 --> Controller Class Initialized
DEBUG - 2023-07-26 13:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:23:31 --> Database Driver Class Initialized
INFO - 2023-07-26 13:23:31 --> Model "Admin_model" initialized
INFO - 2023-07-26 13:23:31 --> Model "Student_model" initialized
INFO - 2023-07-26 13:23:31 --> Model "Teacher_model" initialized
INFO - 2023-07-26 13:23:31 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/dashboard.php
INFO - 2023-07-26 13:23:31 --> Final output sent to browser
DEBUG - 2023-07-26 13:23:31 --> Total execution time: 0.0522
INFO - 2023-07-26 13:23:35 --> Config Class Initialized
INFO - 2023-07-26 13:23:35 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:23:35 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:23:35 --> Utf8 Class Initialized
INFO - 2023-07-26 13:23:35 --> URI Class Initialized
INFO - 2023-07-26 13:23:35 --> Router Class Initialized
INFO - 2023-07-26 13:23:35 --> Output Class Initialized
INFO - 2023-07-26 13:23:35 --> Security Class Initialized
DEBUG - 2023-07-26 13:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:23:35 --> Input Class Initialized
INFO - 2023-07-26 13:23:35 --> Language Class Initialized
INFO - 2023-07-26 13:23:35 --> Loader Class Initialized
INFO - 2023-07-26 13:23:35 --> Helper loaded: url_helper
INFO - 2023-07-26 13:23:35 --> Helper loaded: form_helper
INFO - 2023-07-26 13:23:35 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:23:35 --> Controller Class Initialized
DEBUG - 2023-07-26 13:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:23:35 --> Database Driver Class Initialized
INFO - 2023-07-26 13:23:35 --> Model "Admin_model" initialized
INFO - 2023-07-26 13:23:35 --> Model "Student_model" initialized
INFO - 2023-07-26 13:23:35 --> Model "Teacher_model" initialized
INFO - 2023-07-26 13:23:35 --> Config Class Initialized
INFO - 2023-07-26 13:23:35 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:23:35 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:23:35 --> Utf8 Class Initialized
INFO - 2023-07-26 13:23:35 --> URI Class Initialized
INFO - 2023-07-26 13:23:35 --> Router Class Initialized
INFO - 2023-07-26 13:23:35 --> Output Class Initialized
INFO - 2023-07-26 13:23:35 --> Security Class Initialized
DEBUG - 2023-07-26 13:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:23:35 --> Input Class Initialized
INFO - 2023-07-26 13:23:35 --> Language Class Initialized
INFO - 2023-07-26 13:23:35 --> Loader Class Initialized
INFO - 2023-07-26 13:23:35 --> Helper loaded: url_helper
INFO - 2023-07-26 13:23:35 --> Helper loaded: form_helper
INFO - 2023-07-26 13:23:35 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:23:35 --> Controller Class Initialized
DEBUG - 2023-07-26 13:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:23:35 --> Database Driver Class Initialized
INFO - 2023-07-26 13:23:35 --> Model "Admin_model" initialized
INFO - 2023-07-26 13:23:35 --> Model "Student_model" initialized
INFO - 2023-07-26 13:23:35 --> Model "Teacher_model" initialized
INFO - 2023-07-26 13:23:35 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/dashboard.php
INFO - 2023-07-26 13:23:35 --> Final output sent to browser
DEBUG - 2023-07-26 13:23:35 --> Total execution time: 0.0552
INFO - 2023-07-26 13:23:39 --> Config Class Initialized
INFO - 2023-07-26 13:23:39 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:23:39 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:23:39 --> Utf8 Class Initialized
INFO - 2023-07-26 13:23:39 --> URI Class Initialized
INFO - 2023-07-26 13:23:39 --> Router Class Initialized
INFO - 2023-07-26 13:23:39 --> Output Class Initialized
INFO - 2023-07-26 13:23:39 --> Security Class Initialized
DEBUG - 2023-07-26 13:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:23:39 --> Input Class Initialized
INFO - 2023-07-26 13:23:39 --> Language Class Initialized
INFO - 2023-07-26 13:23:39 --> Loader Class Initialized
INFO - 2023-07-26 13:23:39 --> Helper loaded: url_helper
INFO - 2023-07-26 13:23:39 --> Helper loaded: form_helper
INFO - 2023-07-26 13:23:39 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:23:39 --> Controller Class Initialized
DEBUG - 2023-07-26 13:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:23:39 --> Database Driver Class Initialized
INFO - 2023-07-26 13:23:39 --> Model "Admin_model" initialized
INFO - 2023-07-26 13:23:39 --> Model "Student_model" initialized
INFO - 2023-07-26 13:23:39 --> Model "Teacher_model" initialized
INFO - 2023-07-26 13:23:39 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 13:23:39 --> Final output sent to browser
DEBUG - 2023-07-26 13:23:39 --> Total execution time: 0.0423
INFO - 2023-07-26 13:23:44 --> Config Class Initialized
INFO - 2023-07-26 13:23:44 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:23:44 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:23:44 --> Utf8 Class Initialized
INFO - 2023-07-26 13:23:44 --> URI Class Initialized
INFO - 2023-07-26 13:23:44 --> Router Class Initialized
INFO - 2023-07-26 13:23:44 --> Output Class Initialized
INFO - 2023-07-26 13:23:44 --> Security Class Initialized
DEBUG - 2023-07-26 13:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:23:44 --> Input Class Initialized
INFO - 2023-07-26 13:23:44 --> Language Class Initialized
INFO - 2023-07-26 13:23:44 --> Loader Class Initialized
INFO - 2023-07-26 13:23:44 --> Helper loaded: url_helper
INFO - 2023-07-26 13:23:44 --> Helper loaded: form_helper
INFO - 2023-07-26 13:23:44 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:23:44 --> Controller Class Initialized
DEBUG - 2023-07-26 13:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:23:44 --> Database Driver Class Initialized
INFO - 2023-07-26 13:23:44 --> Model "Admin_model" initialized
INFO - 2023-07-26 13:23:44 --> Model "Student_model" initialized
INFO - 2023-07-26 13:23:44 --> Model "Teacher_model" initialized
INFO - 2023-07-26 13:23:44 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/edit_teacher.php
INFO - 2023-07-26 13:23:44 --> Final output sent to browser
DEBUG - 2023-07-26 13:23:44 --> Total execution time: 0.0627
INFO - 2023-07-26 13:23:49 --> Config Class Initialized
INFO - 2023-07-26 13:23:49 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:23:49 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:23:49 --> Utf8 Class Initialized
INFO - 2023-07-26 13:23:49 --> URI Class Initialized
INFO - 2023-07-26 13:23:49 --> Router Class Initialized
INFO - 2023-07-26 13:23:49 --> Output Class Initialized
INFO - 2023-07-26 13:23:49 --> Security Class Initialized
DEBUG - 2023-07-26 13:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:23:49 --> Input Class Initialized
INFO - 2023-07-26 13:23:49 --> Language Class Initialized
INFO - 2023-07-26 13:23:49 --> Loader Class Initialized
INFO - 2023-07-26 13:23:49 --> Helper loaded: url_helper
INFO - 2023-07-26 13:23:49 --> Helper loaded: form_helper
INFO - 2023-07-26 13:23:49 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:23:49 --> Controller Class Initialized
DEBUG - 2023-07-26 13:23:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:23:49 --> Database Driver Class Initialized
INFO - 2023-07-26 13:23:49 --> Model "Admin_model" initialized
INFO - 2023-07-26 13:23:49 --> Model "Student_model" initialized
INFO - 2023-07-26 13:23:49 --> Model "Teacher_model" initialized
INFO - 2023-07-26 13:23:49 --> Config Class Initialized
INFO - 2023-07-26 13:23:49 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:23:49 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:23:49 --> Utf8 Class Initialized
INFO - 2023-07-26 13:23:49 --> URI Class Initialized
INFO - 2023-07-26 13:23:49 --> Router Class Initialized
INFO - 2023-07-26 13:23:49 --> Output Class Initialized
INFO - 2023-07-26 13:23:49 --> Security Class Initialized
DEBUG - 2023-07-26 13:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:23:49 --> Input Class Initialized
INFO - 2023-07-26 13:23:49 --> Language Class Initialized
INFO - 2023-07-26 13:23:49 --> Loader Class Initialized
INFO - 2023-07-26 13:23:49 --> Helper loaded: url_helper
INFO - 2023-07-26 13:23:49 --> Helper loaded: form_helper
INFO - 2023-07-26 13:23:49 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:23:49 --> Controller Class Initialized
DEBUG - 2023-07-26 13:23:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:23:49 --> Database Driver Class Initialized
INFO - 2023-07-26 13:23:49 --> Model "Admin_model" initialized
INFO - 2023-07-26 13:23:49 --> Model "Student_model" initialized
INFO - 2023-07-26 13:23:49 --> Model "Teacher_model" initialized
INFO - 2023-07-26 13:23:49 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 13:23:49 --> Final output sent to browser
DEBUG - 2023-07-26 13:23:49 --> Total execution time: 0.0390
INFO - 2023-07-26 13:23:51 --> Config Class Initialized
INFO - 2023-07-26 13:23:51 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:23:51 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:23:51 --> Utf8 Class Initialized
INFO - 2023-07-26 13:23:51 --> URI Class Initialized
INFO - 2023-07-26 13:23:51 --> Router Class Initialized
INFO - 2023-07-26 13:23:51 --> Output Class Initialized
INFO - 2023-07-26 13:23:51 --> Security Class Initialized
DEBUG - 2023-07-26 13:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:23:51 --> Input Class Initialized
INFO - 2023-07-26 13:23:51 --> Language Class Initialized
INFO - 2023-07-26 13:23:51 --> Loader Class Initialized
INFO - 2023-07-26 13:23:51 --> Helper loaded: url_helper
INFO - 2023-07-26 13:23:51 --> Helper loaded: form_helper
INFO - 2023-07-26 13:23:51 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:23:51 --> Controller Class Initialized
DEBUG - 2023-07-26 13:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:23:51 --> Database Driver Class Initialized
INFO - 2023-07-26 13:23:51 --> Model "Admin_model" initialized
INFO - 2023-07-26 13:23:51 --> Model "Student_model" initialized
INFO - 2023-07-26 13:23:51 --> Model "Teacher_model" initialized
INFO - 2023-07-26 13:23:51 --> Config Class Initialized
INFO - 2023-07-26 13:23:51 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:23:51 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:23:51 --> Utf8 Class Initialized
INFO - 2023-07-26 13:23:51 --> URI Class Initialized
INFO - 2023-07-26 13:23:51 --> Router Class Initialized
INFO - 2023-07-26 13:23:51 --> Output Class Initialized
INFO - 2023-07-26 13:23:51 --> Security Class Initialized
DEBUG - 2023-07-26 13:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:23:51 --> Input Class Initialized
INFO - 2023-07-26 13:23:51 --> Language Class Initialized
INFO - 2023-07-26 13:23:51 --> Loader Class Initialized
INFO - 2023-07-26 13:23:51 --> Helper loaded: url_helper
INFO - 2023-07-26 13:23:51 --> Helper loaded: form_helper
INFO - 2023-07-26 13:23:51 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:23:51 --> Controller Class Initialized
DEBUG - 2023-07-26 13:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:23:51 --> Database Driver Class Initialized
INFO - 2023-07-26 13:23:51 --> Model "Admin_model" initialized
INFO - 2023-07-26 13:23:51 --> Model "Student_model" initialized
INFO - 2023-07-26 13:23:51 --> Model "Teacher_model" initialized
INFO - 2023-07-26 13:23:51 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 13:23:51 --> Final output sent to browser
DEBUG - 2023-07-26 13:23:51 --> Total execution time: 0.0568
INFO - 2023-07-26 13:24:08 --> Config Class Initialized
INFO - 2023-07-26 13:24:08 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:24:08 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:24:08 --> Utf8 Class Initialized
INFO - 2023-07-26 13:24:08 --> URI Class Initialized
INFO - 2023-07-26 13:24:08 --> Router Class Initialized
INFO - 2023-07-26 13:24:08 --> Output Class Initialized
INFO - 2023-07-26 13:24:08 --> Security Class Initialized
DEBUG - 2023-07-26 13:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:24:08 --> Input Class Initialized
INFO - 2023-07-26 13:24:08 --> Language Class Initialized
INFO - 2023-07-26 13:24:08 --> Loader Class Initialized
INFO - 2023-07-26 13:24:08 --> Helper loaded: url_helper
INFO - 2023-07-26 13:24:08 --> Helper loaded: form_helper
INFO - 2023-07-26 13:24:08 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:24:08 --> Controller Class Initialized
DEBUG - 2023-07-26 13:24:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:24:08 --> Database Driver Class Initialized
INFO - 2023-07-26 13:24:08 --> Model "Admin_model" initialized
INFO - 2023-07-26 13:24:08 --> Model "Student_model" initialized
INFO - 2023-07-26 13:24:08 --> Model "Teacher_model" initialized
INFO - 2023-07-26 13:24:08 --> Config Class Initialized
INFO - 2023-07-26 13:24:08 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:24:08 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:24:08 --> Utf8 Class Initialized
INFO - 2023-07-26 13:24:08 --> URI Class Initialized
INFO - 2023-07-26 13:24:08 --> Router Class Initialized
INFO - 2023-07-26 13:24:08 --> Output Class Initialized
INFO - 2023-07-26 13:24:08 --> Security Class Initialized
DEBUG - 2023-07-26 13:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:24:08 --> Input Class Initialized
INFO - 2023-07-26 13:24:08 --> Language Class Initialized
INFO - 2023-07-26 13:24:08 --> Loader Class Initialized
INFO - 2023-07-26 13:24:08 --> Helper loaded: url_helper
INFO - 2023-07-26 13:24:08 --> Helper loaded: form_helper
INFO - 2023-07-26 13:24:08 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:24:08 --> Controller Class Initialized
DEBUG - 2023-07-26 13:24:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:24:08 --> Database Driver Class Initialized
INFO - 2023-07-26 13:24:08 --> Model "Admin_model" initialized
INFO - 2023-07-26 13:24:08 --> Model "Student_model" initialized
INFO - 2023-07-26 13:24:08 --> Model "Teacher_model" initialized
INFO - 2023-07-26 13:24:08 --> File loaded: C:\xampp\htdocs\Project\application\views\admin/teachers_dashboard.php
INFO - 2023-07-26 13:24:08 --> Final output sent to browser
DEBUG - 2023-07-26 13:24:08 --> Total execution time: 0.0371
INFO - 2023-07-26 13:24:17 --> Config Class Initialized
INFO - 2023-07-26 13:24:17 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:24:17 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:24:17 --> Utf8 Class Initialized
INFO - 2023-07-26 13:24:17 --> URI Class Initialized
DEBUG - 2023-07-26 13:24:17 --> No URI present. Default controller set.
INFO - 2023-07-26 13:24:17 --> Router Class Initialized
INFO - 2023-07-26 13:24:17 --> Output Class Initialized
INFO - 2023-07-26 13:24:17 --> Security Class Initialized
DEBUG - 2023-07-26 13:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:24:17 --> Input Class Initialized
INFO - 2023-07-26 13:24:17 --> Language Class Initialized
INFO - 2023-07-26 13:24:17 --> Loader Class Initialized
INFO - 2023-07-26 13:24:17 --> Helper loaded: url_helper
INFO - 2023-07-26 13:24:17 --> Helper loaded: form_helper
INFO - 2023-07-26 13:24:17 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:24:17 --> Controller Class Initialized
INFO - 2023-07-26 13:24:17 --> Database Driver Class Initialized
INFO - 2023-07-26 13:24:17 --> Model "Student_model" initialized
DEBUG - 2023-07-26 13:24:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:24:17 --> File loaded: C:\xampp\htdocs\Project\application\views\register.php
INFO - 2023-07-26 13:24:17 --> Final output sent to browser
DEBUG - 2023-07-26 13:24:17 --> Total execution time: 0.0327
INFO - 2023-07-26 13:24:22 --> Config Class Initialized
INFO - 2023-07-26 13:24:22 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:24:22 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:24:22 --> Utf8 Class Initialized
INFO - 2023-07-26 13:24:22 --> URI Class Initialized
INFO - 2023-07-26 13:24:22 --> Router Class Initialized
INFO - 2023-07-26 13:24:22 --> Output Class Initialized
INFO - 2023-07-26 13:24:22 --> Security Class Initialized
DEBUG - 2023-07-26 13:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:24:22 --> Input Class Initialized
INFO - 2023-07-26 13:24:22 --> Language Class Initialized
INFO - 2023-07-26 13:24:22 --> Loader Class Initialized
INFO - 2023-07-26 13:24:22 --> Helper loaded: url_helper
INFO - 2023-07-26 13:24:22 --> Helper loaded: form_helper
INFO - 2023-07-26 13:24:22 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:24:22 --> Controller Class Initialized
INFO - 2023-07-26 13:24:22 --> Database Driver Class Initialized
INFO - 2023-07-26 13:24:22 --> Model "Auth_model" initialized
DEBUG - 2023-07-26 13:24:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 13:24:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:24:22 --> File loaded: C:\xampp\htdocs\Project\application\views\login.php
INFO - 2023-07-26 13:24:22 --> Final output sent to browser
DEBUG - 2023-07-26 13:24:22 --> Total execution time: 0.0261
INFO - 2023-07-26 13:24:32 --> Config Class Initialized
INFO - 2023-07-26 13:24:32 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:24:32 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:24:32 --> Utf8 Class Initialized
INFO - 2023-07-26 13:24:32 --> URI Class Initialized
INFO - 2023-07-26 13:24:32 --> Router Class Initialized
INFO - 2023-07-26 13:24:32 --> Output Class Initialized
INFO - 2023-07-26 13:24:32 --> Security Class Initialized
DEBUG - 2023-07-26 13:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:24:32 --> Input Class Initialized
INFO - 2023-07-26 13:24:32 --> Language Class Initialized
INFO - 2023-07-26 13:24:32 --> Loader Class Initialized
INFO - 2023-07-26 13:24:32 --> Helper loaded: url_helper
INFO - 2023-07-26 13:24:32 --> Helper loaded: form_helper
INFO - 2023-07-26 13:24:32 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:24:32 --> Controller Class Initialized
INFO - 2023-07-26 13:24:32 --> Database Driver Class Initialized
INFO - 2023-07-26 13:24:32 --> Model "Auth_model" initialized
DEBUG - 2023-07-26 13:24:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 13:24:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:24:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-07-26 13:24:32 --> File loaded: C:\xampp\htdocs\Project\application\views\login.php
INFO - 2023-07-26 13:24:32 --> Final output sent to browser
DEBUG - 2023-07-26 13:24:32 --> Total execution time: 0.0395
INFO - 2023-07-26 13:24:39 --> Config Class Initialized
INFO - 2023-07-26 13:24:39 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:24:39 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:24:39 --> Utf8 Class Initialized
INFO - 2023-07-26 13:24:39 --> URI Class Initialized
INFO - 2023-07-26 13:24:39 --> Router Class Initialized
INFO - 2023-07-26 13:24:39 --> Output Class Initialized
INFO - 2023-07-26 13:24:39 --> Security Class Initialized
DEBUG - 2023-07-26 13:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:24:39 --> Input Class Initialized
INFO - 2023-07-26 13:24:39 --> Language Class Initialized
INFO - 2023-07-26 13:24:39 --> Loader Class Initialized
INFO - 2023-07-26 13:24:39 --> Helper loaded: url_helper
INFO - 2023-07-26 13:24:39 --> Helper loaded: form_helper
INFO - 2023-07-26 13:24:39 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:24:39 --> Controller Class Initialized
INFO - 2023-07-26 13:24:39 --> Database Driver Class Initialized
INFO - 2023-07-26 13:24:39 --> Model "Auth_model" initialized
DEBUG - 2023-07-26 13:24:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 13:24:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:24:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-07-26 13:24:39 --> File loaded: C:\xampp\htdocs\Project\application\views\login.php
INFO - 2023-07-26 13:24:39 --> Final output sent to browser
DEBUG - 2023-07-26 13:24:39 --> Total execution time: 0.0412
INFO - 2023-07-26 13:24:44 --> Config Class Initialized
INFO - 2023-07-26 13:24:44 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:24:44 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:24:44 --> Utf8 Class Initialized
INFO - 2023-07-26 13:24:44 --> URI Class Initialized
INFO - 2023-07-26 13:24:44 --> Router Class Initialized
INFO - 2023-07-26 13:24:44 --> Output Class Initialized
INFO - 2023-07-26 13:24:44 --> Security Class Initialized
DEBUG - 2023-07-26 13:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:24:44 --> Input Class Initialized
INFO - 2023-07-26 13:24:44 --> Language Class Initialized
INFO - 2023-07-26 13:24:44 --> Loader Class Initialized
INFO - 2023-07-26 13:24:44 --> Helper loaded: url_helper
INFO - 2023-07-26 13:24:44 --> Helper loaded: form_helper
INFO - 2023-07-26 13:24:44 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:24:44 --> Controller Class Initialized
INFO - 2023-07-26 13:24:44 --> Database Driver Class Initialized
INFO - 2023-07-26 13:24:44 --> Model "Auth_model" initialized
DEBUG - 2023-07-26 13:24:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 13:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:24:44 --> File loaded: C:\xampp\htdocs\Project\application\views\login.php
INFO - 2023-07-26 13:24:44 --> Final output sent to browser
DEBUG - 2023-07-26 13:24:44 --> Total execution time: 0.0312
INFO - 2023-07-26 13:25:03 --> Config Class Initialized
INFO - 2023-07-26 13:25:03 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:25:03 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:25:03 --> Utf8 Class Initialized
INFO - 2023-07-26 13:25:03 --> URI Class Initialized
INFO - 2023-07-26 13:25:03 --> Router Class Initialized
INFO - 2023-07-26 13:25:03 --> Output Class Initialized
INFO - 2023-07-26 13:25:03 --> Security Class Initialized
DEBUG - 2023-07-26 13:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:25:03 --> Input Class Initialized
INFO - 2023-07-26 13:25:03 --> Language Class Initialized
INFO - 2023-07-26 13:25:03 --> Loader Class Initialized
INFO - 2023-07-26 13:25:03 --> Helper loaded: url_helper
INFO - 2023-07-26 13:25:03 --> Helper loaded: form_helper
INFO - 2023-07-26 13:25:03 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:25:03 --> Controller Class Initialized
INFO - 2023-07-26 13:25:03 --> Database Driver Class Initialized
INFO - 2023-07-26 13:25:03 --> Model "Auth_model" initialized
DEBUG - 2023-07-26 13:25:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-07-26 13:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:25:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2023-07-26 13:25:03 --> Config Class Initialized
INFO - 2023-07-26 13:25:03 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:25:03 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:25:03 --> Utf8 Class Initialized
INFO - 2023-07-26 13:25:03 --> URI Class Initialized
INFO - 2023-07-26 13:25:03 --> Router Class Initialized
INFO - 2023-07-26 13:25:03 --> Output Class Initialized
INFO - 2023-07-26 13:25:03 --> Security Class Initialized
DEBUG - 2023-07-26 13:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:25:03 --> Input Class Initialized
INFO - 2023-07-26 13:25:03 --> Language Class Initialized
INFO - 2023-07-26 13:25:03 --> Loader Class Initialized
INFO - 2023-07-26 13:25:03 --> Helper loaded: url_helper
INFO - 2023-07-26 13:25:03 --> Helper loaded: form_helper
INFO - 2023-07-26 13:25:03 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:25:03 --> Controller Class Initialized
DEBUG - 2023-07-26 13:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:25:03 --> Database Driver Class Initialized
INFO - 2023-07-26 13:25:03 --> Model "User_model" initialized
INFO - 2023-07-26 13:25:03 --> Model "Student_model" initialized
INFO - 2023-07-26 13:25:03 --> File loaded: C:\xampp\htdocs\Project\application\views\dashboard.php
INFO - 2023-07-26 13:25:03 --> Final output sent to browser
DEBUG - 2023-07-26 13:25:03 --> Total execution time: 0.0403
INFO - 2023-07-26 13:25:16 --> Config Class Initialized
INFO - 2023-07-26 13:25:16 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:25:16 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:25:16 --> Utf8 Class Initialized
INFO - 2023-07-26 13:25:16 --> URI Class Initialized
INFO - 2023-07-26 13:25:16 --> Router Class Initialized
INFO - 2023-07-26 13:25:16 --> Output Class Initialized
INFO - 2023-07-26 13:25:16 --> Security Class Initialized
DEBUG - 2023-07-26 13:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:25:16 --> Input Class Initialized
INFO - 2023-07-26 13:25:16 --> Language Class Initialized
INFO - 2023-07-26 13:25:16 --> Loader Class Initialized
INFO - 2023-07-26 13:25:16 --> Helper loaded: url_helper
INFO - 2023-07-26 13:25:16 --> Helper loaded: form_helper
INFO - 2023-07-26 13:25:16 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:25:16 --> Controller Class Initialized
DEBUG - 2023-07-26 13:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:25:16 --> Database Driver Class Initialized
INFO - 2023-07-26 13:25:16 --> Model "User_model" initialized
INFO - 2023-07-26 13:25:16 --> Upload Class Initialized
INFO - 2023-07-26 13:25:16 --> Model "Student_model" initialized
INFO - 2023-07-26 13:25:16 --> Config Class Initialized
INFO - 2023-07-26 13:25:16 --> Hooks Class Initialized
DEBUG - 2023-07-26 13:25:16 --> UTF-8 Support Enabled
INFO - 2023-07-26 13:25:16 --> Utf8 Class Initialized
INFO - 2023-07-26 13:25:16 --> URI Class Initialized
INFO - 2023-07-26 13:25:16 --> Router Class Initialized
INFO - 2023-07-26 13:25:16 --> Output Class Initialized
INFO - 2023-07-26 13:25:16 --> Security Class Initialized
DEBUG - 2023-07-26 13:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-26 13:25:16 --> Input Class Initialized
INFO - 2023-07-26 13:25:16 --> Language Class Initialized
INFO - 2023-07-26 13:25:16 --> Loader Class Initialized
INFO - 2023-07-26 13:25:16 --> Helper loaded: url_helper
INFO - 2023-07-26 13:25:16 --> Helper loaded: form_helper
INFO - 2023-07-26 13:25:16 --> Form Validation Class Initialized
DEBUG - 2023-07-26 13:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-26 13:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-26 13:25:16 --> Controller Class Initialized
DEBUG - 2023-07-26 13:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-26 13:25:16 --> Database Driver Class Initialized
INFO - 2023-07-26 13:25:16 --> Model "User_model" initialized
INFO - 2023-07-26 13:25:16 --> Model "Student_model" initialized
INFO - 2023-07-26 13:25:16 --> File loaded: C:\xampp\htdocs\Project\application\views\dashboard.php
INFO - 2023-07-26 13:25:16 --> Final output sent to browser
DEBUG - 2023-07-26 13:25:16 --> Total execution time: 0.0549
