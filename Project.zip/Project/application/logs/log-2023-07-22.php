<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-22 13:16:50 --> The upload path does not appear to be valid.
