<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-24 18:49:04 --> The upload path does not appear to be valid.
ERROR - 2023-07-24 18:53:01 --> The upload path does not appear to be valid.
ERROR - 2023-07-24 19:02:25 --> Severity: Error --> Call to undefined method Student_model::update_image() C:\xampp\htdocs\Project\application\controllers\Dashboard.php 136
ERROR - 2023-07-24 19:16:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Project\application\controllers\Dashboard.php 131
ERROR - 2023-07-24 19:16:03 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\Project\application\views\dashboard.php 12
ERROR - 2023-07-24 19:21:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Project\application\controllers\Dashboard.php 131
ERROR - 2023-07-24 19:21:26 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\Project\application\views\dashboard.php 12
ERROR - 2023-07-24 19:23:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Project\application\controllers\Dashboard.php 130
ERROR - 2023-07-24 19:23:36 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\Project\application\views\dashboard.php 12
ERROR - 2023-07-24 19:26:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Project\application\controllers\Dashboard.php 130
ERROR - 2023-07-24 19:26:25 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\Project\application\views\dashboard.php 12
ERROR - 2023-07-24 20:10:22 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-24 20:11:21 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-24 20:44:18 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-24 20:44:18 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-24 20:44:18 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-24 20:44:18 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-24 20:44:18 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-24 20:44:18 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-24 20:44:18 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-24 20:44:18 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-24 20:44:18 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-24 20:44:18 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-24 20:44:18 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-24 20:44:18 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-24 20:44:18 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-24 20:44:18 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-24 20:44:18 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-24 20:44:18 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-24 20:44:18 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-24 20:44:18 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-24 20:59:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-24 20:59:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-24 20:59:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-24 20:59:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-24 20:59:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-24 20:59:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-24 20:59:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-24 20:59:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-24 20:59:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-24 20:59:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-24 20:59:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-24 20:59:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-24 20:59:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-24 20:59:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-24 20:59:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-24 20:59:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-24 20:59:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-24 20:59:31 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-24 21:15:21 --> 404 Page Not Found: Admin/login
