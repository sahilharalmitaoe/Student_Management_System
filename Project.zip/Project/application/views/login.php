<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            max-width: 400px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
        }

        h2 {
            text-align: center;
        }

        form p {
            margin: 0;
            padding: 10px 0;
        }

        form label {
            display: inline-block;
            width: 100px;
        }

        form input[type="email"],
        form input[type="password"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        form input[type="submit"] {
            background-color: #4CAF50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        form input[type="submit"]:hover {
            background-color: #45a049;
        }

        form p.error {
            color: red;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <?php echo validation_errors('<p class="error">', '</p>'); ?>
        <?php if (isset($error_message)) echo '<p class="error">' . $error_message . '</p>'; ?>
        <?php echo form_open('auth/login'); ?>
            <p>
                <label for="email">Email:</label>
                <input type="email" name="email" value="<?php echo set_value('email'); ?>" required>
            </p>
            <p>
                <label for="password">Password:</label>
                <input type="password" name="password" required>
            </p>
            <p>
                <input type="submit" name="login" value="Login">
            </p>
            <p>
    <a href="<?php echo site_url('auth/admin_login'); ?>">Admin Login</a>
</p>
        <?php echo form_close(); ?>
    </div>
</body>
</html>
