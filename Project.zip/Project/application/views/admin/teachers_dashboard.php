<!DOCTYPE html>
<html>
<head>
    <title>Teachers Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2 class="text-primary">Teachers Dashboard</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Course</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($teachers as $teacher): ?>
                    <tr>
                        <td><?php echo $teacher->id; ?></td>
                        <td><?php echo $teacher->first_name; ?></td>
                        <td><?php echo $teacher->last_name; ?></td>
                        <td><?php echo $teacher->email; ?></td>
                        <td><?php echo $teacher->address; ?></td>
                        <td><?php echo $teacher->phone; ?></td>
                        <td><?php echo $teacher->course; ?></td>
                        <td>
                            <a href="<?php echo site_url('admin/edit_teacher/'.$teacher->email); ?>" class="btn btn-primary btn-sm">Edit</a>
                            <a href="<?php echo site_url('admin/delete_teacher/'.$teacher->email); ?>" class="btn btn-danger btn-sm">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="container mt-4">
    <h2 class="text-primary">Import Teachers from CSV</h2>
    <form method="post" action="<?php echo site_url('admin/import_csv'); ?>" enctype="multipart/form-data">

        <input type="file" name="csv_file" required>
        <button type="submit">Import CSV</button>
    </form>
    <!-- <a href="" class="btn btn-success">Add Teacher</a> -->
</div>

</body>
</html>
