<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_login extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('Admin_model'); 
    }

    public function index() {
        
        $this->load->view('admin/login');
    }

    public function login() {
        if ($this->input->post()) {
            $email = $this->input->post('email');
            $password = $this->input->post('password');

            
            if ($this->Admin_model->check_admin_credentials($email, $password)) {
                
                $this->session->set_userdata('admin_logged_in', true);
                redirect('admin/dashboard'); 
            } else {
                
                $data['error'] = 'Invalid email or password';
                $this->load->view('admin/login', $data);
            }
        } else {
            
            $this->load->view('admin/login');
        }
    }

    public function logout() {
       
        $this->session->unset_userdata('admin_logged_in');
        redirect('admin/login');
    }
}
