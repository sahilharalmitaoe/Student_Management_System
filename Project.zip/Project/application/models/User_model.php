<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    
    public function get_user_details($user_id) {
        $this->db->where('id', $user_id);
        $query = $this->db->get('students'); 

        if ($query->num_rows() == 1) {
            return $query->row_array();
        }

        return false;
    }
    
    public function get_admin_by_email($email, $password) {
        $this->db->where('email', $email);
        $this->db->where('password', $password);
        $this->db->where('is_admin', 1);
        $query = $this->db->get('students');

        if ($query->num_rows() == 1) {
            return true;
        } else {
            return false;
        }
    }
    
    public function update_user_details($user_id, $data) {
        
        $this->db->where('id', $user_id);
        $this->db->update('students', $data);
    }

    public function delete_user($user_id) {
        
        $this->db->where('id', $user_id);
        $this->db->delete('students');
    }
    public function get_student_by_id($user_id) {
        $this->db->where('id', $user_id);
        $query = $this->db->get('students');
        return $query->row();
    }
    public function get_all_users() {
        $query = $this->db->get('students');
        return $query->result_array();
    }
    public function get_all_teachers() {
        $query = $this->db->get('teachers'); 
        return $query->result_array();
    }
}

?>
