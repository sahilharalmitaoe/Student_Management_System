<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-21 08:24:00 --> Severity: Error --> Call to undefined method Student_model::get_user_by_id() C:\xampp\htdocs\Project\application\controllers\Dashboard.php 39
ERROR - 2023-07-21 08:25:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 13
ERROR - 2023-07-21 08:25:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 17
ERROR - 2023-07-21 08:25:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 21
ERROR - 2023-07-21 08:25:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 25
ERROR - 2023-07-21 08:25:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 29
ERROR - 2023-07-21 08:25:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 35
ERROR - 2023-07-21 08:25:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 36
ERROR - 2023-07-21 08:29:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 13
ERROR - 2023-07-21 08:29:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 17
ERROR - 2023-07-21 08:29:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 21
ERROR - 2023-07-21 08:29:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 25
ERROR - 2023-07-21 08:29:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 29
ERROR - 2023-07-21 08:29:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 35
ERROR - 2023-07-21 08:29:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 36
ERROR - 2023-07-21 08:29:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 13
ERROR - 2023-07-21 08:29:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 17
ERROR - 2023-07-21 08:29:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 21
ERROR - 2023-07-21 08:29:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 25
ERROR - 2023-07-21 08:29:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 29
ERROR - 2023-07-21 08:29:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 35
ERROR - 2023-07-21 08:29:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 36
ERROR - 2023-07-21 08:32:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 44
ERROR - 2023-07-21 08:32:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 48
ERROR - 2023-07-21 08:32:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 52
ERROR - 2023-07-21 08:32:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 56
ERROR - 2023-07-21 08:32:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 60
ERROR - 2023-07-21 08:32:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 66
ERROR - 2023-07-21 08:32:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 67
ERROR - 2023-07-21 08:33:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 44
ERROR - 2023-07-21 08:33:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 48
ERROR - 2023-07-21 08:33:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 52
ERROR - 2023-07-21 08:33:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 56
ERROR - 2023-07-21 08:33:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 60
ERROR - 2023-07-21 08:33:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 66
ERROR - 2023-07-21 08:33:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 67
ERROR - 2023-07-21 08:33:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 44
ERROR - 2023-07-21 08:33:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 48
ERROR - 2023-07-21 08:33:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 52
ERROR - 2023-07-21 08:33:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 56
ERROR - 2023-07-21 08:33:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 60
ERROR - 2023-07-21 08:33:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 66
ERROR - 2023-07-21 08:33:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 67
ERROR - 2023-07-21 08:42:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:42:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:42:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:42:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:42:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:42:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:42:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:42:49 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:42:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:42:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:42:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:42:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:42:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:42:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:42:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:42:50 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:43:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:43:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:43:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:43:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:43:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:43:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:43:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:43:31 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:43:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:43:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:43:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:43:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:43:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:43:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:43:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:43:32 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:43:33 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:43:34 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:43:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:43:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:43:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:43:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:43:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:43:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:43:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:43:35 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:45:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:45:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:45:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:45:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:45:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:45:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:45:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:45:20 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:45:21 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:45:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:45:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:45:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:45:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:45:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:45:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:45:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:45:22 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:57:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:57:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:57:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:57:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:57:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:57:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:57:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:57:18 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:57:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:57:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:57:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:57:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:57:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:57:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:57:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:57:19 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 08:57:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 08:57:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 08:57:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 08:57:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 08:57:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 08:57:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 08:57:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 08:57:24 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 09:02:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 09:02:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 09:02:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 09:02:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 09:02:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 09:02:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 09:02:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 09:02:53 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 09:06:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 09:06:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 09:06:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 09:06:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 09:06:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 09:06:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 09:06:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 09:06:15 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 09:06:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 18
ERROR - 2023-07-21 09:06:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 22
ERROR - 2023-07-21 09:06:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 26
ERROR - 2023-07-21 09:06:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 30
ERROR - 2023-07-21 09:06:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 34
ERROR - 2023-07-21 09:06:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 40
ERROR - 2023-07-21 09:06:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 41
ERROR - 2023-07-21 09:06:16 --> Severity: Notice --> Undefined variable: show_change_password_form C:\xampp\htdocs\Project\application\views\edit.php 49
ERROR - 2023-07-21 09:09:44 --> Severity: Error --> Call to undefined method User_model::get_user_by_id() C:\xampp\htdocs\Project\application\controllers\Dashboard.php 39
ERROR - 2023-07-21 09:10:41 --> Query error: Table 'codeigniter.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `id` = '21'
ERROR - 2023-07-21 09:12:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 47
ERROR - 2023-07-21 09:12:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 51
ERROR - 2023-07-21 09:12:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 55
ERROR - 2023-07-21 09:12:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 59
ERROR - 2023-07-21 09:12:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 63
ERROR - 2023-07-21 09:12:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 69
ERROR - 2023-07-21 09:12:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Project\application\views\edit.php 70
ERROR - 2023-07-21 09:16:54 --> Query error: Table 'codeigniter.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `id` = '21'
ERROR - 2023-07-21 09:17:10 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 09:17:27 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 09:19:43 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 09:22:41 --> 404 Page Not Found: Dashboard/save_details
ERROR - 2023-07-21 09:23:01 --> 404 Page Not Found: Dashboard/save_details
ERROR - 2023-07-21 09:26:13 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:19:28 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:26:36 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:26:46 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:27:15 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:27:16 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:27:16 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:27:16 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:27:16 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:27:16 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:27:16 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:27:17 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:27:17 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:27:17 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:27:17 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:27:17 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:27:17 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:28:38 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:32:33 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:33:27 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:38:06 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\Project\application\views\dashboard.php 90
ERROR - 2023-07-21 10:41:48 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\Project\application\views\dashboard.php 91
ERROR - 2023-07-21 10:41:51 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\Project\application\views\dashboard.php 91
ERROR - 2023-07-21 10:42:06 --> The upload path does not appear to be valid.
ERROR - 2023-07-21 10:42:06 --> Severity: Notice --> Undefined property: stdClass::$image C:\xampp\htdocs\Project\application\views\dashboard.php 91
ERROR - 2023-07-21 10:43:18 --> The upload path does not appear to be valid.
ERROR - 2023-07-21 10:44:45 --> The upload path does not appear to be valid.
ERROR - 2023-07-21 10:48:06 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:48:48 --> 404 Page Not Found: Dashboard/save
ERROR - 2023-07-21 10:50:38 --> The upload path does not appear to be valid.
ERROR - 2023-07-21 10:52:58 --> 404 Page Not Found: Auth/admin_login
ERROR - 2023-07-21 11:28:35 --> Severity: Error --> Call to undefined method User_model::get_admin_by_email() C:\xampp\htdocs\Project\application\controllers\Auth.php 25
ERROR - 2023-07-21 11:31:13 --> Query error: Unknown column 'is_admin' in 'where clause' - Invalid query: SELECT *
FROM `students`
WHERE `email` = 'admin@gmail.com'
AND `is_admin` = 1
ERROR - 2023-07-21 11:34:49 --> 404 Page Not Found: Auth/admin_dashboard
ERROR - 2023-07-21 11:35:54 --> The upload path does not appear to be valid.
ERROR - 2023-07-21 11:54:34 --> Severity: Notice --> Undefined variable: admin C:\xampp\htdocs\Project\application\views\admin_dashboard.php 13
ERROR - 2023-07-21 11:54:34 --> Severity: Notice --> Undefined variable: admin C:\xampp\htdocs\Project\application\views\admin_dashboard.php 13
ERROR - 2023-07-21 11:54:34 --> Severity: Notice --> Undefined variable: admin C:\xampp\htdocs\Project\application\views\admin_dashboard.php 14
ERROR - 2023-07-21 11:56:23 --> Severity: Error --> Call to undefined method User_model::get_all_users() C:\xampp\htdocs\Project\application\controllers\Admin_dashboard.php 20
ERROR - 2023-07-21 12:19:38 --> 404 Page Not Found: Admin_dashboard/teachers
ERROR - 2023-07-21 12:21:05 --> 404 Page Not Found: Admin_dashboard/teachers
ERROR - 2023-07-21 12:21:06 --> 404 Page Not Found: Admin_dashboard/teachers
ERROR - 2023-07-21 12:21:06 --> 404 Page Not Found: Admin_dashboard/teachers
ERROR - 2023-07-21 12:21:06 --> 404 Page Not Found: Admin_dashboard/teachers
ERROR - 2023-07-21 12:21:29 --> 404 Page Not Found: Admin_dashboard/teachers
ERROR - 2023-07-21 12:23:04 --> 404 Page Not Found: Admin_dashboard/teachers
ERROR - 2023-07-21 12:23:05 --> 404 Page Not Found: Admin_dashboard/teachers
ERROR - 2023-07-21 12:23:05 --> 404 Page Not Found: Admin_dashboard/teachers
ERROR - 2023-07-21 12:23:06 --> 404 Page Not Found: Admin_dashboard/teachers
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: phone C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 21
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 25
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 26
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: phone C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 21
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 25
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 26
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: phone C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 21
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 25
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 26
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: phone C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 21
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 25
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 26
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: phone C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 21
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 25
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 26
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: phone C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 21
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 25
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 26
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: phone C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 21
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 25
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 26
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: phone C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 21
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 25
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 26
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: phone C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 21
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 25
ERROR - 2023-07-21 12:23:11 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 26
ERROR - 2023-07-21 12:26:05 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:26:05 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:26:05 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:26:05 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:26:05 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:26:05 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:26:05 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:26:05 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:26:05 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:26:05 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:26:05 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:26:05 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:26:05 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:26:05 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:26:05 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:26:05 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:26:05 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:26:05 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:37 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:37 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:37 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:37 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:37 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:37 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:37 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:37 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:37 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:37 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:37 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:37 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:37 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:37 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:37 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:37 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:37 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:37 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:38 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:38 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:38 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:38 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:38 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:38 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:38 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:38 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:38 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:38 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:38 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:38 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:38 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:38 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:38 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:38 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:38 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:38 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:27:39 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
ERROR - 2023-07-21 12:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 71
ERROR - 2023-07-21 12:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Project\application\views\teachers_dashboard.php 72
