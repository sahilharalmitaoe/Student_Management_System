<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">    
</head>
<body>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6">
                <h2 class="text-primary">Welcome to Dashboard</h2>
                <h3 class="mt-3">User Details:</h3>
                <?php if ($student): ?>
                    <p><strong>Name:</strong> <?php echo $student->first_name . ' ' . $student->last_name; ?></p>
                    <p><strong>Email:</strong> <?php echo $student->email; ?></p>
                    <p><strong>Phone:</strong> <?php echo $student->phone; ?></p>
                    <p><strong>Address:</strong> <?php echo $student->address; ?></p>
                    <p><strong>Gender:</strong> <?php echo ucfirst($student->gender); ?></p>
                    
                    <h3 class="mt-4">Upload Image</h3>
                    <?php echo form_open_multipart('dashboard/upload_image'); ?>
                        <div class="form-group">
                            <label for="userfile">Choose Image:</label>
                            <input type="file" name="userfile" class="form-control-file" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Upload</button>
                    <?php echo form_close(); ?>

                    <?php if (isset($upload_error) && $upload_error): ?>
                        <p class="text-danger"><?php echo $upload_error; ?></p>
                    <?php endif; ?>

                    <a href="<?php echo site_url('dashboard/edit'); ?>" class="btn btn-primary mt-4">Edit Details</a>
                    <a href="<?php echo site_url('dashboard/change_password'); ?>" class="btn btn-primary mt-4">Change Password</a>
                    <a href="<?php echo site_url('auth/logout'); ?>" class="btn btn-danger mt-4">Logout</a>
                <?php else: ?>
                    <p class="text-danger">User details not found.</p>
                <?php endif; ?>
            </div>
            <div class="col-md-6">
                <?php if (isset($student->image) && !empty($student->image)): ?>
                    <h3 class="mt-4">Uploaded Image</h3>
                    <!-- Display the image using an img tag -->
                    <img src="<?php echo base_url('uploads/' . $student->image); ?>" alt="User Image" class="img-fluid img-thumbnail" style="max-width: 200px;">
                <?php else: ?>
                    <h3 class="mt-4">No Image Uploaded</h3>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
