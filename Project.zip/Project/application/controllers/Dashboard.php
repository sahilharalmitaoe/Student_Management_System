<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('User_model'); 
        if (!$this->session->userdata('user_id')) {
            redirect('auth');
        }
    }
    public function index() {
        if ($this->session->userdata('user_id')) {
            $this->load->model('student_model');
            $user_id = $this->session->userdata('user_id');
            $data['student'] = $this->student_model->get_student_by_id($user_id);
            $this->load->view('dashboard', $data);
        } else {
            redirect('auth/login');
        }
    }
    

  

    public function edit() {
        $this->load->model('User_model');
        $user_id = $this->session->userdata('user_id');
        $data['user'] = $this->User_model->get_user_details($user_id);
    
        if ($data['user']) {
            $data['show_change_password_form'] = true;
        } else {
            $data['error_message'] = 'User not found.';
            $data['show_change_password_form'] = false;
        }
    
        $this->load->view('edit', $data);
    }
    
    
    public function save_details() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('phone', 'Phone', 'trim|required');
        $this->form_validation->set_rules('address', 'Address', 'trim|required');
        $this->form_validation->set_rules('gender', 'Gender', 'trim|required');
    
        if ($this->form_validation->run() == FALSE) {
            $this->edit(); 
        } else {
            $user_id = $this->session->userdata('user_id');
            $data = array(
                'first_name' => $this->input->post('first_name'),
                'last_name' => $this->input->post('last_name'),
                'email' => $this->input->post('email'),
                'phone' => $this->input->post('phone'),
                'address' => $this->input->post('address'),
                'gender' => $this->input->post('gender')
            );
    
            $this->load->model('user_model');
            $this->user_model->update_user_details($user_id, $data);
    
            redirect('dashboard');
        }
    }
    
    public function change_password() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('current_password', 'Current Password', 'trim|required');
        $this->form_validation->set_rules('new_password', 'New Password', 'trim|required|min_length[6]');
        $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|matches[new_password]');

        if ($this->form_validation->run() == FALSE) {
            $this->edit();
        } else {
            $user_id = $this->session->userdata('user_id');
            $current_password = $this->input->post('current_password');
            $new_password = $this->input->post('new_password');

            $this->load->model('user_model');
            $user = $this->user_model->get_user_by_id($user_id);

            if (password_verify($current_password, $user['password'])) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $data = array('password' => $hashed_password); 
                $this->user_model->update_user_details($user_id, $data);
                redirect('dashboard');
            } else {
                $data['error_message'] = 'Invalid current password.';
                $this->edit($data);
            }
        }
    }

    



public function upload_image()
{
    $config['upload_path'] = './uploads/';
    $config['allowed_types'] = 'gif|jpg|jpeg|png';
    $config['max_size'] = 2048;
    $config['encrypt_name'] = TRUE;

    $this->load->library('upload', $config);

    if (!$this->upload->do_upload('userfile')) {
        $data['upload_error'] = $this->upload->display_errors();
    } else {
        $upload_data = $this->upload->data();
        $image_name = $upload_data['file_name'];

        $student_id = $this->session->userdata('user_id');
        $this->load->model('Student_model');
        $this->Student_model->update_image($student_id, $image_name);

        
        redirect('dashboard');
    }
    $this->index();
}




    public function delete() {
        
        $user_id = $this->session->userdata('user_id');

        
        $this->User_model->delete_user($user_id);

        $this->session->unset_userdata('user_id');

    
        redirect('register');
    }
}
?>
