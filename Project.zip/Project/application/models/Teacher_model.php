<?php
class Teacher_model extends CI_Model {
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

   
    public function get_all_teachers() {
        return $this->db->get('teachers')->result();
    }
    public function get_teacher_by_email($email) {
        return $this->db->get_where('teachers', array('email' => $email))->row();
    }

    public function insert_teacher($data) {
        unset($data['id']);
        $this->db->insert('teachers', $data);
    }
    
    public function update_teacher($teacher_email, $data) {
        $this->db->where('email', $teacher_email);
        $this->db->update('teachers', $data);
    }
    
    public function delete_teacher($email) {
        $this->db->where('email', $email);
        $this->db->delete('teachers');
    }
    public function update_teacher_by_email($email, $data) {
       
        $this->db->where('email', $email);
        $this->db->update('teachers', $data);
    }
    
    

    
    
    
    
    
    



}
