<!DOCTYPE html>
<html>
<head>
    <title>Edit Details</title>
    
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        h2 {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            margin: 0;
        }

        form {
            width: 400px;
            margin: 20px auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        label {
            display: inline-block;
            width: 100px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        select {
            width: 200px;
            padding: 5px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        select {
            width: 215px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            text-decoration: none;
            cursor: pointer;
            border-radius: 5px;
        }

        .error-message {
            color: red;
        }
    </style>
</head>
<body>
    <h2>Edit Details and Change Password</h2>
    <?php echo validation_errors('<p class="error-message">', '</p>'); ?>
    <?php if (isset($error_message)) echo '<p class="error-message">' . $error_message . '</p>'; ?>

    <?php echo form_open('dashboard/save_details'); ?>
        <?php if (isset($user)): ?>
            <label for="first_name">First Name:</label>
            <input type="text" name="first_name" value="<?php echo $user['first_name']; ?>" required><br>

            <label for="last_name">Last Name:</label>
            <input type="text" name="last_name" value="<?php echo $user['last_name']; ?>" required><br>

            <label for="email">Email:</label>
            <input type="email" name="email" value="<?php echo $user['email']; ?>" required><br>

            <label for="phone">Phone:</label>
            <input type="text" name="phone" value="<?php echo $user['phone']; ?>" required><br>

            <label for="address">Address:</label>
            <input type="text" name="address" value="<?php echo $user['address']; ?>" required><br>

            <label for="gender">Gender:</label>
            <select name="gender" required>
                <option value="">Select Gender</option>
                <option value="male" <?php echo ($user['gender'] === 'male') ? 'selected' : ''; ?>>Male</option>
                <option value="female" <?php echo ($user['gender'] === 'female') ? 'selected' : ''; ?>>Female</option>
            </select><br>

        <?php else: ?>
            <p>User details not found.</p>
        <?php endif; ?>

        <h2>Change Password</h2>
        <?php echo validation_errors('<p class="error-message">', '</p>'); ?>
        <label for="current_password">Current Password:</label>
        <input type="password" name="current_password" required><br>

        <label for="new_password">New Password:</label>
        <input type="password" name="new_password" required><br>

        <label for="confirm_password">Confirm Password:</label>
        <input type="password" name="confirm_password" required><br>

        <input type="submit" name="save_details" value="Save and Change Password">
    <?php echo form_close(); ?>
</body>
</html>
