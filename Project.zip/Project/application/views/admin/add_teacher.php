<!-- views/admin/add_teacher.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Add Teacher</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2 class="text-primary">Add Teacher</h2>
        <form method="post" action="<?php echo base_url('admin_dashboard/add_teacher'); ?>">
            <label for="first_name">First Name:</label>
            <input type="text" name="first_name" required>
            <label for="last_name">Last Name:</label>
            <input type="text" name="last_name" required>
            <label for="email">Email:</label>
            <input type="email" name="email" required>
            <label for="phone">Phone:</label>
            <input type="text" name="phone" required>
            <label for="address">Address:</label>
            <input type="text" name="address" required>
            <label for="course">Course:</label>
            <input type="text" name="course" required>
            <button type="submit">Add Teacher</button>
        </form>
    </div>
</body>
</html>
