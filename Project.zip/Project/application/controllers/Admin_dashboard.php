<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_dashboard extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('Admin_model');
        $this->load->model('Student_model');
        $this->load->model('Teacher_model');
        
    }

    public function index() {
        if ($this->session->userdata('admin_logged_in')) {
            $this->load->model('Student_model'); // Load the Student_model
            $data['students'] = $this->Student_model->get_all_students();
            $this->load->view('admin/dashboard', $data);
        } else {
            redirect('admin/login');
        }
    }
    public function edit_student($id) {
        if ($this->session->userdata('admin_logged_in')) {
            $data['student'] = $this->Student_model->get_student_by_id($id);

            if ($this->input->post()) {
                
                $this->Student_model->update_student($id, $this->input->post());

                
                redirect('admin/dashboard');
            }

            $this->load->view('admin/edit_student', $data);
        } else {
            redirect('admin/login');
        }
    }

    public function delete_student($id) {
        if ($this->session->userdata('admin_logged_in')) {
            
            $this->Student_model->delete_student($id);

            
            redirect('admin/dashboard');
        } else {
            redirect('admin/login');
        }
    }
    public function update_student($student_id) {
        if ($this->session->userdata('admin_logged_in')) {
            $this->load->model('Student_model'); 
    
            
            $data = array(
                'first_name' => $this->input->post('first_name'),
                'last_name' => $this->input->post('last_name'),
                'email' => $this->input->post('email'),
                'phone' => $this->input->post('phone'),
                'address' => $this->input->post('address')
            );
            $this->Student_model->update_student($student_id, $data);
    
            
            redirect('admin_dashboard');
        } else {
            redirect('admin/login');
        }
    }
    public function teachers_dashboard() {
        $this->load->model('Teacher_model');
        $data['teachers'] = $this->Teacher_model->get_all_teachers();
        $this->load->view('admin/teachers_dashboard', $data);
    }
    public function edit_teacher($teacher_email) {
        $this->load->model('Teacher_model');
        $data['teacher_data'] = $this->Teacher_model->get_teacher_by_email($teacher_email);
        $this->load->view('admin/edit_teacher', $data);
    }
    
    public function update_teacher($teacher_email) {
        $this->load->model('Teacher_model');
        $data = array(
            'first_name' => $this->input->post('first_name'),
            'last_name' => $this->input->post('last_name'),
            'address' => $this->input->post('address'),
            'phone' => $this->input->post('phone'),
            'course' => $this->input->post('course')
        );
        $this->Teacher_model->update_teacher($teacher_email, $data);
        redirect('admin_dashboard/teachers_dashboard');
    }
    
    public function delete_teacher($teacher_email) {
        $this->load->model('Teacher_model');
        $this->Teacher_model->delete_teacher($teacher_email);
        redirect('admin_dashboard/teachers_dashboard');
    }
        
    public function import_csv() {
        
        $this->load->model('Teacher_model');
    
        
        if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] === UPLOAD_ERR_OK) {
            
            $csv_file = $_FILES['csv_file']['tmp_name'];
    
            
            if (($handle = fopen($csv_file, 'r')) !== false) {
                
                fgetcsv($handle);
    
                
                while (($data = fgetcsv($handle)) !== false) {
                    
                    $first_name = $data[0];
                    $last_name = $data[1];
                    $email = $data[2];
                    $address = $data[3];
                    $phone = $data[4];
                    $course = $data[5];
    
                    
                    $teacher_data = array(
                        'first_name' => $first_name,
                        'last_name' => $last_name,
                        'email' => $email,
                        'address' => $address,
                        'phone' => $phone,
                        'course' => $course
                    );
    
                    
                    $this->Teacher_model->insert_teacher($teacher_data);
                }
    
               
                fclose($handle);
    
                
                redirect('admin_dashboard/teachers_dashboard');
            } else {
                
                echo "Error: Unable to open the CSV file.";
            }
        } else {
            
            echo "Error: Please upload a CSV file.";
        }
    }

    
public function add_teacher() {
    
    $this->load->model('Teacher_model');

    
    if ($this->input->server('REQUEST_METHOD') === 'POST') {
        
        $first_name = $this->input->post('first_name');
        $last_name = $this->input->post('last_name');
        $email = $this->input->post('email');
        $phone = $this->input->post('phone');
        $address = $this->input->post('address');
        $course = $this->input->post('course');

        
        $teacher_data = array(
            'first_name' => $first_name,
            'last_name' => $last_name,
            'email' => $email,
            'address' => $address,
            'phone' => $phone,
            'course' => $course
        );

        
        $this->Teacher_model->insert_teacher($teacher_data);

        
        redirect('admin/teachers_dashboard');
    } else {
        
        $this->load->view('admin_dashboard/add_teacher');
    }
}

    
}
