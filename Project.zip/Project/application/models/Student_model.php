<?php
class Student_model extends CI_Model {
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function update_image($student_id, $image_filename) {
        $data = array(
            'image_filename' => $image_filename
        );
        $this->db->where('id', $student_id);
        $this->db->update('students', $data);
    }

    public function update_student($student_id, $data) {
        $this->db->where('id', $student_id);
        $this->db->update('students', $data);
    }
    
    public function insert_student($data) {
        $this->db->insert('students', $data);
        return $this->db->insert_id();
    }

    public function get_all_students() {
        $query = $this->db->get('students');
        return $query->result();
    }

    public function get_student_by_id($student_id) {
        $this->db->where('id', $student_id);
        $query = $this->db->get('students');
        return $query->row();
    }

    public function delete_student($student_id) {
        $this->db->where('id', $student_id);
        $this->db->delete('students');
    }
}

?>


