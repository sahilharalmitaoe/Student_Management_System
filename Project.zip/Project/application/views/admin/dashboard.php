<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2 class="text-primary">Welcome to Admin Dashboard</h2>
        <a href="<?php echo site_url('admin/logout'); ?>" class="btn btn-danger mt-4">Logout</a>
        <a href="<?php echo site_url('admin_dashboard/teachers_dashboard'); ?>" class="btn btn-primary mt-4">Teachers Dashboard</a>

        <h3 class="mt-4">Registered Students:</h3>
        <?php if (!empty($students)): ?>
            <table class="table table-bordered mt-3">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $student): ?>
                        <tr>
                            <td><?php echo $student->id; ?></td>
                            <td><?php echo $student->first_name . ' ' . $student->last_name; ?></td>
                            <td><?php echo $student->email; ?></td>
                            <td><?php echo $student->phone; ?></td>
                            <td><?php echo $student->address; ?></td>
                            <td>
                                <a href="<?php echo site_url('admin/edit_student/'.$student->id); ?>" class="btn btn-primary btn-sm">Edit</a>
                            </td>
                            <td>
                                <a href="<?php echo site_url('admin/delete_student/'.$student->id); ?>" class="btn btn-danger btn-sm">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No students found.</p>
        <?php endif; ?>
    </div>
</body>
</html>
