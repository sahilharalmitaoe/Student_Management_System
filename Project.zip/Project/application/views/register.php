<!DOCTYPE html>
<html>
<head>
    <title>Student Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
        }
        h2 {
            text-align: center;
        }
        form {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 3px;
            font-size: 16px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        p.error {
            color: red;
            margin: 0;
            margin-bottom: 10px;
        }
        p.login-link {
            text-align: center;
            margin-top: 15px;
        }

        p.login-link a {
            color: #4CAF50;
            text-decoration: none;
            font-weight: bold;
        }

        p.login-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h2>Student Registration</h2>
    <?php echo validation_errors('<p class="error">', '</p>'); ?>
    <?php if (isset($error_message)) echo '<p class="error">' . $error_message . '</p>'; ?>

    <!-- Update the form action URL to call the save() method in the Student controller -->
    <?php echo form_open('student/save'); ?>
        <label for="first_name">First Name:</label>
        <input type="text" name="first_name" value="<?php echo set_value('first_name'); ?>" required>

        <label for="last_name">Last Name:</label>
        <input type="text" name="last_name" value="<?php echo set_value('last_name'); ?>" required>

        <label for="email">Email:</label>
        <input type="email" name="email" value="<?php echo set_value('email'); ?>" required>

        <label for="phone">Phone:</label>
        <input type="text" name="phone" value="<?php echo set_value('phone'); ?>" required>

        <label for="address">Address:</label>
        <input type="text" name="address" value="<?php echo set_value('address'); ?>" required>

        <label for="password">Password:</label>
        <input type="password" name="password" required>

        <label for="confirm_password">Confirm Password:</label>
        <input type="password" name="confirm_password" required>

        <label for="gender">Gender:</label>
        <select name="gender" required>
            <option value="">Select Gender</option>
            <option value="male" <?php echo set_select('gender', 'male'); ?>>Male</option>
            <option value="female" <?php echo set_select('gender', 'female'); ?>>Female</option>
        </select>

        <input type="submit" name="register" value="Register">
        <p>
    <a href="<?php echo site_url('admin/login'); ?>">Admin Login</a>
</p>
<p class="login-link">
        If you already have an account, <a href="<?php echo site_url('auth/login'); ?>">click here to login</a>.
    </p>
    <?php echo form_close(); ?>
</body>
</html>
